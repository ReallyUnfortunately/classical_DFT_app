%% 
colorscheme='white';
textcolor='black';
Fontsize=25;
% ylabeltext='$$C_\mu$$ [$\mu$F/cm$^2$]';
% ylabeltext='$$C$$ [$\mu$F/cm$^2$ ]';
ylabeltext='$S_{ij}(q)$';

xlabeltext='$q$ [nm$^{-1}$]';



    set(gca,'TickLabelinterpreter','latex','FontSize',Fontsize,'Color',colorscheme,'YColor',textcolor,'XColor',textcolor)
    set(gcf,'color',colorscheme);
    set(gca,'Units','normalized','position',[0.15   0.1500    0.8    0.8]);
    set(gcf,'Units','inches','position',[2.1615    1.0260    9.4896    6.1094]);
fig = gcf;
fig.InvertHardcopy = 'off';

ylabel(ylabeltext,'Interpreter','latex','FontSize',Fontsize,...
'Units','normalized','Position',[-0.10 0.45],'Rotation',90)
xlabel(xlabeltext,'Interpreter','latex','FontSize',Fontsize,'Units','normalized','Position',[0.5 -0.09])

 set(gcf,'Units','Inches');
                pos = get(gcf,'Position');
                set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
                
%%
ylabeltext='$$\rho(x)_N$$ [M]';
xlabeltext='$$x$$ [nm]';
%%
% lgd=legend('String',{'$$\rho^{DFT}_+(z)$$','$$\rho^{DFT}_-(z)$$','$$\rho^{sim}_+(z)$$','$$\rho^{sim}_-(z)$$'},'Interpreter','latex');
% lgd=legend;
lgd=legend('$\eta=0.0001$','$\eta=0.001$','$\eta=0.01$','$\eta=0.1$','$\eta=0.3$','$\eta=0.4$');
    set(lgd,'Edgecolor','black','Color','white','Interpreter','latex','Textcolor','black','Location','best')

    set(gcf,'Units','Inches');
                pos = get(gcf,'Position');
                set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
                
%% change order 
                
ax=gca;
ax.Children=ax.Children([1 2 3 4 6 5]);    

%%

%axis on other side
set(gca,'YaxisLocation','right');
%%

box off
ax=gca;
axes('position',ax.Position,'box','on','ytick',[],'xtick',[],'color','none')


%% from black to white 

    set(gca,'TickLabelinterpreter','latex','FontSize',25,'Color','white','YColor','black','XColor','black')
    set(gcf,'color','white');

%% From white to black

    set(gca,'TickLabelinterpreter','latex','FontSize',25,'Color','Black','YColor','white','XColor','white')
    set(gcf,'color','black');

    
    fig = gcf;
fig.InvertHardcopy = 'off';