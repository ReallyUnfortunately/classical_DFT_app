philength = length(data.BC.phiV);
Phisingle = data.BC.phiV(1:(philength-1)/2+1);

for c0 = 1:length(data.sys.eta)
    for v0 = 1:(length(data.BC.phiV)-1)/2
        if data.Omega(v0,c0)<data.Omega(philength+1-v0,c0)
            Omega(v0,c0) = data.Omega(v0,c0);
            Gamma_tot(v0,c0) = sum(data.GamAds(:,v0,c0));
            sigma0(v0,c0) = data.sigma0(1,v0,c0);
        else
            Omega(v0,c0) = data.Omega(philength+1-v0,c0);
            Gamma_tot(v0,c0) = sum(data.GamAds(:,philength+1-v0,c0));
            sigma0(v0,c0) = data.sigma0(1,philength+1-v0,c0);
        end
    end
    Omega(v0+1,c0) = data.Omega(v0,c0);
    Gamma_tot(v0+1,c0) = sum(data.GamAds(:,v0,c0));
    sigma0(v0+1,c0) = data.sigma0(1,v0,c0);
end

