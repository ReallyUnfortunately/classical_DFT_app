function c1LJ=c1LenJon(g,R,LJ,alpha,r,d)
N=length(g(1,:));
Wd=zeros(length(R),length(R),2*N-1);
zR=d*(-N+1:N-1);

Wdb=zeros(length(R),length(R));
Wdbd=Wdb;

eLJ=sqrt(LJ.eLJ'*LJ.eLJ);%Lorentz-Berthelot

for j=1:length(R)
    for i=1:length(R)
        nD=floor(LJ.dLJ(i,j)*2^(1/6*LJ.wca)/d);
        
        Wd(i,j,:)=4*pi*eLJ(i,j)*LJ.dLJ(i,j)^2*(1/5*(LJ.dLJ(i,j)./zR).^10-1/2*(LJ.dLJ(i,j)./zR).^4);
        
        Wd(i,j,N-nD:N+nD)=4*pi*eLJ(i,j)*LJ.dLJ(i,j)^2*(1/5*2^(-10/6*LJ.wca)-1/2*2^(-4/6*LJ.wca))+LJ.wca*(-pi*eLJ(i,j)*((LJ.dLJ(i,j)*2^(1/6*LJ.wca)).^2-zR(N-nD:N+nD).^2));
        Wdb(i,j)=(4/3*pi*(LJ.dLJ(i,j)*2^(1/6))^3*eLJ(i,j)*LJ.wca-16/3*pi*eLJ(i,j)*LJ.dLJ(i,j)^3*(1/3*2^(-1/6*9*LJ.wca)-2^(-1/6*3*LJ.wca)));
    end
end

if ~isinf(LJ.rc)
    for j=1:length(R)
        for i=1:length(R)
            a=-4*eLJ(i,j)*((LJ.dLJ(i,j)/LJ.rc(i,j)).^12-(LJ.dLJ(i,j)/LJ.rc(i,j)).^6);
            Nrc=floor(LJ.rc(i,j)/d);
            Wd(i,j,[1:N-Nrc-1 N+Nrc+1:2*N-1])=squeeze(Wd(i,j,[1:N-Nrc-1 N+Nrc+1:2*N-1]))'-4*pi*eLJ(i,j)*LJ.dLJ(i,j)^2*(1/5*(LJ.dLJ(i,j)./zR([1:N-Nrc-1 N+Nrc+1:2*N-1])).^10-1/2*(LJ.dLJ(i,j)./zR([1:N-Nrc-1 N+Nrc+1:2*N-1])).^4);
            Wd(i,j,N-Nrc:N+Nrc)=squeeze(Wd(i,j,N-Nrc:N+Nrc))'-4*pi*eLJ(i,j)*LJ.dLJ(i,j)^2*(1/5*(LJ.dLJ(i,j)./LJ.rc(i,j)).^10-1/2*(LJ.dLJ(i,j)./LJ.rc(i,j)).^4)+pi*a*(LJ.rc(i,j)^2-zR(N-Nrc:N+Nrc).^2);
            
            Wdbd(i,j)=-16/3*pi*eLJ(i,j)*LJ.dLJ(i,j)^3*(-4/3*(LJ.dLJ(i,j)/LJ.rc(i,j))^9+2*(LJ.dLJ(i,j)/LJ.rc(i,j))^3);
        end
    end
end

if min(abs(sum(Wd,3)))>0
    Wd=Wd.*(Wdb+Wdbd)./(-d*(sum(Wd,3)));
else
    Wd(isnan(Wd))=0;
end

c1LJ=zeros(length(R),size(g,2));
for i=1:length(R)
    for j=1:length(R)
        c1LJ(i,:)=c1LJ(i,:)-d*conv((alpha(j).*r(j).^3)*g(j,:),squeeze(Wd(i,j,:)),'same');
    end
end
end