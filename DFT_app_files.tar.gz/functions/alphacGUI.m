function [alpha,c]=alphacGUI(alpha,constants,sys)

Mol = constants.Mol;
nhs = sys.nhs;
M = sys.M;
nu = nhs + M;
Z = sys.Z;
Rreal = sys.Rreal;
r = sys.r;
Nc = nhs+1:nu;

if M~=0
    nonzeroZ=find(Z~=0);
    Zchain=sum(Z(nonzeroZ(nonzeroZ>nhs)));
    
    if Zchain==0
        if isempty(nonzeroZ)
            c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
        else
            lastZ=max(nonzeroZ(1:nhs));
            if isempty(lastZ) || lastZ>nhs
                c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
            else
                nonzeroZfixed=nonzeroZ(1:lastZ-1);
                alpha(lastZ)=-1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZfixed).*r(nonzeroZfixed).^3.*Z(nonzeroZfixed));
                c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
            end
        end
    else
        lastZ=nhs+1;
        nonzeroZfixed=nonzeroZ(1:lastZ-1);
        alpha(lastZ)=-1/sum(Z(Nc))/r(lastZ)^3*sum(alpha(nonzeroZfixed).*r(nonzeroZfixed).^3.*Z(nonzeroZfixed));
        alpha(Nc)=alpha(lastZ);
        c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
    end
else
    if isempty(find(Z~=0, 1))% If there are no charges particles
        c=alpha.*(r/(2*Rreal)).^3/Mol;
    else
        nonzeroZ=find(Z~=0);
        lastZ=max(nonzeroZ);
        nonzeroZ=nonzeroZ(1:length(nonzeroZ)-1);
        alpha(lastZ)=-1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZ).*r(nonzeroZ).^3.*Z(nonzeroZ));
        c=alpha/Mol.*r.^3/(2*Rreal)^3;
    end
end
