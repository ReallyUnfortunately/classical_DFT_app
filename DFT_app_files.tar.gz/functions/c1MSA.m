function c1MSAc=c1MSAdc(alphat,Z,r,d,g,MSA,lambda)
etab=MSA.etab;
Gammab=MSA.Gammab;

X=(Z-etab./r.^2)./(1+Gammab./r);
Nb=(X-Z).*r;

% cMSAsh=2*lambda*(Z(i)*Nb(j)+etab/r(i)*(X(i)+1/3*etab/r(i)^2));
L0=-(1./r-1./r').^2/4.*(etab*(X+X')+1/4*(etab^2*(1./r-1./r').^2-4*Nb.*Nb'));
L1=-((X-X').*(Nb-Nb')+(X.^2+X'.^2)*Gammab+(1./r+1./r').*(Nb.*Nb')-1/3*etab^2*(1./r.^3+1./r'.^3));
L2=-etab*(X+X')+(Nb.*Nb')-1/2*etab^2*(1./r.^2+1./r'.^2);
L4=1/3*etab^2;


c1MSAc=zeros(length(r),size(g,2));
c1MSAcb=zeros(1,length(r));

for i=1:length(r)
    for j=1:length(r)
        
            cMSAsh=2*lambda*(Z(i)*Nb(j)+etab/r(i)*(X(i)+1/3*etab/r(i)^2));

%         if 1/r(i)<1/r(j)
            
            
            Ddif=max(abs(1/r(j)-1/r(i))/2,0);
            Dsum=(1/r(j)+1/r(i))/2;
            NDs=ceil(Ddif/d);
            NDl=ceil((1/r(j)+1/r(i))/2/d);
            zds=d*(-NDs:NDs);
            zdl=d*(-NDl:NDl);
            
            c2MSAcb(i,j)=4*pi/3*Ddif^3*cMSAsh+4*pi*lambda*(1/2*L0(i,j)*(Dsum^2-Ddif^2)+L1(i,j)/3*(Dsum^3-Ddif^3)+L2(i,j)/4*(Dsum^4-Ddif^4)+L4/6*(Dsum^6-Ddif^6))+2*pi*lambda*Z(i)*Z(j)*Dsum^2;
            c1MSAcb(i)=c1MSAcb(i)+c2MSAcb(i,j)*alphat(j)*r(j)^3;
            
            c2temp=2*pi*Z(i)*Z(j)*lambda*(Dsum-abs(zdl))+...
                2*pi*lambda*(L0(i,j)*(Dsum-abs(zdl))+L1(i,j)/2*(Dsum^2-zdl.^2)+L2(i,j)/3*(Dsum^3-abs(zdl).^3)+L4/5*(Dsum^5-abs(zdl).^5));
            c2temp(-NDs+(length(c2temp)+1)/2:NDs+(length(c2temp)+1)/2)=pi*(Ddif^2-zds.^2)*cMSAsh+...
                2*pi*lambda*(L0(i,j)*(Dsum-Ddif)+L1(i,j)/2*(Dsum^2-Ddif^2)+L2(i,j)/3*(Dsum^3-Ddif^3)+L4/5*(Dsum^5-Ddif^5))+2*pi*lambda*Z(i)*Z(j)*(Dsum-abs(zds));
            if sign(c2MSAcb(i,j))*(d*sum(c2temp)-c2MSAcb(i,j))<0
                c2temp([1,end])=c2temp([1,end])-(d*sum(c2temp)-c2MSAcb(i,j))/2/d;
            else
                c2temp([2,end-1])=c2temp([2,end-1])-(d*sum(c2temp)-c2MSAcb(i,j))/2/d;
            end
            
            c1MSAc(i,:)=c1MSAc(i,:)+d*conv(alphat(j)*r(j)^3*g(j,:),c2temp,'same');
%         end
    end
end
