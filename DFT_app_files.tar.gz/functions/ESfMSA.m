function [c1ES,c1ESMSA,c1ESnonMSA,Gamma,dGamma,PhiMSA,Zeff]=ESfMSA(Z,alpha,g,b,lambda,r,d,z,Gamma,dGamma,Gammab,dft,errg)

if nnz(Z)>1
    
    if strcmp(dft.ES,'MSAu') %MSAu or only MSAc
        
        %% Calculating q_i
        N=length(z);
        Nb=round(b/d);
        
        WF=zeros(length(b),2*N-1);
        for j=1:length(r)
            WF(j,max(N-Nb(j),1):min(N+Nb(j),size(WF,2)))=1/(2*b(j));
            WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])=WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])-(d*sum(WF(j,:))-1)/2/d;
        end
        
        q0=zeros(length(r),3*N-2);
        for j=1:length(r)
            %         q0(j,:)=alpha(j)*d*conv(g(j,:),WF(j,:),'same');
            q0(j,:)=alpha(j)*d*conv(g(j,:),WF(j,:),'full');
        end
        
        q2=Z.^2.*r.^3*q0;
        q2(abs(q2)<1e-15)=0;
        %     figure(431234);semilogy(z,abs(q0-repmat(alpha,N,1)'));pause(0.0001)
        %% Calculating space dependent Gamma
        o=1/length(r)*sum(1./r);
        
        indnz=abs(q2)>1e-10;
        Ntind=(length(q2(indnz))-N)/2;
        zt=int8(Ntind+1:length(q2(indnz))-Ntind);
        
        if isempty(Gamma)
            Gamma=1/2/o*(sqrt(1+4*o*sqrt(pi*lambda*q2))-1);
        end
        
        
        q0t=q0(:,indnz);
        Gammat=Gamma(indnz);
        Gamma0t=Gammat;
        
        errorGam=1;
        errorGamp=2;
        a=0.1;
        Gameps=10^(min(abs(errg)-2,-4));
        
        while errorGam>Gameps&&abs(errorGamp-errorGam)>Gameps
            Gamma0t=a*Gammat+(1-a)*Gamma0t;
            H=sum(q0t./(1+Gamma0t./r'))+2/pi*(1-pi/6*sum(q0t));
            %             eta=1./H.*sum(Z'.*r'.^2.*q0./(1+Gamma0./r'));
            eta=1./H.*(Z.*r.^2*(q0t./(1+Gamma0t./r')));
            %             Gamma=sqrt(pi*lambda*sum(r'.^3.*q0.*((Z'-eta./r'.^2)./(1+Gamma0./r')).^2));
            Gammat=sqrt(pi*lambda*(r.^3*(q0t.*((Z'-eta./r'.^2)./(1+Gamma0t./r')).^2)));
            errorGamp=errorGam;
            errorGam=max(abs(Gammat-Gamma0t));
        end
        
        Gamma(indnz)=Gammat;
        Gamma(~indnz)=0;
        
        Zeff=(Z'-eta(zt)./r'.^2)./(1+Gammat(zt)./r');
        
        
        
        %% Calculating space dependent derivative of Gamma wrt q_i
        
        
        if isempty(dGamma)
            dGamma=1/2*pi*lambda*Z'.^2.*r'.^3./(sqrt(1+4*o*sqrt(pi*lambda*q2)).*sqrt(pi*lambda*q2).*ones(length(r),length(q2)));
        end
        
        dGammat=dGamma(:,indnz);
        dGamma0t=dGammat;
        errorGam=1;
        errorGamp=2;
        errorGampp=2;
        a=0.75;
        
        while errorGam>Gameps&&abs(errorGamp-errorGam)>Gameps&&abs(errorGampp-errorGam)>Gameps
            dGamma0t=(1-a)*dGamma0t+a*dGammat;
            dH=1./(1+Gammat./r')-1./r*(q0t./(1+Gammat./r').^2).*dGamma0t-1/3;
            %             deta=-dH./H.*eta...
            %                 +1./H.*(Z'.*r'.^2./(1+Gamma./r'))...
            %                 -1./H.*sum(Z'.*r'.*q0./(1+Gamma./r').^2).*dGamma0;
            deta=1./H.*(-dH.*eta...
                +(Z'.*r'.^2./(1+Gammat./r'))...
                -(Z.*r*(q0t./(1+Gammat./r').^2)).*dGamma0t);
%                         dGamma=pi*lambda./Gamma.*(1/2*r'.^3.*((Z'-eta./r'.^2)./(1+Gamma./r')).^2 ...
%                             -sum(r'.^2.*q0.*(Z'-eta./r'.^2).^2./(1+Gamma./r').^3).*dGamma0 ...
%                             -sum(r'.*q0.*(Z'-eta./r'.^2)./(1+Gamma./r').^2).*deta);
            dGamma=pi*lambda./Gammat.*(1/2*r'.^3.*((Z'-eta./r'.^2)./(1+Gammat./r')).^2 ...
                -r.^2*(q0t.*(Z'-eta./r'.^2).^2./(1+Gammat./r').^3).*dGamma0t ...
                -r*(q0t.*(Z'-eta./r'.^2)./(1+Gammat./r').^2).*deta);
            
            errorGampp=errorGamp;
            errorGamp=errorGam;
            errorGam=max(abs(dGammat(:)-dGamma0t(:)));
        end
        
        dGamma(:,indnz)=dGammat;
        dGamma(:,~indnz)=0;
        
        dGamma(isnan(dGamma))=0;
        deta(isnan(deta))=0;
        
        
        
        %% Calculating free energy density MSA
        
        PhiMSA=-lambda*sum(q0t(:,zt).*r'.^3.*(Z'.^2.*Gammat(zt)+Z'.*eta(zt)./r')./(1+Gammat(zt)./r'))+...
            Gammat(zt).^3/(3*pi);
        
        %% Calculating derivative of electrostatic free energy density
%         c2MSA=lambda*(Z.^2'.*Gamma+Z'.*eta./r')./(1+Gamma./r')...
%             +lambda./r'.^3.*sum(r'.^3.*q0.*(Z'.^2-Z'.*eta./r.^2')./(1+Gamma./r').^2).*dGamma...
%             +lambda./r'.^3.*sum(r'.^2.*q0.*Z'./(1+Gamma./r')).*deta...
%             -1./r'.^3*Gamma.^2/pi.*dGamma;
        c2MSA=lambda*(Z.^2'.*Gammat+Z'.*eta./r')./(1+Gammat./r')...
            +lambda./r'.^3.*(r.^3*(q0t.*(Z'.^2-Z'.*eta./r.^2')./(1+Gammat./r').^2)).*dGammat...
            +lambda./r'.^3.*(Z.*r.^2*(q0t./(1+Gammat./r'))).*deta...
            -1./r'.^3*Gammat.^2/pi.*dGammat;
        
        for j=1:length(r)
            c1ESMSA(j,:)=d*conv(c2MSA(j,:),WF(j,:),'full');
        end
        c1ESMSA=c1ESMSA(:,round(size(c1ESMSA,2)/2-N/2+1:size(c1ESMSA,2)/2+N/2));
        
    else
        c1ESMSA=0;
        PhiMSA=zeros(1,length(z));
        Zeff=Z;
    end
    %% MSA direct correlation function, psish+psiC eq. 37
    N=length(z);
    
    RR=1/2*(1./r+1./r');
    
    b=1./r/2+1/Gammab/2;
    
    %Shell Radius
    B=b+b';
    BB=b'*b;
    
    NRi=round(1/2./r'/d.*ones(length(r),length(r)));
    NRj=round(1/2./r/d.*ones(length(r),length(r)));
    NR=NRi+NRj;
    ZZ=Z'*Z;
    zz=abs(d*(-N+1:N-1))';
    
    nzero=find(Z~=0);%Check this since I think somethings missing
    c2nonMSA=zeros(2*N-1,length(nzero),length(nzero));
    
    for j=1:length(nzero)
        c2nonMSA(:,:,j)=lambda*pi/2*ZZ(nzero(j),nzero)./BB(nzero(j),nzero).*(repmat(1/3*RR(nzero(j),nzero).^3+...
            B(nzero(j),nzero).^2.*RR(nzero(j),nzero)-...
            B(nzero(j),nzero).*RR(nzero(j),nzero).^2,2*N-1,1)+...
            B(nzero(j),nzero).*zz.^2-...
            1/3*repmat(zz.^3,1,length(nzero))-...
            zz.*B(nzero(j),nzero).^2);
        for k=1:length(nzero)
            c2nonMSA(c2nonMSA(N,k,j)*c2nonMSA(:,k,j)<0,k,j)=0;
            
            if N-NR(nzero(j),nzero(k))+1>0&&N+NR(nzero(j),nzero(k))-1<2*N
                c2nonMSA([N-NR(nzero(j),nzero(k))+1,N+NR(nzero(j),nzero(k))-1],k,j)=c2nonMSA([N-NR(nzero(j),nzero(k))+1;N+NR(nzero(j),nzero(k))-1],k,j)-...
                    lambda*pi/6*ZZ(nzero(j),nzero(k))./BB(nzero(j),nzero(k)).*RR(nzero(j),nzero(k)).*(B(nzero(j),nzero(k))-1/2*RR(nzero(j),nzero(k)))*d/2;
            end
        end
    end
%     c2nonMSA=1.5*c2nonMSA;
    
    c1ESnonMSA=zeros(length(r),N);
    
    for j=1:length(nzero)
        for k=1:length(nzero)
            c1ESnonMSA(nzero(j),:)=c1ESnonMSA(nzero(j),:)+alpha(nzero(k))*r(nzero(k))^3*d.*real(conv(g(nzero(k),:),c2nonMSA(:,k,j)','same'));
        end
    end
    
    %     c1ESnonMSA=c1ESnonMSA(:,N:2*N-1);
    
    %% Total contribution electrostatics to C1
    
    c1ES=c1ESMSA+c1ESnonMSA;
    
else
    c1ES=0;
    c1ESMSA=0;
    c1ESnonMSA=zeros(length(Z),length(z));
    Gamma=0;
    PhiMSA=zeros(1,length(z));
    Zeff=0;
end

end
