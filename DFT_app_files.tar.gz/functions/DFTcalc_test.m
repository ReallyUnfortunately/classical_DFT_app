function data=DFTcalc(sys,BC,dft,LJ)

eta=sys.eta;
disp('start')

% Natural Constants
epsilon0=8.8541878128e-12; %permittivity constant
el=1.602176634e-19; %Electric charge
Na=6.02214076e23; %Number of Avogadro
Mol=Na*1e3*1e-27;% Molar in #/nm^3
kb=1.38064852e-23;%Boltzmann Constant

T=el^2/4/pi/sys.epsilonw/epsilon0/sys.lambdanm/1e-9/kb;%Temperature

%% Define # of particles, their size ratios and their charges

nhs=sys.nhs; %number of hard-sphere species. Only fill in r, Z, c for the first nu values. The other values will be thrown away.
M=sys.M; %number of beads in the chain

nu=sys.nhs+sys.M; %total number of hard-sphere types, i.e. chain beads + hard-spheres
Nc=sys.nhs+1:sys.nhs+sys.M;

if sys.nhs==0
    Nhs=1;
    sys.rhs=1;
    sys.Zhs=1;
else
    Nhs=1:sys.nhs;
end

%Define particle ratios
r(Nhs)=sys.rhs(Nhs); %size-ratio between first particle with the rest r(i)=R_1/R_j for the hard spheres
r(Nc)=sys.rc(Nc-nhs); %size-ratio between first solvent particle with the particles in the chain;

r=r(1:nu);

Z(Nhs)=sys.Zhs; %Valency of particle of species 1:n
Z(Nc)=sys.Zc; %Valency of chain particles

Z=Z(1:nu);

%% packing fraction or concentration of particles

%Defining concentration. Note that for charged species, one has a charge
%neutrality condition, fixing some values of c
% for two charged species, one of the concentrations must be fixed.
% for three charged species, two of the concentrations must be fixed etc.
%...
%For convenience, choose the first x concentrations to fix
%Note that alpha=c*Mol.*(2*Rreal./r).^3;

packing=sys.packing;
csolv=40;

if ~strcmp(packing,'on')
    c(Nhs)=sys.chs(Nhs); %Concentration in Moles for particles of species 1
    c(Nc)=sys.cc; %Concentration in Moles for particles of species 2 (alpha=c*Mol.*(2*Rreal./r).^3;)
    c=c(1:nu);
else
    c=1e-10*ones(1,nu);
end


%% rigid chains not yet working well
rigid='off';
theta0=pi*120/180;


%% parallel defining parameters
sigma=zeros(2,length(BC.phiV),length(eta),length(sys.zmax));
phi0=zeros(2,length(BC.phiV),length(eta),length(sys.zmax));
GamAds=zeros(nu,length(BC.phiV),length(eta),length(sys.zmax));
F.id_legendre=0;
f.id_FMT=0;
Omega=zeros(length(BC.phiV),length(eta),length(sys.zmax));
decay=zeros(3,length(eta),length(BC.phiV),length(sys.zmax));
wav=zeros(3,length(eta),length(BC.phiV),length(sys.zmax));
GammabMSA=zeros(1,length(eta));

%%
for z0=1:length(sys.zmax)
    if length(sys.zmax)>1 && z0>1
        clear g_0 g V_ext
    end
    %% All non-tuning parameters
    
    % Natural Constants
    beta=1/(kb*T);%inverse Boltzmann temperature
    lambda=el^2*beta/(4*pi*sys.epsilonw*epsilon0)/(2*sys.Rreal*1e-9);%Bjerrum length
    
    %Distance between gridpoints
    d=1/sys.ngrid;
    
    %Round sys.zmax off in terms to d
    sys.zmax(z0)=round(sys.zmax(z0)/d)*d;
    
    %Size particles
    %     r(1)=1;
    for j=1:nu
        %         r(j)=1/(round(1/r(j)/d/2)*2*d);
        R(j)=1/2/r(j);
    end
    
    % number of gridpoints |1|2|3|...|N-1|N|
    N=round(sys.ngrid*sys.zmax(z0));
    
    %Length vector with z_i=d*(i-1/2)
    z=d*((1:N)-1/2);
    
    %% External potential=potential of wall=hard-wall potential
    V_ext=Vext(z,R,d,dft,LJ);
    
    %% setting values for alpha
    alpha=c*Mol.*(2*sys.Rreal./r).^3;
    
    if ~strcmp(packing,'on')
        if sum(alpha*pi/6)>=0.6
            error('!!!Packing fraction unphysically large.!!!')
        elseif nnz(Z)~=0&&abs(sum(sign(Z)))==nnz(Z)
            error('All charged species having the same sign in charge is not physical!')
        end
        eta=pi/6*alpha*r'.^3;
    else
        if sys.eta>0.48
            error('!!!Packing fraction unphysically large.!!!')
        end
    end
    
    if nnz(Z)==1
        error('Only one charged species is not physical!')
    end
    
    %     % Fixing the number density of one of the charged species from charge neutrality in the bulk
    %     if ~isempty(find(Z(Nhs)~=0, 1))
    %         [alpha,c]=alphapacking(Nc,Nhs,eta(c0),Z,r,csolv,Mol,sys);
    %     end
    
    if nnz(sign(alpha)<0)>0
        error('No charge neutrality possible in bulk!!')
    end
    
    
    %% Weight functions W_a(z)
    % This includes the tensor weight function
    W=WFFMT(N,R,d,dft);
    
    %% Picard
    
    %Determine to either loop over phi0 or sigma0 or c/alpha/eta
    if strcmp(BC.type,'DD')
        nV=length(BC.phiV);
    elseif ~strcmp(BC.type,'DD')
        nV=length(BC.sigma0);
    else
        nV=1;
    end
    
    if ~strcmp(packing,'on')
        eta=0;
    end
    
    %%
    g_0=zeros(nu,length(z));
    
    %% Begin loop for different values of phi0 or BC.sigma0
    for c0=1:length(eta)
        for v0=1:nV
            
            if strcmp(packing,'on')
                [alphat,c(c0,:)]=alphapacking(Nc,Nhs,eta(c0),Z,r,csolv,Mol,sys);
            else
                alphat=alpha;
            end
            
            if min(alphat)<0
                error('!!!!Solvent concentration too high!!!!')
            end
            
            if strcmp(dft.epsilonbulkvar,'on')
                epsilonb=max(epsilon(sys.epsilonw,epsilon0,1,1,c(c0,:),beta,el,Mol,Z),2);
                data.epsb(c0)=epsilonb;
                lambda=el^2*beta/(4*pi*epsilonb*epsilon0)/(2*sys.Rreal*1e-9);%Bjerrum length
            end
            
            
            %% Boundary Conditions Electrostatics
            [phi, D2, B, C]=ESBC(BC,z,d,beta,el,v0);
            if strcmp(BC.type,'ND')||strcmp(BC.type,'NN')
                C=4*pi*lambda*C/(el*1e18/(2*sys.Rreal)^2);%From C/m^2 to e/d^2
            end
            phi_old=phi;
            
            %% initial density profile
            smalla=1;
            ag0=sys.ag0;
            if v0==1
                if nV>1||c0==1
                    if min(min(V_ext'))<0
                        g_0=exp(-smalla*V_ext/abs(min(V_ext(V_ext<0))));
                    else
                        g_0=exp(-smalla*V_ext);
                    end
                else
                    g_0=ag0*gf(:,:,v0,c0-1)+(1-ag0)*exp(-smalla*V_ext);
                end
            elseif strcmp(BC.type,'DD')
                g_0=ag0*gf(:,:,v0-1,c0)+(1-ag0)*exp(-smalla*V_ext);
            else
                g_0=exp(-smalla*V_ext-Z'.*phi*0.01);
%                 g_0=(ag0*gf(:,:,v0-1,c0)+(1-ag0)*exp(-smalla*V_ext)).*exp(-Z'.*phi*0.01);
            end
            
            g_old=g_0;
            g_new=g_0;
            g=g_0;
            
            %% Bulk values
            
            if ~strcmp(dft.HS,'none')
                %Bulk weighted densities for all species
                [nb, ptHSFMT, PhiFMTb]=WDFMTb(alphat,r,nhs,M,dft);
                
                %bulk direct correlation function
                [c1HSb, phiWBb, dphib]=cFMTb(nb,R,dft);
            else
                %Bulk weighted densities for all species
                [nb, ptHSFMT, PhiFMTb]=WDFMTb(1e-20*ones(1,length(r)),r,nhs,M,dft);
                %bulk direct correlation function
                [c1HSb, phiWBb, dphib]=cFMTb(nb,R,dft);
            end
            %Electrostatics
            %bulk
            [c1ESb,MSA]=ESb(Z,alphat,lambda,r,d,dft);
            
            GammabMSA(c0)=MSA.Gammab;
            
            % Chain connectivity
            if strcmp(dft.TPT1,'on')
                [c1chainb,Phichainb,ptchain]=c1CCb(alphat,r,Nhs,Nc,nb,Z,MSA,lambda);
            else
                Phichainb=0;
                c1chainb=0;
                ptchain=0;
            end
            
            % Lennard-Jones attraction
            if strcmp(dft.LJ,'on')
                c1LJb=c1LenJonb(LJ,alphat,R,r);
            else
                c1LJb=0;
            end
            
            %% Total direct correlatioon function in bulk=-excess chemical
            %potential
            c1b=c1HSb+c1ESb+c1chainb+c1LJb;
            
            %% Bulk pressure
            ptbulk=ptHSFMT+MSA.pu+MSA.pc+ptchain;
            
            %Pressure from Bulk value Grand Potential Omega/V=f_HS+f_ES_MSA-rho*mu
            ptbulkomega=-phiWBb.tot-MSA.Phib+1/2*(alphat.*r.^3)*MSA.c2EScb*(alphat.*r.^3)'-sum(r.^3.*alphat.*(c1b-1));
            
            %Numerical Bullshit
            k=2;
            err.g(1)=inf;
            err.skip=0;
            errorg=inf;
            err.a0(1:2)=-6;
            err.a0min=-1;
            a0=1e-10;
            a00=-10;
            a0min=0.5;
            
            %             try
            %% All other iterations until convergence
            while errorg>sys.eps
                
                %Picard Iteraction mix
                g=(1-a0)*g_old+a0*g_new;
                g(g==0)=1e-20;
                
                %weighted densities for FMT
                if ~strcmp(dft.HS,'none')
                    n=WDFMT(g,alphat,W,r,d,nhs,M);
                    maxn3=nanmax(n.n3);
                else
                    n=WDFMT(g,1e-20*alphat,W,r,d,nhs,M);
                    maxn3=nanmax(n.n3);
                end
                
                %Check maximum packing condition n.n3<1
                l=1;
                while maxn3>1
                    a=a0/10^l;
                    g=(1-a)*g_old+a*g_new;
                    n=WDFMT(g,alphat,W,r,d,nhs,M);
                    maxn3=max(n.n3);
                    l=l+1;
                    
                    if isinf(log10(a))
                        g=g_0;
                        n=WDFMT(g,alphat,W,r,d,nhs,M);
                        maxn3=max(n.n3);
                    end
                end
                
                %Potential from Poisson equation using tridiagonal
                %matrix inversion with correction
                Q=4*pi*lambda*(r.^3.*alphat.*g')*Z';
                
                if ~strcmp(BC.type,'NN')
                    phi_old=phi;
                    phi=transpose(D2\(-B*Q-C));
                    phi(isnan(phi))=0;
                else
                    phi_old=phi;
                    phi=transpose(D2\(-B*[Q;0]-C));
                    phi=phi(1:end-1);
                end
                
                % Mean-field contribution
                c1ESC=-Z'*phi;
                
                % Direct correlation function electrostatics due to energy term
                [c1ESu,MSA,WF]=c1MSAu(alphat,Z,r,d,z,g,MSA,lambda,dft,err.a0(k-1));
                MSA.c1ESu=c1ESu;
                
                % Direct correlation function electrostatics from correlations
                c1ESc=c1MSAc(alphat,Z,r,d,z,g,MSA,lambda,dft);
                MSA.c1ESc=c1ESc;
                
                % Total contribution electrostatics to C1
                c1ES=c1ESc+c1ESu;
                
                % Internal energy contribution according to Debye Huckel
                % theory
                if strcmp(dft.ESu,'MFu')
                    c1MFu=ESMFu(z,g,alphat,r,W,Z,lambda);
                elseif strcmp(dft.ESu,'MFu2')
                    c1MFu=ESMFu2(z,g,alphat,r,W,Z,lambda);
                else
                    c1MFu=0;
                end
                
                %direct correlation function chain associativity from
                %TPT1 [J. Chem. Phys. 117, 2368 (2002)]
                if strcmp(dft.TPT1,'on')
                    [c1chain, Phichain]=c1CC(n,r,Nc,W,WF,Z,MSA,d,lambda);
                else
                    c1chain=0;
                    Phichain=0;
                end
                
                %Direct correlation function for mean-field LJ attraction
                if strcmp(dft.LJ,'on')
                    c1LJ=c1LenJon(g,R,LJ,alphat,r,d);
                else
                    c1LJ=0;
                end
                
                %Calculations for HS-FMT direct correlation function  [J. Phys.: Condens. Matter 22 063102]
                [psi, dphi, PhiFMT]=FMT(n,dft);
                c1HS=c1HSFMT(dphi,W,d,r);
                
                % Total direct correlation function
                c1=c1HS+c1ES+c1ESC+c1LJ+c1chain+c1MFu;
                for j=1:nu
                    c1(j,c1(j,:)-c1b(j)>500)=500+c1b(j);
                    c1(j,c1(j,:)-c1b(j)<-500)=-500+c1b(j);
                end
                
                %Chain connectivity
                if strcmp(dft.TPT1,'on')
                    
                    %New density profiles with chains functional
                    G=connectivity(c1,c1b,V_ext,sys,r,z,d,rigid,theta0);
                    
                    g_new(Nhs,:)=exp(-V_ext(Nhs,:)+c1(Nhs,:)-c1b(Nhs)');
                    
                    if strcmp(rigid,'on')
                        for j=Nc
                            g_new(j,:)=exp(-V_ext(j,:)+c1(j,:)-c1b(j)).*G.tot(j-nhs,:);
                        end
                    else
                        for j=Nc
                            g_new(j,:)=exp(-V_ext(j,:)+c1(j,:)-c1b(j)).*G.L(j-nhs,:).*G.R(M+1-j+nhs,:);
                        end
                    end
                    g_old=g;
                else
                    %New density profiles without chains functional
                    g_new=exp(-V_ext+c1-c1b');
                    g_old=g;
                end
                
                
                %Picard errors and parameters (numerical bullshit)
                [a00,err]=apicard_new(g,g_new,phi,phi_old,err,k,a00,sys,BC);
                a0=10^a00;
                errorg=real(err.g(k));
                
                if (err.dg(k)>10&&k>10)||~isempty(find(isnan(g_new), 1))
                    if k>2
                        g_new=g;
                        a0=10^(err.a0(k-2)-2);
                        err.a0(k)=a00-2;
                    else
                        g_new=g_0;
                        a0=a0/100;
                    end
                end
                
                % Free energy
                phi0LV=[3/2*phi(1)-1/2*phi(2),3/2*phi(N)-1/2*phi(N-1)];
                dphi0=[(phi(2)-phi(1))/d, (phi(N)-phi(N-1))/d];
                sig=-dphi0/(4*pi*lambda).*[1 -1];
                
                
                [Fe,fe]=F_id_ex_FMT(PhiFMT,g,c1,alphat,d,r,BC);
                [Fe]=F_ex_ES(g,z,Z,alphat,r,phi,phi0LV,sig,MSA,Fe,fe,BC);
                
                F_id(k)=Fe.id_legendre;
                F_FMT(k)=Fe.ex_FMT;
                F_ESc(k)=Fe.ex_ESc;
                F_ESC(k)=Fe.ex_ESC;
                
                Om(k)=sum(structfun(@(x)x, Fe));
                Om2(k)=Om(k)-Fe.ex_ESC_wall;
                
                k=k+1;
                % Break loop when not converging
                if k>1000000||(abs(err.dg(k-2))/10^(err.a0(k-2))<1e-50&&abs(err.dg(k-1))/10^(err.a0(k-2))<1e-50&&(a00)>-15&&~isinf(log10(abs(err.dg(k-1))))&&k>200)
                    break
                end
                
                if mod(k,100)==0
                    clc;disp({'log10(error)=',num2str(err.g(k-1));...
                        'log10(errormid)=',num2str(err.gm(k-1));...
                        'picard',num2str(log10(a0));...
                        'surface ES',[num2str(v0) '/'  num2str(nV)];...
                        'concentration',[num2str(c0) '/'  num2str(length(sys.eta))];...
                        'sys.zmax',[num2str(z0) '/'  num2str(length( sys.zmax))]});
                end
                
                %                                 figure(123213213);semilogy(z,abs(c1ES(1,:)-c1ESb(1)),z,abs(c1chain(4,:)-c1chainb(4)))
                
            end
            
            
            
            %             catch ME
            %                 disp('oopsy')
            %                 warning(ME.message)
            %             end
            %
            %% Thermodynamic quantities
            
            % Debye Length
            K(c0)=sqrt(4*pi*lambda*sum(Z.^2.*alphat.*r.^3));
            
            alphas(:,c0)=alphat;
            mu_ex(:,c0)=-c1b;
            mu_es_ES(:,c0)=-c1ESb;
            mu(:,c0)=log(alphat.*r.^3)'+mu_ex(:,c0);
            
            [F,f,p_HS_id]=F_id_ex_FMT(PhiFMT,g,c1,alphat,d,r,BC);
            [F,f,p_ES]=F_ex_ES(g,z,Z,alphat,r,phi,phi0LV,sig,MSA,F,f,BC);
            
            if length(sys.zmax)==1
                %local Grand potential density
                omegaz(1:length(f.id_FMT),v0,c0,z0)=f.id_FMT+f.ex_ES;
                %Density Profiles
                gf(:,1:size(g,2),v0,c0,z0)=g;
                gN(:,v0,c0,z0)=(alphat.*r.^3)*(g-1)/alphat(1);
                gQ(:,v0,c0,z0)=(alphat.*Z.*r.^3)*g/alphat(1);
                %Potential Profile
                Phif(1:size(g,2),v0,c0,z0)=phi/beta/el;
            else
                %local Grand potential density
                omegaz(1:length(f.id_FMT),v0,c0,z0)=f.id_FMT+f.ex_ES;
                %Density Profiles
                gf(:,1:size(g,2),v0,c0,z0)=g;
                %Potential Profile
                Phif(1:size(g,2),v0,c0,z0)=phi/beta/el;
            end
            
            %surface charge
            sigma(:,v0,c0,z0)=sig';
            
            %surface potential
            phi0(:,v0,c0,z0)=phi0LV';
            %             if strcmp(BC.type,'DD')
            %                 phi0(v0,c0,z0)=BC.phiV(v0);
            %             else
            %                 phi0(v0,c0,z0)= interp1(z,phi,0,'spline','extrap');
            %             end
            
            %Contact presure
            pcontl=0;
            ap=1;
            for j=1:length(r)
                pcontl=pcontl+alphat(j)*r(j)^3*(...
                    ap*interp1(z(round(1/d/2/r(j))+1:round(N/2)),g(j,round(1/d/2/r(j)+1):round(N/2)),1/2/r(j),'pchip','extrap')+...
                    (1-ap)*interp1(z(round(1/d/2/r(j))+1:round(N/2)),g(j,round(1/d/2/r(j)+1):round(N/2)),1/2/r(j),'spline','extrap'));
            end %note here that spline overestimates and pchip mostly underestimates the contact value, thus the mixing.
            pcontl=pcontl-2*pi*lambda*sigma(1,v0,c0,z0)^2;
            
            pcontr=0;
            ap=0.5;
            for j=1:length(r)
                pcontr=pcontr+alphat(j)*r(j)^3*(...
                    ap*interp1(z(round(1/d/2/r(j))+1:round(N/2)),g(j,round(1/d/2/r(j)+1):round(N/2)),1/2/r(j),'pchip','extrap')+...
                    (1-ap)*interp1(z(round(1/d/2/r(j))+1:round(N/2)),g(j,round(1/d/2/r(j)+1):round(N/2)),1/2/r(j),'spline','extrap'));
            end
            pcontr=pcontr-2*pi*lambda*sigma(2,v0,c0,z0)^2;
            
            ptcontactl=pcontl;
            ptcontactr=pcontr;
            
            %Adsorption
            GamAds(:,v0,c0,z0)=d*alphat'.*r'.^3.*(sum(g-1,2));
            for jG=1:nu
                GamAdsR(jG,v0,c0,z0)=d*alphat(jG).*r(jG).^3.*(sum(g(jG,round(1/r(jG)/2/d+1):N-round(1/r(jG)/2/d))-1,2));
            end
            
            % Grand potential
            Omega(v0,c0,z0)=sum(structfun(@(x)x, F));
            Fhelm(v0,c0,z0)=F.ex_FMT+F.ex_ESC+F.ex_ESc+F.ex_ESu;
            
            %Surface Tension
            surftens(v0,c0,z0)=Omega(v0,c0,z0)+ptbulk*sys.zmax(z0);
            
            
            pHSFMT(v0,c0)=ptHSFMT;
            pESu(v0,c0)=MSA.pu;
            pESc(v0,c0)=MSA.pc;
            pchain(v0,c0)=ptchain;
            pbulkomega(v0,c0)=ptbulkomega;
            pbulk(v0,c0)=ptbulk;
            pcontactl(v0,c0)=ptcontactl;
            pcontactr(v0,c0)=ptcontactr;
            pmidsys(v0,c0)=p_HS_id+p_ES;
            
        end
    end
    
    p.HSFMT(:,:,z0)=pHSFMT;
    p.ESu(:,:,z0)=pESu;
    p.ESc(:,:,z0)=pESc;
    p.chain(:,:,z0)=pchain;
    p.bulkomega(:,:,z0)=pbulkomega;
    p.bulk(:,:,z0)=pbulk;
    p.contactl(:,:,z0)=pcontactl;
    p.contactr(:,:,z0)=pcontactr;
    p.midsys(:,:,z0)=pmidsys;
end

%% Differential Capacitance
try
    if size(gf,3)>1
        for j=1:size(gf,4)%concentrations c0
            for k=1:size(gf,5)%system sizes z0
                Cdd=diff(sigma(:,:,j,k),[],2)'./(diff(phi0(:,:,j,k),[],2))';
                CdL(:,j,k)=interp1(phi0(1,1:size(gf,3)-1,j,k)+0.5*diff(phi0(1,:,j,k),[],2),Cdd(:,1),phi0(1,:,j,k),'spline','extrap');
                CdR(:,j,k)=interp1(phi0(2,1:size(gf,3)-1,j,k)+0.5*diff(phi0(2,:,j,k),[],2),Cdd(:,2),phi0(2,:,j,k),'spline','extrap');
                %
                CdL2(:,j,k)=gradient(sigma(1,:,j,k))./gradient(phi0(1,:,j,k));
                CdR2(:,j,k)=gradient(sigma(2,:,j,k))./gradient(phi0(2,:,j,k));
            end
        end
    end
catch
end

%% Define output
data.g=gf;
data.phi=Phif;
data.p=p;
data.GamAds=GamAds;
data.sys=sys;
data.sigma0=sigma;
data.phi0=phi0;
data.z=z;
% data.alpha=alphat;

%% Save data
% filename='test';
% save(['C:\Users\peter\surfdrive\PhD\MATLAB\DFT_ILs_runscript\data\' filename])
if strcmp(sys.save,'on')
    
    
    DFTtype=['FMT_' dft.HS '_ESc_' dft.ESc  '_ESu_' dft.ESu];
    
    if isempty(sys.savetext)
        precursor='';
    else
        precursor=sys.savetext;
    end
    
    if strcmp(dft.LJ,'on')
        DFTtype=[DFTtype '_LJ_' strrep(num2str(LJ.eLJ(1,:)),' ','_') '_' strrep(num2str(LJ.eLJw(1,:)),' ','_') '_'];
    end
    
    if strcmp(dft.TPT1,'on')
        DFTtype=[DFTtype '_TPT1_' num2str(sys.M) '_'];
    end
    
    if sys.M==0
        Zstring=num2str(sys.Zhs);
        rstring=num2str(sys.rhs);
        cstring=num2str(c);
    elseif sys.nhs==0
        Zstring=['Zc_' num2str(sys.Zc(1))];
        rstring=['rc_' num2str(sys.rc(1))];
        cstring=num2str(c);
    else
        Zstring=['Zhs_' num2str(sys.Zhs) '_Zc_' num2str(sys.Zc(1))];
        rstring=['rhs_' num2str(sys.rhs) '_rc_' num2str(sys.rc(1))];
        cstring=num2str(c);
    end
    
    format shortE
    
    if strcmp(packing,'on')
        if length(eta)==1
            constr=['_eta_' num2str(sys.eta(1))];
        else
            constr=['_eta_' num2str(sys.eta(1)) '_' num2str(sys.eta(length(sys.eta)))];
        end
    else
        constr=['_c_' cstring];
    end
    
    if strcmp(BC.type,'DD')
        if length(BC.phiV)>2
            phistring=['_phi0_' num2str(BC.phiV(1)) '_' num2str(BC.phiV(length(BC.phiV)))];
        else
            phistring=['_phi0_' num2str(BC.phiV)];
        end
    else
        if length(BC.sigma0)>2
            phistring=['_sigma0_' num2str(BC.sigma0(1)) '_' num2str(BC.sigma0(length(BC.sigma0)))];
        else
            phistring=['_sigma0_' num2str(BC.sigma0)];
        end
    end
    
    if length(sys.zmax)>1
        zmaxstring=[num2str(sys.zmax(1)) '_' num2str(sys.zmax(end))];
    else
        zmaxstring=num2str(sys.zmax(1));
    end
    
    filename=[precursor '_R_0' num2str(round(sys.Rreal*100))...
        '_Nhs_' num2str(sys.nhs)...
        '_M_' num2str(sys.M)...
        '_r_' rstring...
        '_Z_' Zstring...
        phistring...
        constr...
        '_zmax_' zmaxstring...
        '_ngrid_' num2str(sys.ngrid)...
        '_lambdaB_' num2str(lambda*2*sys.Rreal)...
        '_' DFTtype '_' ...
        datestr(now, 'yyyy_mm_dd')];
    while contains(filename,'  ')
        filename=strrep(filename,'  ',' ');
    end
    filename=strrep(strrep(filename,'.',''),' ','_');
    save(['data\' filename])
end


end