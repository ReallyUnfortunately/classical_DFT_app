function [c1ESb,MSA]=ESb(Z,alpha,lambda,r,d,dft)
if nnz(Z)>1
    
    
    %% calculating Gamma Bulk
    
    %first guess gamma bulk
    q2b=sum(Z.^2.*alpha.*r.^3);
    o=1/length(r)*sum(1./r);
    Gammab=1/2/o.*(sqrt(1+4*o*sqrt(pi*lambda*q2b))-1);
    
    error=1;
    while error>1e-10
        Gamma0b=Gammab;
        Hb=sum(alpha./(1+Gamma0b./r))+2/pi*(1-pi/6*sum(alpha));
        etab=1/Hb*(Z.*r.^2*(alpha./(1+Gamma0b./r))');
        Gammab=sqrt(pi*lambda*r.^3*(alpha.*((Z-etab./r.^2)./(1+Gamma0b./r)).^2)');
        error=max(abs(Gammab-Gamma0b));
    end
    
    
    MSA.Gammab=Gammab;
    MSA.etab=etab;
    
    %% Derivative of Gamma bulk
    %     dGammab=1/2*pi*lambda*Z.^2.*r.^3./(sqrt(1+4*o*sqrt(pi*lambda*q2b)).*sqrt(pi*lambda*q2b));
    dGammab=pi/2*lambda*Z.^2./(sqrt(1+4*o*sqrt(pi*lambda*q2b)).*sqrt(pi*lambda*q2b));
    dGamma0b=dGammab;
    error=1;
    agam=0.5;
    
    while max(error)>1e-10
        dGamma0b=(1-agam)*dGamma0b+agam*dGammab;
        dHb=1./r.^3./(1+Gammab./r)-sum(alpha./r./(1+Gammab./r).^2).*dGamma0b-1/3./r.^3;
        detab=-dHb./Hb.*etab...
            +1./Hb.*(Z./r./(1+Gammab./r))...
            -1./Hb.*sum(Z.*r.*alpha./(1+Gammab./r).^2).*dGamma0b;
        dGammab=pi*lambda./Gammab.*(1/2*((Z-etab./r.^2)./(1+Gammab./r)).^2 ...
            -sum(alpha.*r.^2.*(Z-etab./r.^2).^2./(1+Gammab./r).^3).*dGamma0b ...
            -sum(r.*alpha.*(Z-etab./r.^2)./(1+Gammab./r).^2).*detab);
        error=sum(abs(dGammab-dGamma0b));
    end
    
    MSA.dGammab=dGammab;
    MSA.detab=detab;
    
    %% Calculating free energy density MSA and pressure
   if strcmp(dft.ESu(1:2),'MS')
        MSA.Phib=-lambda*sum(alpha.*r.^3.*(Z.^2*Gammab+Z.*etab./r)./(1+Gammab./r))+Gammab.^3/(3*pi);
        MSA.pu=-Gammab^3/3/pi-2*lambda*etab^2/pi;
    else
        MSA.Phib=0;
        MSA.p=0;
    end
    
    
    %% Chemical potential MSA
    
    dPhib=-lambda*(Z.^2*Gammab+Z.*etab./r)./(1+Gammab./r)...
        -lambda*sum(r.*alpha.*etab.*(Z-etab./r.^2)./(1+Gammab./r).^2).*dGammab...
        -lambda*sum(r.^2.*alpha.*Z./(1+Gammab./r)).*detab;
    c1MSAub=-dPhib;
    
    %% WDA-like formulation with F=int rho Phi(n)
    
    PhiMSApcb=(Z.^2.*Gammab+(Z./r).*etab)./(1+Gammab./r)-Gammab/3.*(Z-etab./r.^2).^2./(1+Gammab./r).^2;
    dPhiMSApcb=((Z-etab./r.^2)./(1+Gammab./r).^2.*(Z+1/3*(Z-etab./r.^2).*(Gammab./r-1)./(1+Gammab./r)))'.*dGammab +...
        +(Z./r./(1+Gammab./r).*(1+2*Gammab./(3*Z.*r).*(Z-etab./r.^2)./(1+Gammab./r)))'.*detab;
    muMSApc=-lambda*PhiMSApcb-lambda*(alpha.*r.^3)*dPhiMSApcb;
    c1MSA_WDAb=-muMSApc;
    
    %% MSA parameters
    
    %Shell Radius
    b=((1./r/2+1/2/Gammab)/d)*d;
    MSA.b=b;
    
    % Effective charge Zeff
    X=(Z-etab./r.^2)./(1+Gammab./r);
    MSA.X=X;
    MSA.Zeffb=X;
    
    Nb=(X-Z).*r;
    MSA.Nb=Nb;
    
    % Parameters for direct correlation function c^(2)=lambda_B/r*(L0+L1*r+L2*r^2+L4*r^4)
    MSA.L0=-(1./r-1./r').^2/4.*(etab*(X+X')+1/4*(etab^2*(1./r-1./r').^2-4*Nb.*Nb'));
    MSA.L1=-((X-X').*(Nb-Nb')+(X.^2+X'.^2)*Gammab+(1./r+1./r').*(Nb.*Nb')-1/3*etab^2*(1./r.^3+1./r'.^3));
    MSA.L2=-etab*(X+X')+(Nb.*Nb')-1/2*etab^2*(1./r.^2+1./r'.^2);
    MSA.L4=1/3*etab^2;
    
    % MSA direct correlation function [K. Hiroike, Mol. Phys. 33, 1195
    % (1977)]
    c1MSAcb=zeros(1,length(r));
    c2MSAcb=zeros(length(r),length(r));
    cMSAsh=zeros(length(r),length(r));
    
    for i=1:length(r)
        for j=1:length(r)
            Ddif=max(abs(1/r(j)-1/r(i))/2,0);
            Dsum=(1/r(j)+1/r(i))/2;
            
            cMSAsh(i,j)=2*lambda*(Z(i)*MSA.Nb(j)+MSA.etab/r(i)*(MSA.X(i)+1/3*MSA.etab/r(i)^2));
            
            c2MSAcb(i,j)=4*pi/3*Ddif^3*cMSAsh(i,j)+4*pi*lambda*(1/2*MSA.L0(i,j)*(Dsum^2-Ddif^2)+MSA.L1(i,j)/3*(Dsum^3-Ddif^3)+MSA.L2(i,j)/4*(Dsum^4-Ddif^4)+MSA.L4/6*(Dsum^6-Ddif^6))+2*pi*lambda*Z(i)*Z(j)*Dsum^2;
            c1MSAcb(i)=c1MSAcb(i)+c2MSAcb(i,j)*alpha(j)*r(j)^3;
        end
    end
    
    MSA.cMSAsh=cMSAsh;
    MSA.c2MSAcb=c2MSAcb;
    
    %% MSA direct correlation function from RPM [L. Blum and Y. Rosenfeld, J. Stat. Phys. 63, 1177 (1991)]
    
    B=b+b';
    BB=b'*b;
    RR=1/2*(1./r+1./r');
    
    MSA.c2MSAcRPMb=(Z'*Z).*pi*lambda./BB.*(RR.^4/4-2/3*RR.^3.*B+1/2*RR.^2.*B.^2);
    
    munonMSA=-pi/2*lambda*Z./b.*((Z.*alpha.*r.^3./b)*(2*RR.*(RR.^3/3-B.*RR.^2+B.^2.*RR)-RR.^4/6+2*B.*RR.^3/3-B.^2.*RR.^2));
    c1MSAcRPMb=-munonMSA;
    
    
    %% Define the bulk functional
    if strcmp(dft.ESc,'MSA')
        c1EScb=c1MSAcb;
        MSA.pc=-1/2*(alpha.*r.^3)*c2MSAcb*(alpha.*r.^3)';
        MSA.c2EScb=c2MSAcb;
    elseif strcmp(dft.ESc,'MSA_RPM')
        c1EScb=c1MSAcRPMb;
        MSA.pc=-1/2*(alpha.*r.^3)*MSA.c2MSAcRPMb*(alpha.*r.^3)';
        MSA.c2EScb=MSA.c2MSAcRPMb;
    else
        c1EScb=0;
        MSA.pc=0;
        MSA.c2EScb=zeros(length(r),length(r));
    end
    
    if strcmp(dft.ESu,'MSA')
        c1ESub=c1MSAub;
    elseif strcmp(dft.ESu,'MSA_WDA')
        c1ESub=c1MSA_WDAb;
    else
        c1ESub=0;
        MSA.Phib=0;
        MSA.pu=0;
    end
    
    MSA.c1EScb=c1EScb;
    MSA.c1ESub=c1ESub;
    
    c1ESb=c1EScb+c1ESub;
    
else
    c1ESb=0;
    
    MSA.c1MSAub=0;
    MSA.c1MSAcRPMb=0;
    MSA.c1MSA_WDAb=1;
    MSA.c2EScb=0;
    
    MSA.Phib=0;
    
    MSA.X=Z;
    MSA.N=zeros(1,length(r));
    MSA.L0=0;
    MSA.L1=0;
    MSA.L2=0;
    MSA.L4=0;
    
    MSA.b=1./r/2;
    MSA.Gammab=0;
    MSA.dGammab=0;
    MSA.PhiMSAb=0;
    MSA.pu=0;
    MSA.pc=0;
    MSA.Zeffb=0;
end