function         [a0,err]=apicard_conv(g,g_new,phi,phi_old,err,k,a0)
N=length(phi);
err.g(k)=log10(max(max(abs(g_new-g))));
err.dg(k)=err.g(k)-err.g(k-1);

err.gm(k)=log10(max(max(abs(g_new(:,round(N*3/8:N*5/8))-g(:,round(N*3/8:N*5/8))))));
err.dgm(k)=(err.gm(k))-(err.gm(k-1));
if isnan(err.dgm(k))
    err.dgm(k)=-15;
end


if (err.dg(k)>0&&err.dgm(k)>0)&&(log10(abs(err.dg(k)))>err.a0min||log10(abs(err.dgm(k)))>err.a0min)
    err.a0min=max(err.a0(k-1)-0.2,-5);
elseif k==2
    err.a0min=-1;
else
    err.a0min=min(-1,err.a0min+0.005);
end

nerr=10;
sdg=nnz(sign(err.dg(max(k-nerr+1:k,1)))+1);
sdgh=nnz(sign(err.dg(max(k-nerr:k-1,1)))+1);
sdgm=nnz(sign(err.dgm(max(k-nerr+1:k,1)))+1);
sdgmh=nnz(sign(err.dgm(max(k-nerr:k-1,1)))+1);

sd=min(sdg,sdgm);
sdh=min(sdgh,sdgmh);
ninc=0;

amin=-300;
aminend=-5+0.5*(tanh(-err.g(k)+1)+1);
amax=-3+1*(tanh(-0.2*err.g(k))+1);

dphi=max(abs(phi)-abs(phi_old));
phiav=mean(phi(round(N*3/8:N*5/8)));
dphiav=mean(abs(phi(round(N*3/8:N*5/8)))-abs(phi_old(round(N*3/8:N*5/8))));

drop=0.5;
nskip=10;

% if k==357
%     a0=-5;
% end

d=2;
c=d;
f=2;
if k<50
    f1=1;
else
    f1=4;
end

% if abs(dphi)>1
    b=1;
% else
%     b=5;
% end

if max(abs(phi))<1e-5
    minia=min([err.a0min,amax,a0+0.1]);
else
minia=min([err.a0min,amax,...
    d-max(err.g(k),err.gm(k)),...
    a0-dphi+b,...
    max(f+log10(abs(err.dgm(k))),-8)/2]);
end


if k>200
    meandec=log10(abs(mean(err.g(k-20:k))-mean(err.g(k-40:k-20))));
%     dgpeak=mean(abs(diff(err.g(k-100:k-1))));
else
    meandec=0;
end


if k<10&&phiav<1e-1&&dphiav<1e-1
    a0=-4;
% elseif sd>ninc&&(sd-sdh)>0
%     a0=a0-drop;
elseif round(err.skip)==1
    a0=max(a0+0.001,amin);
    err.skip=err.skip*0.5^(1/nskip);
elseif meandec<a0-1&&~isinf(meandec)
    a0=a0-1;
    err.skip=1;
elseif err.dgm(k)>0||dphiav>10^(-a0)
    a0=max([min(minia),amin]);
else
    a0=min(max([minia,aminend]),a0-dphi+b);
end


%     figure(123412343);plot(1:k,err.g,1:k,-err.a0);pause(0.01)
if err.g(k)<2
    a0=max(a0,-5);
end

a0=max(a0,-40);

err.a0(k)=a0;

% a0=min(a0,-5);
end