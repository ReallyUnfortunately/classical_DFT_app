[zG,wG]=legzo(N,0.5,sys.zmax-0.5);
QG=4*pi*lambda*interp1(z(1/d/2+1:N-1/d/2),(alphat.*r.^3.*Z)*g(:,1/d/2+1:N-1/d/2),zG,'spline');
% QG=[zeros(1,kies(1)-1) QG zeros(1,N-kies(end))];
dphiG=(BC.phiV*el*beta*BC.ratio*2+sum(wG.*(sys.zmax-zG).*QG))/sys.zmax;
% dphiG=1.01*dphi0;

for i=1:1/d/2
    phiG(i)=BC.phiV*el*beta+z(i)*dphiG;
end

for i=1/d/2+1:N-1/d/2
    [zzG,wwG]=legzo(max(i-1/d/2,100),0.5,z(i));
%      [zzG,wwG]=legzo(500,0.5,z(i));
    QG=-4*pi*lambda*interp1(z(1/d/2+1:max(i,1/d/2+3)),(alphat.*r.^3.*Z)*g(:,1/d/2+1:max(i,1/d/2+3)),zzG,'pchip');
    phiG(i)=BC.phiV*el*beta+z(i)*dphiG+sum(wwG.*(z(i)-zzG).*QG);
end

for i=N-1/d/2+1:N
    phiG(i)=BC.ratio*BC.phiV*el*beta+(z(i)-sys.zmax)*dphiG;
end


dphim=1/sys.zmax*(BC.phiV*(BC.ratio-1)*el*beta+d*sum((sys.zmax-z).*Q'));

for i=1:length(z)
phim(i)=BC.phiV*el*beta+z(i)*dphim-d*sum((z(i)-z(1:i)).*Q(1:i)');
end


tic
for llll=1:10000
                    if strcmp(BC.type,'DD')

                    phim=transpose(D2\(-B*Q-C));
                    phim(isnan(phim))=0;
                elseif strcmp(BC.type,'ND')

                    phim=transpose(D2\(-B*Q-C));
                    phim(isnan(phim))=0;
                    end
% time=0.645836
dphim=1/sys.zmax*(BC.phiV*(BC.ratio-1)*el*beta+d*sum((sys.zmax-z).*Q'));

for i=1:length(z)
phim(i)=BC.phiV*el*beta+z(i)*dphim-d*sum((z(i)-z(1:i)).*Q(1:i)');
end

end
toc