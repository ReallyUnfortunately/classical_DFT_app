L=12;
phic0=0.5;
[zG,wG]=legzo(1000,0.5,L-0.5);
QG=4*pi*lambda*interp1(zc,alphat(1)*(gc(:,2)-gc(:,1)),zG,'spline');
% QG=[zeros(1,kies(1)-1) QG zeros(1,N-kies(end))];
dphiG=(-2*phic0*el*beta+sum(wG.*(L-zG).*QG))/L;
% dphiG=1.01*dphi0;

for i=1:length(zc)
    [zzG,wwG]=legzo(500,0.5,zc(i));
    QG=-4*pi*lambda*interp1(zc(1:max(i,3)),alphat(1)*(gc(1:max(i,3),2)-gc(1:max(i,3),1)),zzG,'pchip');
    phiGc(i)=phic0*el*beta+zc(i)*dphiG+sum(wwG.*(zc(i)-zzG).*QG);
end


%%
zc=cheng(:,1)+0.5;
Qc=4*pi*lambda*(-cheng(:,2)+cheng(:,3));
dphic=1/sys.zmax*(BC.phiV*(BC.ratio-1)*el*beta+d*sum((sys.zmax-zc).*Qc));

for i=1:length(zc)
phic(i)=BC.phiV*el*beta+zc(i)*dphic-d*sum((zc(i)-zc(1:i)).*Qc(1:i));
end

%%

zc2=[0.05:0.05:0.45 zc' zc(end)+0.05:0.05:zc(end)+0.5-0.05];
Qc2=-[zeros(1/0.05/2-1,1); Qc; zeros(1/0.05/2-1,1)];
[~ ,D2c,Bc,Cc]=ESBC(BC,zc2,0.05,beta,el,1);
D2c(1,1)=-2/0.05^2;
D2c(length(zc2),length(zc2))=-2/0.05^2;
Cc(1)=-BC.phiV*el*beta/0.05^2;
Cc(end)=-BC.ratio*BC.phiV*el*beta/0.05^2;
phic2=transpose(D2c\(-Bc*Qc2-Cc));
