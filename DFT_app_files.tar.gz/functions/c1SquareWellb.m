function c1SWb=c1SquareWellb(y,eSW,alpha,R,r)
c1SWb=zeros(1,length(R));
for i=1:length(r)
    for j=1:length(r)
        c1SWb(i)=c1SWb(i)+sum(4/3*pi*(y^3-1)*eSW(i,j).*(R(i)+R(j)).^3.*alpha(j).*r(j).^3);
    end
    
end
end