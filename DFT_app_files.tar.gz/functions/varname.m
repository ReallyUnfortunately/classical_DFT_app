function out=varname(x)

out=inputname(1);
end