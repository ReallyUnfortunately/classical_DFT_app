function G=connectivity(c1,c1b,V_ext,sys,r,z,d,rigid,theta0)

%% Connectivity
M=sys.M;
nhs=sys.nhs;

sigma1=1/r(nhs+1);
N=length(V_ext);

L=-c1+V_ext+c1b';

if strcmp(rigid,'on')
    
    dtheta=1/100;
    theta=0:2*pi*dtheta:2*pi-dtheta;
    
    G.L=zeros(M-1,N,N);
    G.R=zeros(M-1,N,N);
    G.L1=zeros(M-1,N,N);
    
    G.L(1,:,:)=1;
    G.R(M-1,:,:)=1;
    G.L1(1,:,:)=1;
    G.tot=zeros(M,N);
    
    
    for j=2:M-1
        for o=1:N
            for p=max(1,o-1/r(nhs+1)/d):min(N,o+1/r(nhs+1)/d)
                zl=z(o)+(1-cos(theta0))*(z(p)-z(o))-sin(theta0)*cos(theta)*sqrt(1/r(nhs+1)^2-(z(p)-z(o))^2);
                zr=z(p)+(1-cos(theta0))*(z(o)-z(p))-sin(theta0)*cos(theta)*sqrt(1/r(nhs+1)^2-(z(p)-z(o))^2);
                
                
                Nl=round(zl/d+1/2);
                Nl(Nl<1)=1;
                Nl(Nl>N-1)=N;
                Nr=round(zr/d+1/2);
                Nr(Nr<1)=1;
                Nr(Nr>N-1)=N;
                
                G.L(j,o,p)=dtheta*exp(-L(nhs+j-1,Nl))*G.L(j-1,Nl,o)';
                G.R(M-j,o,p)=dtheta*exp(-L(nhs+M-j+1,Nr))*squeeze(G.R(M-j+1,p,Nr));
                G.L1(j,o,p)=dtheta*exp(-L(nhs+j,Nr))*squeeze(G.L1(j-1,Nr,o))';
            end
        end
        
        G.tot(j,:)=d/2*r(nhs+1)*diag(squeeze(G.L(j,:,:))*diag(exp(-L(nhs+j+1,:)))*(squeeze(G.R(j,:,:)))');
        G.tot(j,:)=smooth(G.tot(j,:));
    end
    G.tot(1,:)=d/2*r(nhs+1)*diag(squeeze(G.L(1,:,:))*diag(exp(-L(nhs+1+1,:)))*squeeze(G.R(1,:,:))');
    G.tot(M,:)=d/2*r(nhs+1)*diag(squeeze(G.L1(M-1,:,:))*diag(exp(-L(nhs+M-1,:)))*squeeze(G.R(M-1,:,:))');
else
    
    
    G.L=zeros(M,N);
    G.R=zeros(M,N);
    
    G.L(1,:)=1;
    G.R(1,:)=1;
    
    
    nR=floor(sigma1/d);
    Wf=zeros(1,2*N-1);
    Wf(N-nR:N+nR)=1/2/sigma1;
    Wf([N-nR N+nR])=Wf([N-nR N+nR])/2;
    
    for j=2:M
        G.L(j,:)=d*conv(exp(-L(nhs+j-1,:)).*G.L(j-1,:),Wf,'same');
        G.R(j,:)=d*conv(exp(-L(nhs+M-j+2,:)).*G.R(j-1,:),Wf,'same');
    end
    
end
end