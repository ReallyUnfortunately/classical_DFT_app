function [phi, D2, B, C]=ESBC(BC,z,d,beta,el,v0)
N=length(z);
zmax=max(z);
phi=zeros(1,length(z));
if strcmp(BC.type,'DD')
    % Dirichlet-Dirichlet BC
    C=zeros(N,1);
    C(1,:)=2*BC.phiV(v0)*el*beta/d^2; %potential at the wall left
    C(N,:)=2*BC.ratio*BC.phiV(v0)*el*beta/d^2; %potential at the wall right
    
%     phi=cosh(z-zmax/2)*BC.phiV(v0)*el*beta/cosh(-zmax/2);%Trial potential profile used in initial density profile
    phi=zeros(1,length(z));
    
    %Differential operator
    e=ones(N,1);
    D2=1/d^2*spdiags([e -2*e e],-1:1,N,N); %Tridiagonal matrix for Laplacian
    D2(1,1)=-3/d^2; %corrections for chosing gridpoints at z_i=d*(i-1/2)
    D2(N,N)=-3/d^2;
    B=spdiags(e,0,N,N)+D2*d^2/12; %second term is for second order corrections to the Laplacian
    %         B=spdiags(e,0,N,N); %second term is for second order corrections to the Laplacian
    
elseif strcmp(BC.type,'ND')
    %Neumann-Dirichlet BC with zero potential on the right side of the
    %system
    %Differential operator
    e=ones(N,1);
    D2=1/d^2*spdiags([e -2*e e],-1:1,N,N);
    D2(1,1)=-1/d^2;
    D2(N,N)=-3/d^2;
    B=spdiags(e,0,N,N)+D2*d^2/12;
    
    sigma0=BC.sigma0(v0); %Converting C/m^2 to e/(D)^2
    
    C=zeros(N,1); % Boundary condition vector
    C(1,:)=sigma0/d;%charge density sigma on left side and zero potential on right side of the system
    C(N,:)=0;
    
    phi=zeros(1,length(z));
    
%     phi=0.1*(sign(BC.sigma0(v0))*exp(-z));
    
elseif strcmp(BC.type,'NN')
    e=ones(N+1,1);
    D2=1/d^2*spdiags([e -2*e e],-1:1,N+1,N+1);
    D2(1,1)=-1/d^2;
    D2(N,N)=-1/d^2;
    D2(N+1,N:N+1)=0;
    D2(1:N,N+1)=1;
    D2(N+1,1:N)=1;
    
    B=spdiags(e,0,N+1,N+1)+D2*d^2/12;
    
    sigma0=BC.sigma0(v0); %Converting C/m^2 to e/(D)^2
    
    C=zeros(N,1); % Boundary condition vector
    C(1,:)=sigma0/d;%charge density sigma on left side and zero potential on right side of the system
    C(N,:)=sigma0/d*BC.ratio;
    lagrangemult=0;
    C(N+1,:)=lagrangemult;
    
    phi=(sign(BC.sigma0(v0))*exp(-z)+BC.ratio*sign(BC.sigma0(v0))*exp(-(z(end)-z)));
    
    
    
else
    phi=zeros(1,N);
    C=zeros(N,1);
    B=zeros(N,N);
    D2=zeros(N,N);
end