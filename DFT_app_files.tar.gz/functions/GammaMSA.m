function [Gammalog, dGamma, eta, det, H]=GammaMSA(alpha,Z,r,lambda)
alph=max(alpha)*linspace(1e-7,5,500);
% alph=max(alpha)'*logspace(-7,log10(10),1000);

nu=length(r);

%% Calculating space dependent Gamma
o=1/length(r)*sum(1./r);

if nu==2
    for j=1:length(alph)
        q2=alph(j).*Z(1)'.^2.*r(1)'.^3+alph.*Z(2)'.^2.*r(2)'.^3;
        q2(abs(q2)<1e-15)=0;
        Gamma=1/2/o*(sqrt(1+4*o*sqrt(pi*lambda*q2))-1);
        Gamma0=Gamma;
        
        errorGam=1;
        a=0.1;
        while errorGam>1e-10
            Gamma0=a*Gamma+(1-a)*Gamma0;
            H=alph(j)./(1+Gamma0./r(1)')+alph./(1+Gamma0./r(2)')+...
                2/pi*(1-pi/6*(alph(j)+alph));
            eta=1./H.*(Z(1)'.*r(1)'.^2.*alph(j)./(1+Gamma0./r(1)')+Z(2)'.*r(2)'.^2.*alph./(1+Gamma0./r(2)'));
            Gamma=sqrt(pi*lambda*(r(1)'.^3.*alph(j).*((Z(1)'-eta./r(1)'.^2)./(1+Gamma0./r(1)')).^2+...
                r(2)'.^3.*alph.*((Z(2)'-eta./r(2)'.^2)./(1+Gamma0./r(2)')).^2));
            errorGam=max(abs(Gamma-Gamma0));
        end
        
        Gammsa(j,:)=Gamma;
        Hmsa(j,:)=H;
        etamsa(j,:)=eta;
        
        
        %% Calculating space dependent derivative of Gamma wrt q_i
        dGamma=1/2*pi*lambda*Z'.^2.*r'.^3./(sqrt(1+4*o*sqrt(pi*lambda*q2)).*sqrt(pi*lambda*q2).*ones(length(r),length(q2)));
        dGamma0=dGamma;
        errorGam=1;
        errorGamp=2;
        a=0.75;
        while errorGam>1e-8&&abs(errorGamp-errorGam)>1e-15
            dGamma0=(1-a)*dGamma0+a*dGamma;
            dH=1./(1+Gamma./r')-(alph(j)./r(1)'./(1+Gamma./r(1)').^2+alph./r(2)'./(1+Gamma./r(2)').^2).*dGamma0-1/3;
            det=-dH./H.*eta...
                +1./H.*(Z'.*r'.^2./(1+Gamma./r'))...
                -1./H.*(Z(1)'.*r(1)'.*alph(j)./(1+Gamma./r(1)').^2+Z(2)'.*r(2)'.*alph./(1+Gamma./r(2)').^2).*dGamma0;
            dGamma=pi*lambda./Gamma.*(1/2*r'.^3.*((Z'-eta./r'.^2)./(1+Gamma./r')).^2 ...
                -(r(1)'.^2.*alph(j).*(Z(1)'-eta./r(1)'.^2).^2./(1+Gamma./r(1)').^3+...
                  r(2)'.^2.*alph.*(Z(2)'-eta./r(2)'.^2).^2./(1+Gamma./r(2)').^3).*dGamma0 ...
                -(r(1)'.*alph(j).*(Z(1)'-eta./r(1)'.^2)./(1+Gamma./r(1)').^2+...
                  r(2)'.*alph.*(Z(2)'-eta./r(2)'.^2)./(1+Gamma./r(2)').^2).*det);
            
            errorGamp=errorGam;
            errorGam=max(max(abs(dGamma-dGamma0)));
        end
        
        
        dGamma(isnan(dGamma))=0;
        det(isnan(det))=0;
        
        dGammsa(:,:,j)=dGamma;
        detamsa(:,:,j)=det;
    end
    
    
end

[xData, yData, zData]=prepareSurfaceData( log(alph), log(alph), log(Gammsa)' );
Gammalog=fit([xData,yData],zData,'cubicinterp');

[xData, yData, zData]=prepareSurfaceData( log(alph), log(alph), (squeeze(dGammsa(1,:,:)))' );
dGam{1}=fit([xData,yData],zData,'cubicinterp', 'Normalize', 'on' );

[xData, yData, zData]=prepareSurfaceData( log(alph), log(alph), (squeeze(dGammsa(2,:,:)))' );
dGam{2}=fit([xData,yData],zData,'cubicinterp', 'Normalize', 'on' );

[xData, yData, zData]=prepareSurfaceData( (alph), (alph), etamsa' );
eta=fit([xData,yData],zData,'cubicinterp', 'Normalize', 'on' );

[xData, yData, zData]=prepareSurfaceData( (alph), (alph), squeeze(detamsa(1,:,:))' );
deta{1}=fit([xData,yData],zData,'cubicinterp', 'Normalize', 'on' );

[xData, yData, zData]=prepareSurfaceData( (alph), (alph), squeeze(detamsa(2,:,:))' );
deta{2}=fit([xData,yData],zData,'cubicinterp', 'Normalize', 'on' );

[xData, yData, zData]=prepareSurfaceData( (alph), (alph), Hmsa' );
H=fit([xData,yData],zData,'cubicinterp', 'Normalize', 'on' );



end
