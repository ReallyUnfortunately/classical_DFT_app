function [c]=ESMFC(g,Z,alpha,lambda,N,d,R)
k=sqrt(4*pi*lambda*sum(Z.^2.*alpha));
xi=k./r;
B=(xi+1-sqrt(1+2*xi))./xi;
dc=zeros(2*N-1,1);
nd=1./r/d;
zd=d*(-nd:nd);
dc(N-nd:N+nd)=-lambda*2*pi*(B./R*(1-zd.^2)-1/12*(B/R)^2*(1-abs(zd).^3)-1+abs(zd));
c=d*real(convnfft(gs*alphas,dc,'same')-d*conv(gb*alphab,dc,'same'));
end