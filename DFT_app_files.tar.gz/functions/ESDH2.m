function [c1ESDH2]=ESDH2(z,g,alphat,r,W,Z,lambda)
d=z(2)-z(1);
N=length(z);

q0=zeros(length(r),3*N-2);
Kb=sqrt(4*pi*lambda*Z.^2.*r.^3*alphat');
b=1./r/2+1./Kb;
% b=1./r/2;
% b=0.1;
Nb=ceil(b/d);

WF=zeros(length(r),2*N-1);
for j=1:length(r)
    WF(j,max(N-Nb(j)+1,1):min(N+Nb(j)-1,size(WF,2)))=1/(2*b(j));
            if d*sum(WF(j,:))-1<0 
                WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])=WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])-(d*sum(WF(j,:))-1)/2/d;
            else
                WF(j,[max(N-Nb(j)+1,1) min(N+Nb(j)-1,size(WF,2))])=WF(j,[max(N-Nb(j)+1,1) min(N+Nb(j)-1,size(WF,2))])-(d*sum(WF(j,:))-1)/2/d;
            end
    WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])=WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])-(d*sum(WF(j,:))-1)/2/d;
end

for j=1:length(r)
    q0(j,:)=d*(conv(g(j,:)*alphat(j)*r(j)^3,WF(j,:),'full'));
end

indnz=abs(q0)>1e-10;
Ntind=(length(q0(indnz))-N)/2;
zt=round(Ntind+1:length(q0(indnz))-Ntind);


for j=1:length(r)
    q(j,:)=q0(j,indnz(j,:));
end


%         q0=zeros(length(r),3*N-2);
%         for j=1:length(r)
%             %         q0(j,:)=alpha(j)*d*conv(g(j,:),WF(j,:),'same');
%             q0(j,:)=alpha(j)*d*conv(g(j,:),WF(j,:),'full');
%         end

K=sqrt(4*pi*lambda*Z.^2*q);

Phiu=-lambda/2*Z.^2*(q.*K./(1+K./r'/2))+K.^3/24/pi;
dK=2*pi*lambda*Z'.^2./K;
dPhiu=-lambda/2*Z'.^2.*K./(1+K./r'/2)-(lambda/2*Z.^2*(q./(1+K./r'/2).^2)-K.^2/8/pi).*dK;

% c1MFu=zeros(length(r),N);
for j=1:length(r)
    c1ESDH2(j,:)=-d*conv(dPhiu(j,:),WF(j,:),'full');
end

c1ESDH2=c1ESDH2(:,round(size(c1ESDH2,2)/2-N/2+1:size(c1ESDH2,2)/2+N/2));

