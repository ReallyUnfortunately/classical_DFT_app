function [dYdX, dYdXerr]=numdiff(Y,X)

if nargin~=2
    X=1:max(size(Y));
end

if size(X,1)>1
    X=X';
end

if size(X,1)>1
    error('X must be a vector')
end

dX=diff(X);
Nx=length(X);

if Nx~=size(Y,1) && Nx~=size(Y,2)
    error('Size mismatch between X and Y')
end



diagi=[-(2*dX(1)+dX(2))/(dX(1)*(dX(1)+dX(2))) -(dX(1:end-1)-dX(2:end))./(dX(1:end-1).*dX(2:end)) (dX(end-1)+2*dX(end))/(dX(end)*(dX(end-1)+dX(end)))];
diagim=[-dX(2:end)./(dX(1:end-1).*(dX(1:end-1)+dX(2:end))) -(dX(end)+dX(end-1))/(dX(end)*dX(end-1))];
diagip=[(dX(1)+dX(2))/(dX(1)*dX(2)) dX(1:end-1)./(dX(2:end).*(dX(1:end-1)+dX(2:end)))];
D1=diag(diagi)+diag(diagim,-1)+diag(diagip,1);
D1(1,3)=-dX(1)/((dX(1)+dX(2))*dX(2));
D1(end,end-2)=dX(end)/(dX(end-1)*(dX(end)+dX(end-1)));

% D1(6,4:7)=[dX(5)*dX(6)/(dX(4)*(dX(4)+dX(5))*(dX(4)+dX(5)+dX(6))) -(dX(4)+dX(5))*dX(6)/(dX(4)*dX(5)*(dX(4)+dX(6))) (dX(6)*(dX(4)+2*dX(5))-dX(5)*(dX(4)+dX(5)))/((dX(4)+dX(5))*dX(5)*dX(6)) (dX(4)+dX(5))*dX(5)/((dX(4)+dX(5)+dX(6))*(dX(5)+dX(6))*dX(6))];
% D1(7,5:8)=[dX(5)*dX(6)/(dX(4)*(dX(4)+dX(5))*(dX(4)+dX(5)+dX(6))) -(dX(4)+dX(5))*dX(6)/(dX(4)*dX(5)*(dX(4)+dX(6))) (dX(6)*(dX(4)+2*dX(5))-dX(5)*(dX(4)+dX(5)))/((dX(4)+dX(5))*dX(5)*dX(6)) (dX(4)+dX(5))*dX(5)/((dX(4)+dX(5)+dX(6))*(dX(5)+dX(6))*dX(6))];
% 
% D1(7,5:8)=[dX(6)*dX(7)/(dX(5)*(dX(5)+dX(6))*(dX(5)+dX(6)+dX(7))) -(dX(5)+dX(6))*dX(7)/(dX(5)*dX(6)*(dX(5)+dX(7))) (dX(7)*(dX(5)+2*dX(6))-dX(6)*(dX(5)+dX(6)))/((dX(5)+dX(6))*dX(6)*dX(7)) (dX(5)+dX(6))*dX(6)/((dX(5)+dX(6)+dX(7))*(dX(6)+dX(7))*dX(7))];

% diagi=[(dX(1).^3-(dX(1)+dX(2)).^3)/(dX(1).^2*(dX(1)+dX(2)).^2.*dX(2)) ...
%     -(dX(1:end-1).^3+dX(2:end).^3)./(dX(1:end-1).^2.*dX(2:end).^2.*(dX(1:end-1)+dX(2:end))) ...
%     (dX(end).^3-(dX(end-1)+dX(end)).^3)/(dX(end).^2.*dX(end-1)*(dX(end-1)+dX(end)).^2)];
% diagim=[dX(2:end)./(dX(1:end-1).^2.*(dX(1:end-1)+dX(2:end))) (dX(end)+dX(end-1))/(dX(end)^2*dX(end-1))];
% diagip=[(dX(1)+dX(2))/(dX(1)^2*dX(2)) dX(1:end-1)./(dX(2:end).^2.*(dX(1:end-1)+dX(2:end)))];
% D2=diag(diagi)+diag(diagim,-1)+diag(diagip,1);
% D2(1,3)=-dX(1)/((dX(1)+dX(2))^2*dX(2));
% D2(end,end-2)=-dX(end)/(dX(end-1)*(dX(end)+dX(end-1))^2);
% D2=D2-diag([(2*dX(1)+dX(2))/(dX(1)*(dX(1)+dX(2))) -(dX(1:end-1)-dX(2:end))./(dX(1:end-1).*dX(2:end)) -(2*dX(end)+dX(end-1))/(dX(end)*(dX(end)+dX(end-1)))])*D1;
% D2=D2*2;
% 
% diagi=[-(2*dX(1)+dX(2))*(dX(1)^2+(dX(1)+dX(2))^2)/(dX(1).^3*(dX(1)+dX(2)).^3)...
%     -(dX(1:end-1)-dX(2:end)).*(dX(1:end-1).^2+dX(2:end).^2)./(dX(1:end-1).^3.*dX(2:end).^3)...
%     (dX(end-1)+2*dX(end))*(dX(end)^2+(dX(end-1)+dX(end))^2)/(dX(end).^3*(dX(end-1)+dX(end)).^3)];
% diagim=[-dX(2:end)./(dX(1:end-1).^3.*(dX(1:end-1)+dX(2:end))) -(dX(end)+dX(end-1))/(dX(end)^3*dX(end-1))];
% diagip=[(dX(1)+dX(2))/(dX(1)^3*dX(2)) dX(1:end-1)./(dX(2:end).^3.*(dX(1:end-1)+dX(2:end)))];
% D3=diag(diagi)+diag(diagim,-1)+diag(diagip,1);
% D3(1,3)=-dX(2)/((dX(1)+dX(2))^3*dX(2));
% D3(end,end-2)=dX(end)/(dX(end-1)*(dX(end)+dX(end-1))^3);
% 
% D3=D3+diag([(dX(1)^3-(dX(1)+dX(2))^3)/(dX(1)^2*(dX(1)+dX(2))^2*dX(2))...
%     -(dX(1:end-1).^3+dX(2:end).^3)./(dX(1:end-1).^2.*dX(2:end).^2.*(dX(1:end-1)+dX(2:end)))...
%     (dX(end)^3-(dX(end)+dX(end-1))^3)/((dX(end)+dX(end-1))^2*dX(end)*dX(end-1))])*D1+...
%     diag([-(2*dX(1)+dX(2))/(dX(1)*(dX(1)+dX(2))) -(dX(1:end-1)-dX(2:end))./(dX(1:end-1).*dX(2:end)) (2*dX(end)+dX(end-1))/(dX(end)*(dX(end)+dX(end-1)))])*D2;
% D3=D3*6;
% 
% Dfp=diag([-1/(dX(1)*(dX(1)+dX(2))) 1./(dX(1:end-1).*dX(2:end)) -1/(dX(end)*(dX(end)+dX(end-1)))]);

%%

if Nx==size(Y,1)
    dYdX=D1*Y;
    
    dYdXerr=diag([dX(1)*(dX(1)+dX(2)) dX(1:end-1).*dX(2:end) (dX(end-1)+dX(end))*dX(end)])*D1*D1*D1*Y/6;
else
    dYdX=D1*Y';
    
    dYdXerr=diag([-dX(1)*(dX(1)+dX(2)) dX(1:end-1).*dX(2:end) -(dX(end-1)+dX(end))*dX(end)])*(D1*D1*D1*Y')/6;
end






