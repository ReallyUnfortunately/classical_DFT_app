function c1LJ=c1LenJon(g,R,LJ,alpha,r,d)
N=length(g(1,:));
Wd=zeros(length(R),length(R),2*N-1);
zR=d*(-N+1:N-1);

if isinf(LJ.rc)
    for j=1:length(R)
        for i=1:length(R)
            nD=floor(LJ.dLJ(i,j)*2^(1/6*LJ.wca)/d);
            
            Wd(i,j,:)=2*pi*LJ.eLJ(i,j)*LJ.dLJ(i,j)^2*(2/5*(LJ.dLJ(i,j)./zR).^10-(LJ.dLJ(i,j)./zR).^4);
            
            Wd(i,j,N-nD:N+nD)=4*pi*LJ.eLJ(i,j)*LJ.dLJ(i,j)^2*(1/5*2^(-10/6*LJ.wca)-1/2*2^(-4/6*LJ.wca))+LJ.wca*(-pi*LJ.eLJ(i,j)*((LJ.dLJ(i,j)*2^(1/6*LJ.wca)).^2-zR(N-nD:N+nD).^2));
        
            Wd(i,j,:)=Wd(i,j,:)*(-32/9*pi*LJ.eLJ(i,j)*LJ.dLJ(i,j)^3)/(d*sum(Wd(i,j,:)));
        end
    end
else
    for j=1:length(R)
        for i=1:length(R)
            nD=floor(LJ.dLJ(i,j)/d);
            rc=min(LJ.rc,(N-1)*d);
            
            Wd(i,j,N-round(rc*nD):N-nD)=2*pi*LJ.eLJ(i,j)*LJ.dLJ(i,j)^2*...
                (2/5*((LJ.dLJ(i,j)./zR(N-round(rc*nD):N-nD)).^10-(1/rc)^10)...
                -((LJ.dLJ(i,j)./zR(N-round(rc*nD):N-nD)).^4-1/rc^4)+...
                2*((zR(N-round(rc*nD):N-nD)/LJ.dLJ(i,j)).^2-rc^2)*(1/rc^12-1/rc^6));
            Wd(i,j,N+nD:N+round(rc*nD))=2*pi*LJ.eLJ(i,j)*LJ.dLJ(i,j)^2*...
                (2/5*((LJ.dLJ(i,j)./zR(N+nD:N+round(rc*nD))).^10-(1/rc)^10)...
                -((LJ.dLJ(i,j)./zR(N+nD:N+round(rc*nD))).^4-1/rc^4)+...
                2*((zR(N+nD:N+round(rc*nD))/LJ.dLJ(i,j)).^2-rc^2)*(1/rc^12-1/rc^6));
            
            Wd(i,j,N-nD:N+nD)=2*pi*LJ.eLJ(i,j)*LJ.dLJ(i,j)^2*(2/5*(1-1/rc^10)-(1-1/rc^4)+...
                2*(1-rc^2)*(1/rc^12-1/rc^6));

            Wd(i,j,:)=Wd(i,j,:)*(-(32/9*pi*LJ.eLJ(i,j)*LJ.dLJ(i,j)^3*(1+1/2*1/rc^9-3/2*1/rc^3)+...
                16*pi/3*LJ.eLJ(i,j)*LJ.dLJ(i,j)^3*(rc^3-1)*(1/rc^12-1/rc^6)))/(d*sum(Wd(i,j,:)));
        end
    end
end
c1LJ=zeros(length(R),size(g,2));
for i=1:length(R)
    for j=1:length(R)
        c1LJ(i,:)=c1LJ(i,:)-d*conv((alpha(j).*r(j).^3)*g(j,:),squeeze(Wd(i,j,:)),'same');
    end
end
end