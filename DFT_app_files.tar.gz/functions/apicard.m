function         [a0, a0min,koops]=apicard(phi,phi_old,Z,errordisp,errordispmid,k,a0,a0min,koops)

%         figure(1313);semilogy(1:k,errordisp)
if nnz(Z)==0
    
    stoploop=0;
    nerr=8;
    derr=nnz(sign(diff(errordisp(max(k-nerr+1,1):k)))+1);
    a0minmax=10e-2;
    amin=100e-3;
    ndrop=10;
    if derr<1
        a0=min([0.5,a0min,a0*2,amin]);
        a0min=1.1*a0;
    elseif derr>0&&k-koops<=nerr
        a0=min([0.5,min(min(a0min,a0minmax),a0*ndrop^(1/(nerr-2))),amin]);
%         a0min=max(a0,a0minmax);

        if abs(log10(errordisp(k))-log10(errordisp(k-1)))<1e-3
            a0=a0*10;
        end
    elseif derr>0
        if k-koops<nerr+2
            a0min=min([a0/ndrop*2,a0minmax]);
        else
            a0min=min([a0/2,a0minmax]);
        end
        a0=a0/ndrop;
        koops=k;
    end
    
else
    
    stoploop=0;
    nerr=10;
    derrmax=nnz(sign(diff(errordisp(max(k-nerr+1,1):k)))+1);
    derrmid=nnz(sign(diff(errordispmid(max(k-nerr+1,1):k)))+1);
    errordiff=abs(log10(errordisp(k))-log10(errordisp(k-1)));
    derr=min(derrmax,derrmid);
    numpeak=0;
    a0minmax=5e-2;
    amin=5e-2;
    namin=50;
    a0minmult=1+1e-3;
    ndrop=10;
    
    if k==2
        a0=min(max(10^(-max(abs(phi))),1e-300),amin);
    elseif errordiff<1e-4
        a0=min(3*a0,amin);
        %         a0min=3*a0;
    elseif derr>numpeak&&k-koops<nerr
        a0=min([amin,a0min,a0*ndrop^(1/(nerr-1.1)),namin/errordisp(k)]);
    elseif max(abs(phi))>0&&derr<numpeak+1&&log10(errordisp(k))>1
        a0=max(min([amin,a0min,a0*2*10^(-max(abs(phi-phi_old))),namin/errordisp(k)]),1e-300);
        a0min=a0*4;
    elseif max(abs(phi))>0&&derr<numpeak+1&&log10(errordisp(k))<=1
        for ll=1:10
            if log10(errordisp(k))<=1-0.5*(ll-1)&&nnz(log10(errordisp(k))<=1-0.5*(ll-1))<20&&stoploop==0
                a0min=a0min*a0minmult;
                a0=max(min([amin,a0min,a0*5*10^(-max(abs(phi-phi_old))),namin/errordisp(k)]),1e-300);
                stoploop=1;
            elseif stoploop==0
                a0=max(min([amin,a0min,a0*5*10^(-max(abs(phi-phi_old))),namin/errordisp(k)]),1e-300);
                a0min=a0min*a0minmult;
            end
        end
        a0=max(a0,1e-4);
    elseif derr>numpeak&&log10(errordisp(k))<6
        if abs(a0min-a0)<1e-5
            a0min=min(0.5*a0,a0minmax);
        else
            a0min=min(a0*0.5,a0minmax);
        end
        a0=a0/ndrop;
        koops=k;
    else
        a0=max(min([amin,a0min,a0*20*10^(-max(abs(phi-phi_old))),namin/errordisp(k)]),1e-300);
%     else
%         if abs(mean(errordisp(k-nerr:k))-errordisp(k))<1e-2
%             a0=0.9*a0;
%         else
%             a0=min([amin,a0min,5./errordisp(k),a0*2]);
%             a0min=1.1*a0;
%         end
    end
end