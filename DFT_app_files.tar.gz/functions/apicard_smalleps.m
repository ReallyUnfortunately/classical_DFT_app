function         [a0, a0min,koops]=apicard(phi,phi_old,Z,errordisp,errordispmid,k,a0,a0min,koops)

%         figure(1313);semilogy(1:k,errordisp)
        if nnz(Z)==0
            
        stoploop=0;
        nerr=8;
        derr=nnz(sign(diff(errordisp(max(k-nerr+1,1):k)))+1);
        a0minmax=10e-3;
            if derr<2
                a0=min([0.5,a0min,a0*1.5]);
            elseif derr>1&&k-koops<nerr
                a0=min([0.5,max(a0min,a0minmax),a0*100^(1/nerr)]);
                a0min=max(a0,a0minmax);
            elseif derr>1
                a0min=max(1.1*a0,a0minmax);
                a0=a0/10;
                koops=k;
            end
            
        else
            
            stoploop=0;
            nerr=10;
            derrmax=nnz(sign(diff(errordisp(max(k-nerr,1):k)))+1);
            derrmid=nnz(sign(diff(errordispmid(max(k-nerr,1):k)))+1);
            derr=min(derrmax,derrmid);
            numpeak=0;
            a0minmax=1e-3;
            amin=3e-2;
            
            if k==2
                a0=min(max(10^(-max(abs(phi))),1e-300),amin);
            elseif derr>numpeak&&k-koops<nerr
                a0=min([amin,a0min,1*a0*100^(1/(nerr-1)),1/errordisp(k)]);
            elseif max(abs(phi))>0&&derr<numpeak+1&&log10(errordisp(k))>1
                a0=max(min([amin,a0min,a0*3*10^(-max(abs(phi-phi_old)))]),1e-300);
                a0min=a0min*1.001;
            elseif max(abs(phi))>0&&derr<numpeak+1&&log10(errordisp(k))<=1
                for ll=1:10
                    if log10(errordisp(k))<=1-0.5*(ll-1)&&nnz(log10(errordisp)<=1-0.5*(ll-1))<20&&stoploop==0
                        a0min=a0min*1.001;
                        a0=max(min([amin,a0min,a0*5*10^(-max(abs(phi-phi_old))),1/errordisp(k)]),1e-300);
                        stoploop=1;
                    elseif stoploop==0
                        a0=max(min([amin,a0min,a0*5*10^(-max(abs(phi-phi_old))),1/errordisp(k)]),1e-300);
                        a0min=a0min*1.001;
                    end
                end
                a0=max(a0,1e-4);
            elseif max(abs(phi))>0&&derr==nerr&&log10(errordisp(k))<1
                a0=max(min([amin,a0min,a0*3*10^(-max(abs(phi-phi_old)))]),1e-3);
                a0min=1.001*a0min;
            elseif max(abs(phi))>0&&derr>numpeak&&log10(errordisp(k))<6
                if abs(a0min-a0)<1e-5
                    a0min=max(0.9*a0,a0minmax);
                else
                    a0min=max(a0*0.9,a0minmax);
                end
                a0=a0/50;
                koops=k;
            elseif max(abs(phi))>0
                a0=max(min([amin,a0min,a0*20*10^(-max(abs(phi-phi_old))),1/errordisp(k)]),1e-300);
            end
        end
    
end