function dselection(source,event,ax,data,bg,dd_eta,dd_phi,dd_H)

etaplot=find(strcmp(dd_eta.Items,dd_eta.Value));
phiplot=find(strcmp(dd_phi.Items,dd_phi.Value));
Hplot=find(strcmp(dd_H.Items,dd_H.Value));

if strcmp(bg.SelectedObject.Text,'Density')
    p1=plot(ax,data.z,data.g(:,:,phiplot,etaplot,Hplot),'linewidth',1.5);
    ax.XLim=([0 max(data.z)]);
    ax.YLim=([0 1.1*max(max(data.g(:,:,phiplot,etaplot,Hplot)))]);
    ax.YLabel.String='$$\rho(x)/\rho_b$$';
    
                lgd=legend(p1);
            for ii=1:size(data.g(:,:,phiplot,etaplot,Hplot),1)
                lgd.String{ii}=['$$\rho_' num2str(ii) '/\rho_b$$'];
            end
            lgd.Interpreter='latex';
            lgd.Location='north';
else
    p1=plot(ax,data.z,data.phi(:,phiplot,etaplot,Hplot),'linewidth',1.5);
    ax.XLim=([0 max(data.z)]);
    ax.YLim=([1.1*min(0,min(data.phi(:,phiplot,etaplot,Hplot)))-1e-10 1.1*max(max(data.phi(:,phiplot,etaplot,Hplot)))+1e-10]);
    ax.YLabel.String='$$\Phi(x) [V]$$';
    
    lgd=legend(p1);
    lgd.Visible='off';
end
ax.TickLabelInterpreter='latex';
ax.FontSize=15;
ax.XLabel.String='$$x/d$$';
ax.XLabel.Interpreter='latex';
ax.YLabel.Interpreter='latex';
end