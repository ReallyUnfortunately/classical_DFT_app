function [nb, PCSB, PhiWBb]=WDFMTb(alpha,r,nhs,M,dft)

nb.n0=sum(alpha.*r.^3);
nb.n0s=sum(alpha(nhs+1:nhs+M).*r(nhs+1:nhs+M).^3);
nb.n1=1/2*sum(alpha.*r.^2);
nb.n2=pi*sum(alpha.*r);
nb.n3=pi/6*sum(alpha);

if ~strcmp(dft.HS,'RF')
    psip2=(6*nb.n3-3*nb.n3.^2+6*(1-nb.n3).*log(1-nb.n3))./nb.n3.^3;
    psip3=(6*nb.n3-9*nb.n3.^2+6*nb.n3.^3+6*(1-nb.n3).^2.*log(1-nb.n3))./(4*nb.n3.^3);
else
    psip2=0;
    psip3=0;
end

PhiWBb.t1=-nb.n0.*log(1-nb.n3);
PhiWBb.t2=(1+1/9*nb.n3.^2.*psip2).*(nb.n1.*nb.n2)./(1-nb.n3);
PhiWBb.t3=(1-4/9*nb.n3.*psip3).*(nb.n2.^3)./...
    (24*pi*(1-nb.n3).^2);
PhiWBb.tot=PhiWBb.t1+PhiWBb.t2+PhiWBb.t3;

PCSB=nb.n0/(1-nb.n3)+nb.n1*nb.n2*(1+1/3*nb.n3^2)/(1-nb.n3)^2+...
    nb.n2^3*(1-2/3*nb.n3+1/3*nb.n3^2)/(12*pi*(1-nb.n3)^3);
end