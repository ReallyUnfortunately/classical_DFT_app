function f=FFT(g)

[nc, Nz]=size(g);

if Nz>nc
    N=Nz;
    f=zeros(nc,N);
else
    N=nc;
    f=zeros(Nz,N);
    g=g';
    nc=Nz;
end

% Kx=2*pi*kx'/sys.zmax;
kx=(0:N-1);
x=(0:N-1);

Fexp=exp(2*pi/N*1i*kx'.*x);

for j=1:nc
    f(j,:)=sum(g(j,:).*Fexp,2);
end

