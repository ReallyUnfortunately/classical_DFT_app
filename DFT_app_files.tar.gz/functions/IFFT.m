function f=IFFT(g)

[nc, Nk]=size(g);

if Nk>nc
    N=Nk;
    f=zeros(nc,N);
else
    N=nc;
    f=zeros(Nk,N);
    g=g';
    nc=Nk;
end

% Kx=2*pi*kx'/sys.zmax;
kx=(0:N-1);
x=(0:N-1);

Fexp=exp(-2*pi/N*1i*kx'.*x);

for j=1:nc
    f(j,:)=sum(g(j,:)'.*Fexp);
end


