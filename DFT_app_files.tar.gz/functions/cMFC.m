function [c]=cMFC(g,Z,alpha,lambda,N,d,R,b)

k=sqrt(4*pi*lambda*sum(Z.^2.*alpha));
xi=2*k*R(1);
B=(xi+1-sqrt(1+2*xi))/xi;
B=1./b(1)/2;
dc=zeros(2*N-1,1);
nd=2*R(1)/d;
zd=d*(-nd:nd);
dc(N-nd:N+nd)=-lambda*2*pi*(B./R(1)/2*(1-zd.^2)-1/12*(B/R(1))^2*(1-abs(zd).^3)-1+abs(zd));
c(1,:)=d*conv(g(1,:)*alpha(1)*Z(1),dc,'same')+d*conv(g(2,:)*alpha(2)*Z(2),dc,'same');
c(2,:)=-c(1,:);
end