function [c1ESu,MSA,WF]=c1MSAu(alpha,Z,r,d,z,g,MSA,lambda,dft,errg)
c1ESu=zeros(length(r),length(z));

% Weight function
N=length(z);
b=MSA.b;
Nb=ceil(b/d);

NW=2*max(Nb)+1;
WF=zeros(length(b),NW);
for j=1:length(r)
    WF(j,(NW+1)/2-Nb(j)+1:(NW+1)/2+Nb(j)-1)=1/(2*b(j));
    if d*sum(WF(j,:))-1>0
        WF(j,[(NW+1)/2-Nb(j)+1 (NW+1)/2+Nb(j)-1])=WF(j,[(NW+1)/2-Nb(j)+1 (NW+1)/2+Nb(j)-1])-(d*sum(WF(j,:))-1)/2/d;
    else
        WF(j,[(NW+1)/2-Nb(j) (NW+1)/2+Nb(j)])=WF(j,[(NW+1)/2-Nb(j) (NW+1)/2+Nb(j)])-(d*sum(WF(j,:))-1)/2/d;
    end
end


if nnz(Z)>1
    if strcmp(dft.ESu(1:2),'MS') %when you want to include an internal energy contribution to the electrostatics functional
        
        %% Calculating q_i
        
        q0=zeros(length(r),N+max(Nb));
        for j=1:length(r)
            q0(j,1:N+2*max(Nb))=alpha(j)*d*conv(g(j,:),WF(j,:),'full');
        end
        
        q2=Z.^2.*r.^3*q0;
        q2(abs(q2)<1e-15)=0;
        
        %% Calculating space dependent Gamma
        o=1/length(r)*sum(1./r);
        
        if exist('MSA.Gamma','Var')==0
            Gamma=1/2/o*(sqrt(1+4*o*sqrt(pi*lambda*q2))-1);
        else
            Gamma=MSA.Gamma;
        end
        
        Gamma0=Gamma;
        
        errorGam=1;
        errorGamp=2;
        a=0.1;
        %         Gameps=10^(max(min((errg)-2,-4),-9));
        Gameps=10^(-10);
        
        ZZ=Z'.*ones(length(r),length(Gamma0));
        rr=r'.*ones(length(r),length(Gamma0));
        
        while errorGam>Gameps&&abs(errorGamp-errorGam)>Gameps
            Gamma0=a*Gamma+(1-a)*Gamma0;
            
            AA=1./(1+Gamma0./rr);
            H=sum(q0.*(AA-1/3))+2/pi;
            eta=(Z.*r.^2*(q0.*AA))./H;
            Gamma=sqrt(pi*lambda*(r.^3*(q0.*((ZZ-eta./rr.^2).*AA).^2)));
            
            errorGamp=errorGam;
            errorGam=max(abs(Gamma-Gamma0));
        end
        
        MSA.Gamma=Gamma;
        
        Zeff=(Z'-eta./r'.^2)./(1+Gamma./r');
        zt=round((size(Zeff,2)-N)/2)+1:round((size(Zeff,2)+N)/2);
        MSA.Zeff=Zeff(:,round((size(Zeff,2)-N)/2)+1:round((size(Zeff,2)+N)/2));
        
        %% Calculating space dependent derivative of Gamma wrt q_i
        
        if exist('MSA.dGamma','Var')==0
            dGamma=1/2*pi*lambda*Z'.^2./(sqrt(1+4*o*sqrt(pi*lambda*q2)).*sqrt(pi*lambda*q2).*ones(length(r),length(q2)));
        else
            dGamma=MSA.dGamma;
        end
        
        dGamma0=dGamma;
        
        errorGam=1;
        errorGamp=2;
        errorGampp=2;
        a=0.75;
        
        AA=1./(1+Gamma./r');
        
        dH1=1./r*(q0.*AA.^2);
        deta1=(Z'./r'.*AA);
        deta2=(Z.*r*(q0.*AA.^2));
        divH=1./H;
        dGamma1=((Z'-eta./r'.^2).*AA).^2;
        dGamma2=r.^2*(q0.*(Z'-eta./r'.^2).^2.*AA.^3);
        dGamma3=r*(q0.*(Z'-eta./r'.^2).*AA.^2);
        
        while errorGam>Gameps&&abs(errorGamp-errorGam)>Gameps&&abs(errorGampp-errorGam)>Gameps
            dGamma0=(1-a)*dGamma0+a*dGamma;
            dH=1./r'.^3.*AA-dH1.*dGamma0-1/3./r'.^3;
            deta=divH.*(-dH.*eta...
                +deta1...
                -deta2.*dGamma0);
            dGamma=pi*lambda./Gamma.*(1/2*dGamma1 ...
                -dGamma2.*dGamma0 ...
                -dGamma3.*deta);
            
            errorGampp=errorGamp;
            errorGamp=errorGam;
            errorGam=max(abs(dGamma(:)-dGamma0(:)));
        end
        
        dGamma(isnan(dGamma))=0;
        deta(isnan(deta))=0;
        
        MSA.dGamma=dGamma;
        MSA.deta=deta;
        
    else
        N=length(z);
        MSA.Zeff=Z'.*ones(1,N);
        MSA.Gamma=MSA.Gammab*ones(1,N);
        MSA.dGamma=MSA.dGammab'.*ones(1,N);
    end
    
    if strcmp(dft.ESu,'MSA')
        
        %% Calculating free energy density within MSA [R. Roth and D. Gillespie, J. Phys.: Condens. Matter 28, 244006 (2016)]
        MSA.Phi=-lambda*sum(q0(:,zt).*r'.^3.*(Z'.^2.*Gamma(zt)+Z'.*eta(zt)./r')./(1+Gamma(zt)./r'))+...
            Gamma(zt).^3/(3*pi);
        MSA.FexMSA=simpsons(MSA.Phi,0,max(z)+d/2);
        
        %% Calculating derivative of electrostatic free energy density
        
        dPhi=-lambda*(Z.^2'.*Gamma+Z'.*eta./r')./(1+Gamma./r')...
            -lambda*(r*(q0.*eta.*(Z'-eta./r.^2')./(1+Gamma./r').^2)).*dGamma...
            -lambda*(r.^2*(Z'.*q0./(1+Gamma./r'))).*deta;
        
        
        for j=1:length(r)
            c1MSAu(j,:)=d*conv(-dPhi(j,:),WF(j,:),'full');
        end
        
        c1MSAu=c1MSAu(:,round(size(c1MSAu,2)/2-N/2+1:size(c1MSAu,2)/2+N/2));
        c1ESu=c1MSAu;
        
    elseif strcmp(dft.ESu,'MSA_WDA')
        
        %% WDA-like formulation with F=int rho Phi(n)
        
        zt2=size(dGamma,2)/2-N/2+1:size(dGamma,2)/2+N/2;
        
        PhiMSA_WDA=(Z'.^2.*Gamma+(Z./r)'.*eta)./(1+Gamma./r')-Gamma/3.*(Z'-eta./r'.^2).^2./(1+Gamma./r').^2;
        PhiMSA_WDA=PhiMSA_WDA(:,size(PhiMSA_WDA,2)/2-N/2+1:size(PhiMSA_WDA,2)/2+N/2);
        
        MSA.Phi=-lambda*(alpha.*r.^3)*(g.*PhiMSA_WDA);
        MSA.FexMSA=simpsons(MSA.Phi,0,max(z)+d/2);
        
        dPhiMSA_WDAgam=(Z'-eta./r'.^2)./(1+Gamma./r').^2.*(Z'+1/3*(Z'-eta./r'.^2).*(Gamma./r'-1)./(1+Gamma./r'));
        dPhiMSA_WDAgam=dPhiMSA_WDAgam(:,zt);
        
        dPhiMSA_WDAeta=Z'./r'./(1+Gamma./r').*(1+2*Gamma./(3*Z'.*r').*(Z'-eta./r'.^2)./(1+Gamma./r'));
        dPhiMSA_WDAeta=dPhiMSA_WDAeta(:,zt);
        
        dPhiMSA_WDA=((alpha.*r.^3)*(g.*dPhiMSA_WDAgam)).*dGamma(:,zt2)+((alpha.*r.^3)*(g.*dPhiMSA_WDAeta)).*deta(:,zt);
        
        for j=1:length(r)
            c1pc=lambda*PhiMSA_WDA(j,:)+lambda*d*conv(dPhiMSA_WDA(j,:),WF(j,:),'same');
            c1MSAu_WDA(j,:)=c1pc(:,round(size(c1pc,2)/2-N/2+1:size(c1pc,2)/2+N/2));
        end
        c1ESu=c1MSAu_WDA;
    else
        MSA.Phi=zeros(1,length(z));
        MSA.Zeff=Z;
    end
else
    MSA.Phi=zeros(1,length(z));
    MSA.Zeff=Z;
end