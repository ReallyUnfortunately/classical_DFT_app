function c1SW=c1SquareWell(g,R,y,eSW,alpha,r,d)
N=length(g(1,:));
Wd=zeros(length(R),length(R),2*N-1);
for j=1:length(R)
    for i=1:length(R)
        nDy=floor(y*floor((R(i)+R(j))/d));
        nD=floor((R(i)+R(j))/d);
        
        zR=d*(nD:nDy);
        
        Wd(i,j,N-nDy:N-nD)=pi*eSW(i,j)*(y^2-(fliplr(zR)./(R(i)+R(j))).^2)*(R(i)+R(j))^2;
        Wd(i,j,N+nD:N+nDy)=pi*eSW(i,j)*(y^2-(zR./(R(i)+R(j))).^2)*(R(i)+R(j))^2;         
        
        Wd(i,j,N-nD+1:N+nD-1)=pi*eSW(i,j)*(y^2-1)*(R(i)+R(j))^2;
        
        correction=(4*pi/3*eSW(i,j)*(R(i)+R(j))^3*(y^3-1)-d*sum(Wd(i,j,:)))/2/d;
        if correction>0
            Wd(i,j,[N-nDy N+nDy])=correction;
        else
            Wd(i,j,[N-nDy+1 N+nDy-1])=Wd(i,j,[N-nDy+1 N+nDy-1])+correction;
        end
    end
end

c1SW=zeros(length(R),size(g,2));
for i=1:length(R)
    for j=1:length(R)
        c1SW(i,:)=c1SW(i,:)+d*conv((alpha(j).*r(j).^3)*g(j,:),squeeze(Wd(i,j,:)),'same');
    end
end
end