function [psi, dphiWB, PhiWB]=FMT(n,dft)
N=length(n.n3);


if ~strcmp(dft.HS,'RF')
    %white bear functions psi2 and psi3 (Roth)
    psi.p2=(6*n.n3-3*n.n3.*n.n3+6*(1-n.n3).*log(1-n.n3))./(n.n3.*n.n3.*n.n3);
    psi.p3=(6*n.n3-9*n.n3.*n.n3+6*n.n3.*n.n3.*n.n3+6*(1-n.n3).^2.*log(1-n.n3))./(4*n.n3.*n.n3.*n.n3);
    
    psi.p2(1)=2*psi.p2(2)-psi.p2(3);
    psi.p2(length(psi.p2))=2*psi.p2(length(psi.p2)-1)-psi.p2(length(psi.p2)-2);
    psi.p3(1)=2*psi.p3(2)-psi.p3(3);
    psi.p3(length(psi.p3))=2*psi.p3(length(psi.p3)-1)-psi.p3(length(psi.p3)-2);
    
    psi.dp2=-6*(n.n3+log(1-n.n3))./(n.n3.*n.n3.*n.n3)-3*psi.p2./n.n3;
    psi.dp3=3/2*(-2*n.n3+3*(n.n3.*n.n3)-2*(1-n.n3).*log(1-n.n3))./(n.n3.*n.n3.*n.n3)-3*psi.p3./n.n3;
    
    psi.dp2(1)=2*psi.dp2(2)-psi.dp2(3);
    psi.dp3(1)=2*psi.dp3(2)-psi.dp3(3);
    
    psi.dp2(N)=2*psi.dp2(N-1)-psi.dp2(N-2);
    psi.dp3(N)=2*psi.dp3(N-1)-psi.dp3(N-2);
else
    psi.p2=0;
    psi.dp2=0;
    psi.p3=0;
    psi.dp3=0;
end




%Excess free energy terms phiWB=phiWB1+phiWB2+phiWB3
PhiWB.t1=-n.n0.*log(1-n.n3);
PhiWB.t2=(1+1/9*n.n3.^2.*psi.p2).*(n.n1.*n.n2-n.n1v.*n.n2v)./(1-n.n3);
PhiWB.t3=(1-4/9*n.n3.*psi.p3).*...
    (n.n2.*n.n2.*n.n2-3*n.n2.*n.n2v.*n.n2v+9/2*(n.n2v.*n.nTz.*n.n2v-(n.nTx.*n.nTx.*n.nTx+n.nTy.*n.nTy.*n.nTy+n.nTz.*n.nTz.*n.nTz)))./...
    (24*pi*(1-n.n3).*(1-n.n3));
PhiWB.tot=PhiWB.t1+PhiWB.t2+PhiWB.t3;

%Derivatives of the excess free energy density wrt the weighted densities
dphiWB.dn0=-log(1-n.n3);
dphiWB.dn1=(1+1/9*n.n3.^2.*psi.p2).*n.n2./(1-n.n3);
dphiWB.dn2=((1+1/9*(n.n3.*n.n3).*psi.p2).*n.n1+...
    (1-4/9.*n.n3.*psi.p3).*(n.n2.*n.n2-n.n2v.*n.n2v)./(8*pi*(1-n.n3)))./(1-n.n3);
dphiWB.dn1v=-(1+1/9.*n.n3.*n.n3.*psi.p2).*n.n2v./(1-n.n3);
dphiWB.dn2v=-(1+1/9.*n.n3.*n.n3.*psi.p2).*n.n1v./(1-n.n3)+...
    (1-4/9.*n.n3.*psi.p3).*(-2*n.n2.*n.n2v+3*n.nTz.*n.n2v)./(8*pi*(1-n.n3).*(1-n.n3));
dphiWB.dn3=(n.n0+...
    (1+1/9*n.n3.*psi.p2.*(2-n.n3)+1/9*n.n3.*n.n3.*psi.dp2.*(1-n.n3)).*(n.n1.*n.n2-n.n1v.*n.n2v)./(1-n.n3)+...
    (2-4/9*psi.p3.*(n.n3+1)-4/9*n.n3.*psi.dp3.*(1-n.n3)).*...
    (n.n2.*n.n2.*n.n2-3*n.n2.*n.n2v.*n.n2v+9/2*(n.n2v.*n.nTz.*n.n2v-(n.nTx.*n.nTx.*n.nTx+n.nTy.*n.nTy.*n.nTy+n.nTz.*n.nTz.*n.nTz)))./...
    (24*pi*(1-n.n3).*(1-n.n3)))./(1-n.n3);

if strcmp(dft.HS,'WBIIt')
    dphiWB.dnTxx=(1-4/9*n.n3.*psi.p3).*(-9*n.nTx.*n.nTx)./(16*pi*(1-n.n3).*(1-n.n3));
    dphiWB.dnTyy=(1-4/9*n.n3.*psi.p3).*(-9*n.nTy.*n.nTy)./(16*pi*(1-n.n3).*(1-n.n3));
    dphiWB.dnTzz=(1-4/9*n.n3.*psi.p3).*(3*(n.n2v.*n.n2v-3*n.nTz.*n.nTz))./(16*pi*(1-n.n3).*(1-n.n3));
else
    dphiWB.dnTxx=zeros(1,N);
    dphiWB.dnTyy=zeros(1,N);
    dphiWB.dnTzz=zeros(1,N);
end

dphiWB.dn1(1:2)=0;
dphiWB.dn2(1:2)=0;
dphiWB.dn3(1:2)=0;
dphiWB.dn1v(1:2)=0;
dphiWB.dn2v(1:2)=0;
dphiWB.dnTxx(1:2)=0;
dphiWB.dnTyy(1:2)=0;
dphiWB.dnTzz(1:2)=0;

dphiWB.dn1(N-1:N)=0;
dphiWB.dn2(N-1:N)=0;
dphiWB.dn3(N-1:N)=0;
dphiWB.dn1v(N-1:N)=0;
dphiWB.dn2v(N-1:N)=0;
dphiWB.dnTxx(N-1:N)=0;
dphiWB.dnTyy(N-1:N)=0;
dphiWB.dnTzz(N-1:N)=0;
end