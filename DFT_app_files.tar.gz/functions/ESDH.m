function [c1ESDH]=ESDH(z,g,alphat,r,W,Z,lambda)
d=z(2)-z(1);
N=length(z);

q=zeros(length(r),N);
Kb=sqrt(4*pi*lambda*Z.^2.*r.^3*alphat');
b=1./r/2+1./Kb;
% b=1./r/2;
% b=0.1;
Nb=ceil(b/d);

NW=2*max(Nb)+1;
WF=zeros(length(b),NW);
for j=1:length(r)
    WF(j,(NW+1)/2-Nb(j)+1:(NW+1)/2+Nb(j)-1)=1/(2*b(j));
    if d*sum(WF(j,:))-1>0
        WF(j,[(NW+1)/2-Nb(j)+1 (NW+1)/2+Nb(j)-1])=WF(j,[(NW+1)/2-Nb(j)+1 (NW+1)/2+Nb(j)-1])-(d*sum(WF(j,:))-1)/2/d;
    else
        WF(j,[(NW+1)/2-Nb(j) (NW+1)/2+Nb(j)])=WF(j,[(NW+1)/2-Nb(j) (NW+1)/2+Nb(j)])-(d*sum(WF(j,:))-1)/2/d;
    end
end


q=zeros(length(r),N+max(Nb));
for j=1:length(r)
    q(j,1:N+2*max(Nb))=alphat(j)*d*conv(g(j,:),WF(j,:),'full');
end

% Kb=sqrt(4*pi*lambda*Z.^2.*r.^3*alphat');
% fDHb=1/2.*r.^3.*((Kb./r).^2-2*(Kb./r)+2*log(1+Kb./r));
% dKb=2*pi*lambda*Z.^2./Kb;
% dfDHb=2*pi*lambda/Kb*(Z.^2.*r.^3).*(Kb./r-1+1./(1+Kb./r));
% PhiDHb=-lambda/Kb^2*(Z.^2.*alphat)*fDHb';
% c1ESDHb=lambda/Kb^2*Z.^2.*(4*pi*PhiDHb+fDHb+alphat.*r.^3.*dfDHb);
%
K=sqrt(4*pi*lambda*Z.^2.*r.^3*q);
K(K<1e-16)=1e-15;
dK=2*pi*lambda*Z'.^2./K;
fDH=1/2.*r'.^3.*((K./r').^2-2*(K./r')+2*log(1+K./r'));
dfDH=2*pi*lambda./K.*(Z.^2.*r.^3)'.*(K./r'-1+1./(1+K./r'));
PhiDH=-lambda./K.^2.*((Z.^2)*(r'.^3.*q.*fDH));

dPhiu=lambda./K.^2.*Z'.^2.*(4*pi*PhiDH+fDH+q.*dfDH);

% c1DH=zeros(length(r),N);
for j=1:length(r)
    c1DH(j,:)=d*conv(dPhiu(j,:),WF(j,:),'full');
end

c1ESDH=c1DH(:,round(size(c1DH,2)/2-N/2+1:size(c1DH,2)/2+N/2));

if sum(isnan(c1ESDH(:)))>0
    hallo=1;
end


