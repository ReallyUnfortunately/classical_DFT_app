function         [a0,err]=apicard_new(g,g_new,phi,phi_old,err,k,a0,sys,BC)
N=length(phi);
err.g(k)=log10(max(max(abs(g_new-g))));
err.dg(k)=err.g(k)-err.g(k-1);

err.gm(k)=log10(max(max(abs(g_new(:,round(N*3/8:N*5/8))-g(:,round(N*3/8:N*5/8))))));
err.dgm(k)=(err.gm(k))-(err.gm(k-1));
if isnan(err.dgm(k))
    err.dgm(k)=-15;
end


if (err.dg(k)>0&&err.dgm(k)>0)&&(log10(abs(err.dg(k)))>err.a0min||log10(abs(err.dgm(k)))>err.a0min)
    err.a0min=max(err.a0(k-1)-0.2,-5);
elseif k==2
    err.a0min=-1;
else
    err.a0min=min(-1,err.a0min+0.005);
end

nerr=10;
sdg=nnz(sign(err.dg(max(k-nerr+1:k,1)))+1);
sdgh=nnz(sign(err.dg(max(k-nerr:k-1,1)))+1);
sdgm=nnz(sign(err.dgm(max(k-nerr+1:k,1)))+1);
sdgmh=nnz(sign(err.dgm(max(k-nerr:k-1,1)))+1);

sd=min(sdg,sdgm);
sdh=min(sdgh,sdgmh);
ninc=0;

amin=-300;
aminend=-5+0.5*(tanh(-err.g(k)+1)+1);
%aminend=(-4.5+1*(tanh(-err.g(k)+1)+1))/1.2;
amax=-3+1*(tanh(-0.2*err.g(k))+1);

dphi=max(abs(phi)-abs(phi_old));
phiav=mean(phi(round(N*3/8:N*5/8)));
dphiav=mean(abs(phi(round(N*3/8:N*5/8)))-abs(phi_old(round(N*3/8:N*5/8))));

drop=0.5;
nskip=12;

d=2;
c=d;
f=2;
if k<50
    f1=1;
else
    f1=4;
end

b=1;
symm=0;
symm_old=0;

if max(abs(phi))<1e-5
    minia=min([err.a0min,amax,a0+0.1]);
elseif a0<-4
    minia=min([err.a0min,amax,...
        d-max(err.g(k),err.gm(k)),...
        a0-dphi+b,...
        max(f+log10(abs(err.dgm(k))),-8)/2]);
elseif a0>=-4
    minia=min([err.a0min,amax,...
        d-max(err.g(k),err.gm(k)),...
        a0-dphi+b,...
        max(f+log10(abs(err.dgm(k))),-8)/2,...
        a0+0.05]);
end


if k>200
    meandec=log10(abs(mean(err.g(k-20:k))-mean(err.g(k-40:k-20))));
else
    meandec=0;
end


if k<10&&phiav<1e-1&&dphiav<1e-1
    a0=-50;
elseif round(err.skip)==1
    a0=max(a0+0.001,amin);
    err.skip=err.skip*0.5^(1/nskip);
elseif meandec<a0-2&&~isinf(meandec)
    a0=a0-1;
    err.skip=1;
elseif symm>symm_old&&symm>a0
    err.a0min=a0;
    a0=a0-0.5;
elseif err.dgm(k)>0||dphiav>10^(-a0)
    a0=max([min(minia),amin]);
else
    a0=min(max([minia,aminend]),a0-dphi+b);
end

if k>100
    if err.g(k)<0&&~strcmp(BC.type,'ND')
        a0=max(a0,-4.5);
    elseif err.g(k)<2&&~strcmp(BC.type,'ND')
        a0=max(a0,-4.2);
    elseif err.g(k)<4&&~strcmp(BC.type,'ND')
        a0=max(a0,-4.5);
    elseif err.g(k)<5&&~strcmp(BC.type,'ND')
        a0=max(a0,-6);
    end
end

a0=max(a0,-30);


if nnz([sys.Zhs sys.Zc])>1&&k>101
    if -abs(mean(err.g(k-100:k-50))-mean(err.g(k-50:k)))/a0<1e-5
        err.a0min=err.a0min-0.01;
        err.a0min;
    else
        a0=min(a0,-1.3);
    end
else
    a0=min(a0,-1.2);
end

if sys.nhs+sys.M==1
    a0=max(a0,-4);
end

if k>50
    if max(err.g(k),err.gm(k))>15
        a0=max([a0,-abs(max(err.g(k),err.gm(k)))*1.1]);
    else
        a0=max([a0,-18,min(-abs(max(err.g(k),err.gm(k)))*1.3,-5)]);
    end
end

if strcmp(BC.type,'ND')||strcmp(BC.type,'NN')
    if k<100
        a0=min(a0,-10);
    else
        a0=min(a0,err.a0(k-1)+0.1);
        err.a0min=min(err.a0min+0.01,-5.2);
        if err.g(k)>-1
            a0=min(a0,-3);
        end
        %         a0=-4;
    end
end

if abs(err.gm(k)-err.g(k))<3 && err.gm(k)>-5
    a0=min(a0,-1.3);
end

%a0=max(a0,-4.5);
a0=min(a0,sys.picard);
err.a0(k)=a0;



end