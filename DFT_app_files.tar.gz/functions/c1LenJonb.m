function c1LJb=c1LenJonb(LJ,alpha,R,r)
c1LJb=zeros(1,length(R));

eLJ=sqrt(LJ.eLJ'*LJ.eLJ);%Lorentz-Berthelot

for i=1:length(r)
    for j=1:length(r)
        c1LJb(i)=c1LJb(i)+(4/3*pi*(LJ.dLJ(i,j)*2^(1/6))^3*eLJ(i,j)*LJ.wca-16/3*pi*eLJ(i,j)*LJ.dLJ(i,j)^3*(1/3*2^(-1/6*9*LJ.wca)-2^(-1/6*3*LJ.wca)))*alpha(j)*r(j)^3;
    end
end

if ~isinf(LJ.rc)
    
    for i=1:length(r)
        for j=1:length(r)
            c1LJb(i)=c1LJb(i)-16/3*pi*eLJ(i,j)*LJ.dLJ(i,j)^3*(-4/3*(LJ.dLJ(i,j)/LJ.rc(i,j))^9+2*(LJ.dLJ(i,j)/LJ.rc(i,j))^3)*alpha(j)*r(j)^3;
        end
    end
    
end
end