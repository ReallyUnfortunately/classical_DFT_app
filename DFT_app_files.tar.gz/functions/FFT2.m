function f=FFT2(g)

[nc, Nz]=size(g);

if Nz>nc
    N=Nz;
    f=zeros(nc,N+1);
else
    N=nc;
    f=zeros(Nz,N+1);
    g=g';
    nc=Nz;
end

% Kx=2*pi*kx'/sys.zmax;
kx=(0:N);
x=(0:N-1);

Fexp=exp(2*pi/N*1i*kx'.*x);

for j=1:nc
    f(j,:)=sum(g(j,:).*Fexp,2);
end

