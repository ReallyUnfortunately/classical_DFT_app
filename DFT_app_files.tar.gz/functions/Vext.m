%% External potential=potential of wall=hard-wall potential
function V_ext=Vext(z,R,d,dft,LJ)
nu=length(R);
r=1./R/2;
N=length(z);

V_ext=zeros(nu,N);

%% Lennard-Jones Potential for wall-particle
if strcmp(dft.LJw,'on')
    %External Potential of LJ-wall with the Steele 10-4-3 potential
    for j=1:nu
        V_ext(j,:)=V_ext(j,:)+2*pi*LJ.rhow*LJ.dw(j)^2*LJ.eLJw(j)*(2/5*(LJ.dw(j)./z).^10-(mean(LJ.dw(j,:))./z).^4-mean(LJ.dw(j,:))^4./(3*mean(LJ.dS(j,:))*(z+0.61*mean(LJ.dS(j,:))).^3));
        V_ext(j,:)=V_ext(j,:)+2*pi*LJ.rhow*LJ.dw(j)^2*LJ.eLJw(j)*(2/5*(LJ.dw(j)./fliplr(z)).^10-(mean(LJ.dw(j,:))./fliplr(z)).^4-mean(LJ.dw(j,:))^4./(3*mean(LJ.dS(j,:))*(fliplr(z)+0.61*mean(LJ.dS(j,:))).^3));
    end
end

%% WCA potential for wall-particle
if strcmp(dft.WCA,'on')
    LJ.dLJ=LJ.dLJ;
    for j=1:nu
        Nwca=1:round((LJ.WCAd(j)/d)*2^(1/6));
%         V_ext(j,Nwca)=4*((LJ.dLJ(j)./z(Nwca)).^12-(LJ.dLJ(j)./z(Nwca)).^6)+1;
%         V_ext(j,:)=V_ext(j,:)+fliplr(V_ext(j,:));
        V_ext(j,Nwca)=2*pi*LJ.WCAeps(j)*LJ.WCArho*LJ.WCAd(j)^2*(2/5*(LJ.WCAd(j)./z(Nwca)).^10-(LJ.WCAd(j)./z(Nwca)).^4+2^(4/3)/5+1/2*(2^(1/3)-z(Nwca).^2/LJ.WCAd(j)^2));
        V_ext(j,:)=V_ext(j,:)+fliplr(V_ext(j,:));
    end
end

%% hard-wall
if ~strcmp(dft.WCA,'on')
    for j=1:nu
        V_ext(j,1:round(R(j)/d))=inf;
        V_ext(j,N-round(R(j)/d)+1:N)=inf;
    end
end

%% Attractive EXP
if strcmp(dft.EXP,'on')
    for j=1:nu
        V_ext(j,round(R(j)/d)+1:N-round(R(j)/d))=dft.EXPeps(j)*exp(-dft.KEXP(j)*(z(round(R(j)/d)+1:N-round(R(j)/d))-R(j)));
        V_ext(j,:)=V_ext(j,:)+fliplr(V_ext(j,:));
    end
end


end