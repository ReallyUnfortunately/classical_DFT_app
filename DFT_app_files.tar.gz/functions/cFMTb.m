%Bulk free energy and direct correlation function

function [cb, phiWBb, dphib]=cFMTb(nb,R,dft)

if ~strcmp(dft.HS,'RF')
    phiWBb.p2=(6*nb.n3-3*nb.n3^2+6*(1-nb.n3)*log(1-nb.n3))/nb.n3^3;
    p2=phiWBb.p2;
    phiWBb.p3=(6*nb.n3-9*nb.n3^2+6*nb.n3^3+6*(1-nb.n3)^2*log(1-nb.n3))/(4*nb.n3.^3);
    p3=phiWBb.p3;
    
    phiWBb.dp2=-6*(nb.n3+log(1-nb.n3))/nb.n3^3-3*p2/nb.n3;
    dp2=phiWBb.dp2;
    phiWBb.dp3=3/2*(-2*nb.n3+3*nb.n3^2-2*(1-nb.n3)*log(1-nb.n3))/nb.n3^3-3*p3/nb.n3;
    dp3=phiWBb.dp3;
else
    phiWBb.p2=0;
    p2=phiWBb.p2;
    phiWBb.p3=0;
    p3=phiWBb.p3;
    
    phiWBb.dp2=0;
    dp2=phiWBb.dp2;
    phiWBb.dp3=0;
    dp3=phiWBb.dp3;
end

phiWBb.tot=-nb.n0*log(1-nb.n3)+...
    (1+1/9*nb.n3.^2.*p2).*nb.n2*nb.n1./(1-nb.n3)+...
    (1-4/9*nb.n3.*p3).*nb.n2.^3./(24*pi*(1-nb.n3).^2);

dphib.dn0=-log(1-nb.n3);
dphib.dn1=(1+1/9*nb.n3.^2.*p2).*nb.n2./(1-nb.n3);
dphib.dn2=(1+1/9*nb.n3.^2.*p2).*nb.n1./(1-nb.n3)+...
    (1-4/9*nb.n3.*p3).*nb.n2.^2./(8*pi*(1-nb.n3).^2);
dphib.dn3=nb.n0./(1-nb.n3)+...
    (1+1/9*nb.n3.*p2.*(2-nb.n3)+1/9*nb.n3.^2.*dp2.*(1-nb.n3)).*nb.n1.*nb.n2./(1-nb.n3).^2 ...
    +(2-4/9*p3.*(1+nb.n3)-4/9*nb.n3.*dp3.*(1-nb.n3)).*nb.n2.^3./(24*pi*(1-nb.n3).^3);

cb=-dphib.dn0-dphib.dn1*R-dphib.dn2*4*pi*R.^2-dphib.dn3*4/3*pi*R.^3;
end