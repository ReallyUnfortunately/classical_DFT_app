function n=WDFMT(g,alpha,W,r,d,nhs,M)
%Weighted densities for density profile
n.n0=zeros(1,length(g));
n.n0s=zeros(1,length(g));
n.n1=zeros(1,length(g));
n.n2=zeros(1,length(g));
n.n2s=zeros(1,length(g));
n.n3=zeros(1,length(g));
n.n1v=zeros(1,length(g));
n.n2v=zeros(1,length(g));
n.n2sv=zeros(1,length(g));
n.nTx=zeros(1,length(g));
n.nTy=zeros(1,length(g));
n.nTz=zeros(1,length(g));
for j=1:length(r)
    n2i=d*(conv(g(j,:)*alpha(j)*r(j)^3,W.W2(j,:),'same'));
    n2i(n2i<1e-50)=1e-50;
    n2vi=d*real(conv(g(j,:)*alpha(j)*r(j)^3,W.W2v(j,:),'same'));
%     n2vi(abs(n2vi)<1e-50)=1e-50*n2vi(abs(n2vi)<1e-50);
    n.n0=n.n0+n2i/pi*r(j)^2;
    n.n1=n.n1+n2i/2/pi*r(j);
    n.n2=n.n2+n2i;
    n.n3=n.n3+d*(conv(g(j,:)*alpha(j)*r(j)^3,W.W3(j,:),'same'));
    n.n1v=n.n1v+n2vi/2/pi*r(j);
    n.n2v=n.n2v+n2vi;
    n.nTx=n.nTx+d*(conv(g(j,:)*alpha(j)*r(j)^3,W.WTxx(j,:),'same'));
    n.nTy=n.nTy+d*(conv(g(j,:)*alpha(j)*r(j)^3,W.WTyy(j,:),'same'));
    n.nTz=n.nTz+d*(conv(g(j,:)*alpha(j)*r(j)^3,W.WTzz(j,:),'same'));
end

for j=nhs+1:nhs+M
    n.n0s=n.n0s+d*(conv(g(j,:)*alpha(j)*r(j)^3,W.W0(j,:),'same'));
    n.n2s=n.n2s+d*(conv(g(j,:)*alpha(j)*r(j)^3,W.W2(j,:),'same'));
    n.n2sv=n.n2sv+d*(conv(g(j,:)*alpha(j)*r(j)^3,W.W2v(j,:),'same'));
end
n.n3(n.n3<1e-50)=1e-50;
end