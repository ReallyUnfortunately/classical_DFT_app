function [alpha,c]=alphac(alpha,Nc,Nhs,Z,r,Rreal)
Na=6.02214076e23;
Mol=Na*1e3*1e-27;
nhs=length(Nhs);
M=length(Nc);

if M~=0
        nonzeroZ=find(Z~=0);
        Zchain=sum(Z(nonzeroZ(nonzeroZ>nhs)));
        
        if Zchain==0
            lastZ=max(nonzeroZ(1:nhs));
            nonzeroZfixed=nonzeroZ(1:lastZ-1);
            alpha(lastZ)=-1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZfixed).*r(nonzeroZfixed).^3.*Z(nonzeroZfixed));
            c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
        else
            lastZ=nhs+1;
            nonzeroZfixed=nonzeroZ(1:lastZ-1);
            alpha(lastZ)=-1/sum(Z(Nc))/r(lastZ)^3*sum(alpha(nonzeroZfixed).*r(nonzeroZfixed).^3.*Z(nonzeroZfixed));
            alpha(Nc)=alpha(lastZ);
            c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
        end
else
        nonzeroZ=find(Z~=0);
        lastZ=max(nonzeroZ);
        nonzeroZ=nonzeroZ(1:length(nonzeroZ)-1);
        alpha(lastZ)=-1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZ).*r(nonzeroZ).^3.*Z(nonzeroZ));
        c=alpha/Mol.*r.^3/(2*Rreal)^3;
end
