function [c1chain, Phichain]=c1CC(n,r,Nc,W,WF,Z,MSA,d,lambda)
ds=1/r(min(Nc));
M=length(Nc);
nhs=length(r)-M;
N=length(n.n3);



zeta=1-n.n2v.*n.n2v./n.n2.^2;
zetas=1-n.n2sv.*n.n2sv./n.n2s.^2;

dzeta.dn2v=-2*n.n2v./n.n2.^2;
dzeta.dn2=2*n.n2v.^2./n.n2.^3;
dzetas.dn2sv=-2*n.n2sv./n.n2s.^2;
dzetas.dn2s=2*n.n2sv.^2./n.n2s.^3;

ghs=1./(1-n.n3)+n.n2*ds.*zeta./(4*(1-n.n3).^2)+n.n2.^2*ds^2.*zeta./(72*(1-n.n3).^3);
% ghs=ones(max(Nc),1).*ghs;
% if nnz(Z(Nc))>1
%     y(Nc,:)=y(Nc,:).*exp((Z(Nc)'.^2-Zeff(Nc,:).^2)*lambda/r(Nc(1)));
% end


% s stands for segment
dghs.dn2=ds*zeta./(4*(1-n.n3).^2)+n.n2*ds^2.*zeta./(36*(1-n.n3).^3)+...
    (ds*n.n2./(4*(1-n.n3).^2)+n.n2.^2*ds^2./(72*(1-n.n3).^3)).*dzeta.dn2;
dghs.dn2v=(ds*n.n2./(4*(1-n.n3).^2)+n.n2.^2*ds^2./(72*(1-n.n3).^3)).*dzeta.dn2v;
dghs.dn3=1./(1-n.n3).^2+n.n2*ds.*zeta./(2*(1-n.n3).^3)+n.n2.^2*ds^2.*zeta./(24*(1-n.n3).^4);

if nnz(Z(Nc))>1 && length(Nc)==2
    Zeff=MSA.Zeff;
    Gamma=MSA.Gamma(:,round((size(MSA.Gamma,2)-N)/2)+1:round((size(MSA.Gamma,2)+N)/2));
    dGamma=MSA.dGamma(:,round((size(MSA.Gamma,2)-N)/2)+1:round((size(MSA.Gamma,2)+N)/2));
    deta=MSA.deta(:,round((size(MSA.deta,2)-N)/2)+1:round((size(MSA.deta,2)+N)/2));
    
    Phichain=(1-M)/M*n.n0s.*zetas.*(log(ghs)+lambda/ds*(Z(Nc(1))*Z(Nc(2))-Zeff(Nc(1),:).*Zeff(Nc(2),:)));
    dZeff1=-1./r(Nc(1))./(1+Gamma./r(Nc(1))').*deta(Nc,:)-Zeff(Nc(1),:)./(1+Gamma./r(Nc(1)))./r(Nc(1)).*dGamma(Nc,:);
    dZeff2=-1./r(Nc(2))./(1+Gamma./r(Nc(2))').*deta(Nc,:)-Zeff(Nc(2),:)./(1+Gamma./r(Nc(2)))./r(Nc(2)).*dGamma(Nc,:);
    
    dPhichain.dn2s=(1-M)/M*n.n0s.*(log(ghs)+lambda/ds*(Z(1)*Z(2)-Zeff(1,:).*Zeff(2,:))).*dzetas.dn2s;
    dPhichain.dn2sv=(1-M)/M*n.n0s.*(log(ghs)+lambda/ds*(Z(1)*Z(2)-Zeff(1,:).*Zeff(2,:))).*dzetas.dn2sv;
else
    Phichain=(1-M)/M*n.n0s.*zetas.*log(ghs);
    
    dPhichain.dn2s=(1-M)/M*n.n0s.*log(ghs).*dzetas.dn2s;
    dPhichain.dn2sv=(1-M)/M*n.n0s.*log(ghs).*dzetas.dn2sv;
end


dPhichain.dn0s=Phichain./n.n0s;
% dPhichain.dn2s=Phichain./zetas.*dzetas.dn2s;
% dPhichain.dn2sv=Phichain./zetas.*dzetas.dn2sv;

dPhichain.dn2=(1-M)/M*n.n0s.*zetas.*dghs.dn2./ghs;
dPhichain.dn2v=(1-M)/M*n.n0s.*zetas.*dghs.dn2v./ghs;
dPhichain.dn3=(1-M)/M*n.n0s.*zetas.*dghs.dn3./ghs;

if nnz(Z(Nc))>1 && length(Nc)==2
    dPhichain.drho=(1-M)/M*n.n0s.*zetas*lambda/ds.*(-dZeff1.*Zeff(Nc(2),:)-Zeff(Nc(1),:).*dZeff2);
else
    dPhichain.drho=zeros(M,N);
end

c1chain=zeros(length(r),length(n.n3));

for j=1:Nc(1)-1
    c1chain(j,:)=-d*(conv(dPhichain.dn2,W.W2(j,:),'same')+...
        conv(dPhichain.dn3,W.W3(j,:),'same')+...
        conv(dPhichain.dn2v,-W.W2v(j,:),'same'));
end

for j=Nc
    c1chain(j,:)=-d*(conv(dPhichain.dn0s,W.W0(j,:),'same')+...
        conv(dPhichain.dn2+dPhichain.dn2s,W.W2(j,:),'same')+...
        conv(dPhichain.dn3,W.W3(j,:),'same')+...
        conv(dPhichain.dn2v+dPhichain.dn2sv,-W.W2v(j,:),'same')+...
        conv(dPhichain.drho(j-nhs,:),WF(j,:),'same'));
end

end