function [W]=WFFMT(N,R,d,dft)
W.W3=zeros(length(R),2*N-1);
W.W2=zeros(length(R),2*N-1);
W.W2v=zeros(length(R),2*N-1);
W.WTxx=zeros(length(R),2*N-1);

for j=1:length(R)
nR=floor(R(j)/d);
zR=d*(-nR:nR);

W.W3(j,N-nR:N+nR)=pi*(R(j)^2-zR.^2);
W.W3(j,[N-nR N+nR])=W.W3(j,[N-nR N+nR])+(4*pi/3*R(j)^3-d*sum(W.W3(j,:)))/2/d;
% W.W3(j,[N-nR N+nR])=d/6*pi*R(j);

W.W2(j,N-nR:N+nR)=2*pi*R(j);
W.W2(j,[N-nR N+nR])=W.W2(j,[N-nR N+nR])+(4*pi*R(j)^2-d*sum(W.W2(j,:)))/2/d;
% W.W2(j,[N-nR N+nR])=W.W2(j,[N-nR N+nR])/2;

W.W2v(j,N-nR:N+nR)=2*pi*zR;
W.W2v(j,[N+nR])=W.W2v(j,[N+nR])+(pi*R(j)^2-d*trapz(W.W2v(j,N:N+nR)))/2/d;
W.W2v(j,[N-nR])=W.W2v(j,[N-nR])-(pi*R(j)^2+d*trapz(W.W2v(j,N-nR:N)))/2/d;
% W.W2v(j,[N-nR N+nR])=W.W2v(j,[N-nR N+nR])/2;

W.WTxx(j,N-nR:N+nR)=pi*(R(j)^2-3*zR.^2)./(3*R(j));
W.WTxx(j,[N-nR N+nR])=W.WTxx(j,[N-nR N+nR])+1/6*pi*(2*nR+1)*d;
end

W.W1=W.W2./(4*pi*R');
W.W0=W.W2./(4*pi*R'.^2);
W.W1v=W.W2v./(4*pi*R');


if strcmp(dft.HS,'WBIIt')
    W.WTyy=W.WTxx;
    W.WTzz=-2*W.WTxx;
else
    W.WTxx=0*W.WTxx;
    W.WTyy=W.WTxx;
    W.WTzz=-2*W.WTxx;
end


end