function data=DFTcalc(sys,BC,dft,LJ,V_ext_GUI,app)

eta=sys.eta;
disp('start')

% Natural Constants
epsilon0=8.8541878128e-12; %permittivity constant
el=1.602176634e-19; %Electric charge
Na=6.02214076e23; %Number of Avogadro
Mol=Na*1e3*1e-27;% Molar in #/nm^3
kb=1.38064852e-23;%Boltzmann Constant

if strcmp(sys.defT,'on')
    T = sys.T;
    beta = 1/kb/T;
    sys.epsilonw = el^2*beta/(4*pi*epsilon0 * sys.lambdanm*1e-9);
    lambda = el^2*beta/(4*pi*epsilon0*sys.epsilonw)/(2*sys.Rreal*1e-9);
else
    T = el^2/4/pi/sys.epsilonw/epsilon0/sys.lambdanm/1e-9/kb;%Temperature
    % Natural Constants
    beta = 1/(kb*T);%inverse Boltzmann temperature
    lambda = el^2*beta/(4*pi*sys.epsilonw*epsilon0)/(2*sys.Rreal*1e-9);%Bjerrum length
end

sys.lambda = lambda;
sys.T = T;

%% Define # of particles, their size ratios and their charges

nhs=sys.nhs; %number of hard-sphere species. Only fill in r, Z, c for the first nu values. The other values will be thrown away.
M=sys.M; %number of beads in the chain

nu=sys.nhs+sys.M; %total number of hard-sphere types, i.e. chain beads + hard-spheres
Nc=sys.nhs+1:sys.nhs+sys.M;

if sys.nhs==0
    Nhs=1;
    sys.rhs=1;
    sys.Zhs=1;
else
    Nhs=1:sys.nhs;
end

%Define particle ratios
% r(Nhs)=sys.rhs(Nhs); %size-ratio between first particle with the rest r(i)=R_1/R_j for the hard spheres
% r(Nc)=sys.rc(Nc-nhs); %size-ratio between first solvent particle with the particles in the chain;

r=sys.r;

% Z(Nhs)=sys.Zhs; %Valency of particle of species 1:n
% Z(Nc)=sys.Zc; %Valency of chain particles

Z=sys.Z;

%% packing fraction or concentration of particles

%Defining concentration. Note that for charged species, one has a charge
%neutrality condition, fixing some values of c
% for two charged species, one of the concentrations must be fixed.
% for three charged species, two of the concentrations must be fixed etc.
%...
%For convenience, choose the first x concentrations to fix
%Note that alpha=c*Mol.*(2*Rreal./r).^3;

packing=sys.packing;
csolv=40;

if ~strcmp(packing,'on')
    c(Nhs)=sys.chs(Nhs); %Concentration in Moles for particles of species 1
    c(Nc)=sys.cc(1:sys.M); %Concentration in Moles for particles of species 2 (alpha=c*Mol.*(2*Rreal./r).^3;)
    c=c(1:nu);
else
    %just to make sure it doesnt crash somewhere
    c=1e-10*ones(1,nu);
end


%% rigid chains for TPT1 not yet working well
rigid='off';
theta0=pi*120/180;

%% parallel defining parameters
sigma=zeros(2,length(BC.phiV),length(eta),length(sys.zmax));
phi0=zeros(2,length(BC.phiV),length(eta),length(sys.zmax));
GamAds=zeros(nu,length(BC.phiV),length(eta),length(sys.zmax));
F.id_legendre=0;
f.id_FMT=0;
Omega=zeros(length(BC.phiV),length(eta),length(sys.zmax));
GammabMSA=zeros(1,length(eta));

%%
for z0=1:length(sys.zmax)
    if length(sys.zmax)>1 && z0>1
        clear g_0 g V_ext
    end
    %% All non-tuning parameters
    
    
    
    %Distance between gridpoints
    d=1/sys.ngrid;
    
    %Round sys.zmax off in terms to d
    sys.zmax(z0)=round(sys.zmax(z0)/d)*d;
    
    %Size particles
    %     r(1)=1;
    for j=1:nu
        %         r(j)=1/(round(1/r(j)/d/2)*2*d);
        R(j)=1/2/r(j);
    end
    
    % number of gridpoints |1|2|3|...|N-1|N|
    N=round(sys.ngrid*sys.zmax(z0));
    
    %Length vector with z_i=d*(i-1/2)
    z=d*((1:N)-1/2);
    
    %% External potential=potential of wall=hard-wall potential
    V_ext=Vext_GUI(sys,V_ext_GUI,z0);
    
    %% setting values for alpha
    alpha=c*Mol.*(2*sys.Rreal./r).^3;
    
    if ~strcmp(packing,'on')
        if sum(alpha*pi/6)>=0.6
            app.Errors.Value='!!!Packing fraction unphysically large.!!!';
            data.z=z;
            data.g=exp(-V_ext);
            return
        elseif nnz(Z)~=0&&abs(sum(sign(Z)))==nnz(Z)
            app.Errors.Value='All charged species having the same sign in charge is not physical!';
            data.z=z;
            data.g=exp(-V_ext);
            return
        end
        eta=pi/6*alpha*r'.^3;
    else
        if sys.eta>0.48
            app.Errors.Value='!!!Packing fraction unphysically large.!!!';
            data.z=z;
            data.g=exp(-V_ext);
            return
        end
    end
    
    if nnz(Z)==1
        app.Errors.Value='Only one charged species is not physical!';
        data.z=z;
        data.g=exp(-V_ext);
        return
    end
    
    if nnz(sign(alpha)<0)>0
        app.Errors.Value='No charge neutrality possible in bulk!!';
        data.z=z;
        data.g=exp(-V_ext);
        return
    end
    
    
    %% Weight functions W_a(z)
    % This includes the tensor weight function
    W=WFFMT(N,R,d,dft);
    
    %% Picard
    
    %Determine to either loop over phi0 or sigma0 or c/alpha/eta
    if strcmp(BC.type,'DD')
        nV=length(BC.phiV);
    elseif strcmp(BC.type,'ND')
        nV=length(BC.sigma0);
    else
        nV=1;
    end
    
    if ~strcmp(packing,'on')
        eta=0;
    end
    
    %%
    g_0=zeros(nu,length(z));
    
    %% Begin loop for different values of eta and phi0 or BC.sigma0
    for c0=1:length(eta)
        for v0=1:nV
            
            app.Progress.Value = {[char(951) ' ' num2str(c0) ' of ' num2str(length(eta))];
                [char(934) char(8320) ' ' num2str(v0) ' of ' num2str(length(BC.phiV))];
                ['H ' num2str(z0) ' of ' num2str(length(sys.zmax))]};
            
            if strcmp(packing,'on')
                [alphat,c(c0,:)]=alphapackingGUI(sys,Mol,c0);
            else
                alphat=alpha;
            end
            
            if min(alphat)<0
                app.Errors.Value='!!!!Solvent concentration too high!!!!';
                data.z=z;
                data.g=exp(-V_ext);
                return
            end
            
            % Not yet completely implemented
            if strcmp(dft.epsilonbulkvar,'on')
                epsilonb=max(epsilon(sys.epsilonw,epsilon0,1,1,c(c0,:),beta,el,Mol,Z),2);
                data.epsb(c0)=epsilonb;
                lambda=el^2*beta/(4*pi*epsilonb*epsilon0)/(2*sys.Rreal*1e-9);%Bjerrum length
            end
            
            
            %% Boundary Conditions Electrostatics
            [phi, D2, B, C]=ESBC(BC,z,d,beta,el,v0);
            if strcmp(BC.type,'ND')
                C=4*pi*lambda*C/(el*1e18/(2*sys.Rreal)^2);%From C/m^2 to e/d^2
            end
            phi_old=phi;
            
            %% initial density profile
            smalla=1;
            ag0=sys.ag0;
            if v0==1
                if nV>1||c0==1
                    if min(min(V_ext'))<0
                        g_0=exp(-smalla*V_ext/abs(min(V_ext(V_ext<0))));
                    else
                        g_0=exp(-smalla*V_ext);
                    end
                else
                    g_0=ag0*gf(:,:,v0,c0-1)+(1-ag0)*exp(-smalla*V_ext);
                end
            else
                g_0=ag0*gf(:,:,v0-1,c0)+(1-ag0)*exp(-smalla*V_ext);
            end
            
            g_old=g_0;
            g_new=g_0;
            g=g_0;
            
            %% Bulk values
            
            if ~strcmp(dft.HS,'none')
                %Bulk weighted densities for all species
                [nb, ptHSFMT, PhiFMTb]=WDFMTb(alphat,r,nhs,M,dft);
                
                %bulk direct correlation function
                [c1HSb, phiWBb, dphib]=cFMTb(nb,R,dft);
            else
                %Bulk weighted densities for all species
                [nb, ptHSFMT, PhiFMTb]=WDFMTb(1e-20*ones(1,length(r)),r,nhs,M,dft);
                %bulk direct correlation function
                [c1HSb, phiWBb, dphib]=cFMTb(nb,R,dft);
            end
            %Electrostatics
            %bulk
            [c1ESb,MSA]=ESb(Z,alphat,lambda,r,d,dft);
            
            %length scale Gamma from MSA
            GammabMSA(c0)=MSA.Gammab;
            
            % If using a non-MSA internal energy for the ES part
            if strcmp(dft.ESu,'DH')
                % Internal energy contribution within DC theory
                Kb=sqrt(4*pi*lambda*Z.^2.*r.^3*alphat');
                fDHb=1/2.*r.^3.*((Kb./r).^2-2*(Kb./r)+2*log(1+Kb./r));
                dKb=2*pi*lambda*Z.^2./Kb;
                dfDHb=2*pi*lambda/Kb*(Z.^2.*r.^3).*(Kb./r-1+1./(1+Kb./r));
                PhiDHb=-lambda/Kb^2*(Z.^2.*alphat)*fDHb';
                c1ESDHb=lambda/Kb^2*Z.^2.*(4*pi*PhiDHb+fDHb+alphat.*r.^3.*dfDHb);
                
                c1ESb=c1ESb+c1ESDHb;
            elseif strcmp(dft.ESu,'DHll')
                Kb=sqrt(4*pi*lambda*Z.^2.*r.^3*alphat');
                c1ESb=lambda/2*Kb;
            end
            
            % Chain connectivity
            if strcmp(dft.TPT1,'on')
                [c1chainb,Phichainb,ptchain]=c1CCb(alphat,r,Nhs,Nc,nb,Z,MSA,lambda);
            else
                Phichainb=0;
                c1chainb=0;
                ptchain=0;
            end
            
            % Lennard-Jones pair potential (MF)
            if strcmp(dft.LJ,'on')
                c1LJb=c1LenJonb(LJ,alphat,R,r);
            else
                c1LJb=0;
            end
            
            %% Total direct correlatioon function in bulk=-excess chemical
            %potential
            c1b=c1HSb+c1ESb+c1chainb+c1LJb;
            
            %% Bulk pressure
            ptbulk=ptHSFMT+MSA.pu+MSA.pc+ptchain;
            
            %Pressure from Bulk value Grand Potential Omega/V=f_HS+f_ES_MSA-rho*mu
            ptbulkomega=-phiWBb.tot-MSA.Phib+1/2*(alphat.*r.^3)*MSA.c2EScb*(alphat.*r.^3)'-sum(r.^3.*alphat.*(c1b-1));
            
            %Numerical Bullshit
            k=2;
            err.g(1)=inf;
            err.skip=0;
            errorg=1e10;
            err.a0(1:2)=-6;
            err.a0min=-1;
            a0=1e-10;
            a00=-10;
            a0min=0.5;
            oopsy=0;
            
            %% All other iterations until convergence
            while errorg>sys.eps
                
                %Picard Iteraction mix
                g=(1-a0)*g_old+a0*g_new;
                g(g==0)=1e-20;
                
                %weighted densities for FMT
                if ~strcmp(dft.HS,'none')
                    n=WDFMT(g,alphat,W,r,d,nhs,M);
                    maxn3=nanmax(n.n3);
                else
                    n=WDFMT(g,1e-20*alphat,W,r,d,nhs,M);
                    maxn3=nanmax(n.n3);
                end
                
                %Check maximum packing condition n.n3<1
                l=1;
                while maxn3>1
                    a=a0/10^l;
                    g=(1-a)*g_old+a*g_new;
                    n=WDFMT(g,alphat,W,r,d,nhs,M);
                    maxn3=max(n.n3);
                    l=l+1;
                    
                    if isinf(log10(a))
                        g=g_0;
                        n=WDFMT(g,alphat,W,r,d,nhs,M);
                        maxn3=max(n.n3);
                    end
                    
                    if k == 2 && l>1000
                        g_0 = exp(-smalla*V_ext/(1e-15+abs(min(V_ext(V_ext<=0)))));
                    end
                end
                
                %Potential from Poisson equation using tridiagonal
                %matrix inversion with correction
                Q=4*pi*lambda*(r.^3.*alphat.*g')*Z';
                
                phi_old=phi;
                phi=transpose(D2\(-B*Q-C));
                phi(isnan(phi))=0;
                
                % Mean-field contribution
                c1ESC=-Z'*phi;
                
                % Direct correlation function electrostatics due to energy
                % term MSA [J. Phys.: Condens. Matter 28 244006]
                [c1ESu,MSA,WF]=c1MSAu(alphat,Z,r,d,z,g,MSA,lambda,dft,err.a0(k-1));
                MSA.c1ESu=c1ESu;
                
                % Direct correlation function electrostatics from
                % correlations MSA [J. Chem. Phys. 92, 5087 (1990)]
                c1ESc=c1MSAc(alphat,Z,r,d,z,g,MSA,lambda,dft);
                
                MSA.c1ESc=c1ESc;
                
                % Total contribution electrostatics to C1
                c1ES=c1ESc+c1ESu;
                
                % Internal energy contribution according to Debye Huckel
                % theory
                if strcmp(dft.ESu,'DH')
                    c1ESDH=ESDH(z,g,alphat,r,W,Z,lambda);
                    c1ES=c1ES+c1ESDH;
                elseif strcmp(dft.ESu,'DHll')
                    Kz=sqrt(24*lambda*n.n3);
                    c1ESDH=3/pi*lambda*d*conv(Kz,W.W3(1,:),'same');
                    c1ESDH(2,:)=c1ESDH;
                    c1ES=c1ES+c1ESDH;
                end
                
                %direct correlation function chain associativity from
                %TPT1 [J. Chem. Phys. 117, 2368 (2002)]
                if strcmp(dft.TPT1,'on')
                    [c1chain, Phichain]=c1CC(n,r,Nc,W,WF,Z,MSA,d,lambda);
                else
                    c1chain=0;
                    Phichain=0;
                end
                
                %Direct correlation function for mean-field LJ attraction
                if strcmp(dft.LJ,'on')
                    c1LJ=c1LenJon(g,R,LJ,alphat,r,d);
                else
                    c1LJ=0;
                end
                
                %Calculations for HS-FMT direct correlation function  [J. Phys.: Condens. Matter 22 063102]
                [psi, dphi, PhiFMT]=FMT(n,dft);
                c1HS=c1HSFMT(dphi,W,d,r);
                
                % Total direct correlation function
                c1=c1HS+c1ES+c1ESC+c1LJ+c1chain;
                for j=1:nu
                    c1(j,c1(j,:)-c1b(j)>500)=500+c1b(j);
                    c1(j,c1(j,:)-c1b(j)<-500)=-500+c1b(j);
                end
                
                %Chain connectivity
                if strcmp(dft.TPT1,'on')
                    
                    %New density profiles with chains functional
                    G=connectivity(c1,c1b,V_ext,sys,r,z,d,rigid,theta0);
                    
                    g_new(Nhs,:)=exp(-V_ext(Nhs,:)+c1(Nhs,:)-c1b(Nhs)');
                    
                    if strcmp(rigid,'on')
                        for j=Nc
                            g_new(j,:)=exp(-V_ext(j,:)+c1(j,:)-c1b(j)).*G.tot(j-nhs,:);
                        end
                    else
                        for j=Nc
                            g_new(j,:)=exp(-V_ext(j,:)+c1(j,:)-c1b(j)).*G.L(j-nhs,:).*G.R(M+1-j+nhs,:);
                        end
                    end
                    g_old=g;
                else
                    %New density profiles without chains functional
                    g_new=exp(-V_ext+c1-c1b');
                    g_old=g;
                end
                
                
                %Picard errors and parameters (numerical bullshit)
                [a00,err]=apicard_new(g,g_new,phi,phi_old,err,k,a00,sys,BC);
                
                a0=10^a00;
                if oopsy==1
                    a0=a000;
                end
                errorg=real(err.g(k));
                
                % Determine if weird stuff happens
                if (err.dg(k)>10&&k>10)||~isempty(find(isnan(g_new), 1))
                    if oopsy==1
                        a0=a000/10;
                    elseif k>2
                        g_new=g;
                        a0=10^(err.a0(k-2)-2);
                        err.a0(k)=a00-2;
                        a000=a0;
                        oopsy=1;
                    else
                        g_new=g_0;
                        a0=a0/1000;
                        a000=a0;
                        oopsy=1;
                    end
                else
                    oopsy=0;
                end
                
                % Free energy Calculations
                phi0LV=[3/2*phi(1)-1/2*phi(2),3/2*phi(N)-1/2*phi(N-1)];
                dphi0=[(phi(2)-phi(1))/d, (phi(N)-phi(N-1))/d];
                sig=-dphi0/(4*pi*lambda).*[1 -1];
                %Helmholtz Free energy
                [Fe,fe]=F_id_ex_FMT(PhiFMT,g,c1,alphat,d,r,BC);
                [Fe]=F_ex_ES(g,z,Z,alphat,r,phi,phi0LV,sig,MSA,Fe,fe,BC);
                
                %Helmholtz free energy for every iteration
                %                 F_id(k)=Fe.id_legendre;
                %                 F_FMT(k)=Fe.ex_FMT;
                %                 F_ESc(k)=Fe.ex_ESc;
                %                 F_ESC(k)=Fe.ex_ESC;
                %Grand Potential for every iteration
                %                 Om(k)=sum(structfun(@(x)x, Fe))-phi0LV*sig';
                
                k=k+1;
                
                % Break loop when not converging
                if k>1000000||(abs(err.dg(k-2))/10^(err.a0(k-2))<1e-50&&abs(err.dg(k-1))/10^(err.a0(k-2))<1e-50&&(a00)>-15&&~isinf(log10(abs(err.dg(k-1))))&&k>200)||strcmp(app.StopButton.Text,'Wait!')
                    break
                end
                
                %Show Progression after every 100 iterations
                if mod(k,100)==0
                    app.errorgshow.Value=(err.g(k-1));
                    app.Picardshow.Value=log10(a0);
                    pause(0.0001)
                    if strcmp(app.StopButton.Text,'Wait!')
                        break
                    end
                end
                
            end
            
            %% Thermodynamic quantities
            
            % Debye Length
            K(c0)=sqrt(4*pi*lambda*sum(Z.^2.*alphat.*r.^3));
            
            alphas(:,c0)=alphat;
            mu_ex(:,c0)=-c1b;
            mu_es_ES(:,c0)=-c1ESb;
            mu(:,c0)=log(alphat.*r.^3)'+mu_ex(:,c0);
            
            %Calculate the Helmholtz Free energy for the equilibrium
            %profiles
            [F,f,p_HS_id]=F_id_ex_FMT(PhiFMT,g,c1,alphat,d,r,BC);
            [F,f,p_ES]=F_ex_ES(g,z,Z,alphat,r,phi,phi0LV,sig,MSA,F,f,BC);
            
            if length(sys.zmax)==1
                %local Grand potential density
                omegaz(1:length(f.id_FMT),v0,c0,z0)=f.id_FMT+f.ex_ES;
                %Density Profiles
                gf(:,1:size(g,2),v0,c0,z0)=g;
                gN(:,v0,c0,z0)=(alphat.*r.^3)*(g-1); %Excess number density
                gQ(:,v0,c0,z0)=(alphat.*Z.*r.^3)*g;
                %Potential Profile in V
                Phif(1:size(g,2),v0,c0,z0)=phi/beta/el;
            else
                %local Grand potential density
                omegaz(1:length(f.id_FMT),v0,c0,z0)=f.id_FMT+f.ex_ES;
                %Density Profiles
                gf(:,1:size(g,2),v0,c0,z0)=g;
                %Potential Profile
                Phif(1:size(g,2),v0,c0,z0)=phi/beta/el;
            end
            
            %surface charge
            sigma(:,v0,c0,z0)=sig';
            
            %surface potential
            phi0(:,v0,c0,z0)=phi0LV';
            
            %Contact presure
            pcontl=0;
            ap=0.5;
            for j=1:length(r)
                pcontl=pcontl+alphat(j)*r(j)^3*(...
                    ap*interp1(z(round(1/d/2/r(j))+1:round(N/2)),g(j,round(1/d/2/r(j)+1):round(N/2)),1/2/r(j),'pchip','extrap')+...
                    (1-ap)*interp1(z(round(1/d/2/r(j))+1:round(N/2)),g(j,round(1/d/2/r(j)+1):round(N/2)),1/2/r(j),'spline','extrap'));
            end %note here that spline overestimates and pchip mostly underestimates the contact value, thus the mixing.
            totdensdl(v0,c0,z0)=pcontl;
            pcontl=pcontl-2*pi*lambda*sigma(1,v0,c0,z0)^2;
            
            pcontr=0;
            ap=0.5;
            for j=1:length(r)
                pcontr=pcontr+alphat(j)*r(j)^3*(...
                    ap*interp1(z(round(1/d/2/r(j))+1:round(N/2)),g(j,round(1/d/2/r(j)+1):round(N/2)),1/2/r(j),'pchip','extrap')+...
                    (1-ap)*interp1(z(round(1/d/2/r(j))+1:round(N/2)),g(j,round(1/d/2/r(j)+1):round(N/2)),1/2/r(j),'spline','extrap'));
            end
            totdensdr(v0,c0,z0)=pcontr;
            pcontr=pcontr-2*pi*lambda*sigma(2,v0,c0,z0)^2;
            
            ptcontactl=pcontl;
            ptcontactr=pcontr;
            
            %Adsorption
            GamAds(:,v0,c0,z0)=d*alphat'.*r'.^3.*(sum(g-1,2));
            for jG=1:nu
                GamAdsR(jG,v0,c0,z0)=d*alphat(jG).*r(jG).^3.*(sum(g(jG,round(1/r(jG)/2/d+1):N-round(1/r(jG)/2/d))-1,2));%Without the space at which the  external potential vanishes
            end
            
            % Grand potential
            if strcmp(BC.type,'DD')
                Omega(v0,c0,z0)=sum(structfun(@(x)x, F)) - sig*phi0LV';
            else
                Omega(v0,c0,z0)=sum(structfun(@(x)x, F)) - sig(2)*phi0LV(2);
            end
            F_Helm(v0,c0,z0)=F.ex_FMT+F.ex_ESC+F.ex_ESc+F.ex_ESu;
            
            %Surface Tension
            surftens(v0,c0,z0)=Omega(v0,c0,z0)+ptbulk*sys.zmax(z0);
            
            % Average Packing fraction
            eta_av(v0,c0,z0) = pi/6*d*sum(alphat.*r.^3*g)/(sys.zmax(z0)-1);
            
            
            pHSFMT(v0,c0)=ptHSFMT;
            pESu(v0,c0)=MSA.pu;
            pESc(v0,c0)=MSA.pc;
            pchain(v0,c0)=ptchain;
            pbulkomega(v0,c0)=ptbulkomega;
            pbulk(v0,c0)=ptbulk;
            pcontactl(v0,c0)=ptcontactl;
            pcontactr(v0,c0)=ptcontactr;
            pmidsys(v0,c0)=p_HS_id+p_ES;
            
            alphamultiple(:,v0,c0)=alphat';
            
        end
    end
    %The contribution to the pressure, and its values from different routes
    p.HSFMT(:,:,z0)=pHSFMT;
    p.ESu(:,:,z0)=pESu;
    p.ESc(:,:,z0)=pESc;
    p.chain(:,:,z0)=pchain;
    p.bulkomega(:,:,z0)=pbulkomega;
    p.bulk(:,:,z0)=pbulk;
    p.contactl(:,:,z0)=pcontactl;
    p.contactr(:,:,z0)=pcontactr;
    p.midsys(:,:,z0)=pmidsys;
end

%% Differential Capacitance
try
    if size(gf,3)>1
        for j=1:size(gf,4)%concentrations c0
            for k=1:size(gf,5)%system sizes z0
                                
                    % calculating Cmu using the expression derived in  J. Chem. Phys. 155, 104702 (2021)
                    CdcL(:,j,k)=1/4/pi/lambda./squeeze(sigma(2,:,j,k)).*gradient(totdensdl(:,j,k)')./gradient(phi0(1,:,j,k));
                    CdcR(:,j,k)=1/4/pi/lambda./squeeze(sigma(2,:,j,k)).*gradient(totdensdr(:,j,k)')./gradient(phi0(2,:,j,k));
                    
                    CdL2(:,j,k)=gradient(sigma(1,:,j,k))./gradient(phi0(1,:,j,k));
                    CdR2(:,j,k)=gradient(sigma(2,:,j,k))./gradient(phi0(2,:,j,k));
                    
                if size(gf,3)>2
                    % different (numerical) methods to calculate the differential
                    % capacitance
                    Cdd=diff(sigma(:,:,j,k),[],2)'./(diff(phi0(:,:,j,k),[],2))';
                    CdL(:,j,k)=interp1(phi0(1,1:size(gf,3)-1,j,k)+0.5*diff(phi0(1,:,j,k),[],2),Cdd(:,1),phi0(1,:,j,k),'spline','extrap');
                    CdR(:,j,k)=interp1(phi0(2,1:size(gf,3)-1,j,k)+0.5*diff(phi0(2,:,j,k),[],2),Cdd(:,2),phi0(2,:,j,k),'spline','extrap');
                    
                    CdL3(:,j,k)=numdiff(sigma(1,:,j,k),phi0(1,:,j,k));
                    CdR3(:,j,k)=numdiff(sigma(2,:,j,k),phi0(2,:,j,k));
                else
                    CdL=zeros(length(BC.phiV),length(eta),length(sys.zmax));
                    CdR=zeros(length(BC.phiV),length(eta),length(sys.zmax));
                    
                    CdL3=zeros(length(BC.phiV),length(eta),length(sys.zmax));
                    CdR3=zeros(length(BC.phiV),length(eta),length(sys.zmax));
                end
            end
        end
    else
        CdL=zeros(length(BC.phiV),length(eta),length(sys.zmax));
        CdR=zeros(length(BC.phiV),length(eta),length(sys.zmax));
        
        CdL3=zeros(length(BC.phiV),length(eta),length(sys.zmax));
        CdR3=zeros(length(BC.phiV),length(eta),length(sys.zmax));
    end
catch
        CdL3=zeros(length(BC.phiV),length(eta),length(sys.zmax));
        CdR3=zeros(length(BC.phiV),length(eta),length(sys.zmax));
end

%% Define output
data.g = gf;
data.phi = Phif;
data.p = p;
data.GamAds = GamAds;
data.sys = sys;
data.sigma0 = sigma;
data.phi0 = phi0;
data.z = z;
data.alpha = alphamultiple;
data.Omega = Omega;
data.F = F_Helm;
data.GamAds = GamAds;
data.CdL = CdL3;
data.CdR = CdR3;
data.c = c;
data.BC = BC;
data.c1 = c1;
data.LJ = LJ;
data.dft = dft;
data.eta_av = eta_av;
data.mu = mu;
data.mu_ex = mu_ex;
data.V_ext_GUI = V_ext_GUI;
data.surftens = surftens;

%% Save data filename

DFTtype=['FMT_' dft.HS '_ESc_' dft.ESc  '_ESu_' dft.ESu];

if strcmp(dft.LJ,'on')
    DFTtype=[DFTtype '_LJ_' strrep(num2str(LJ.eLJ(1,:)),' ','_')];
end

if strcmp(dft.TPT1,'on')
    DFTtype=[DFTtype '_TPT1_' num2str(sys.M) '_'];
end

if sys.M==0
    Zstring=num2str(sys.Z);
    rstring=num2str(sys.r);
    cstring=num2str(c);
elseif sys.nhs==0
    Zstring=['Zc_' num2str(sys.Zc(1))];
    rstring=['rc_' num2str(sys.rc(1))];
    cstring=num2str(c);
else
    Zstring=['Zhs_' num2str(sys.Z(sys.Nhs)) '_Zc_' num2str(sys.Zc(1))];
    rstring=['rhs_' num2str(sys.r(sys.Nhs)) '_rc_' num2str(sys.rc(1))];
    cstring=num2str(c);
end

format shortE

if strcmp(packing,'on')
    if length(eta)==1
        constr=['_eta_' num2str(sys.eta(1))];
    else
        constr=['_eta_' num2str(sys.eta(1)) '_' num2str(sys.eta(length(sys.eta)))];
    end
else
    constr=['_c_' cstring];
end

if length(BC.phiV)>2
    phistring=[num2str(BC.phiV(1)) '_' num2str(BC.phiV(length(BC.phiV)))];
else
    phistring=num2str(BC.phiV);
end

if length(sys.zmax)>1
    zmaxstring=[num2str(sys.zmax(1)) '_' num2str(sys.zmax(end))];
else
    zmaxstring=num2str(sys.zmax(1));
end

if strcmp(V_ext_GUI.EXP,'on')
    DFTtype=[DFTtype '_Vext_EXP_' num2str(V_ext_GUI.EXPeps) '_' num2str(V_ext_GUI.EXPK)];
end

if strcmp(V_ext_GUI.WCA,'on')
    DFTtype=[DFTtype '_Vext_WCA_' num2str(V_ext_GUI.WCAeps) '_' num2str(V_ext_GUI.WCAd) '_' num2str(V_ext_GUI.WCArho)];
end

if strcmp(V_ext_GUI.Steele,'on')
    DFTtype=[DFTtype '_Vext_Steele_' num2str(V_ext_GUI.Steele_eLJw) '_' num2str(V_ext_GUI.Steele_dw) '_' num2str(V_ext_GUI.Steele_rhow)];
end

filename=['R_0' num2str(round(sys.Rreal*100))...
    '_Nhs_' num2str(sys.nhs)...
    '_M_' num2str(sys.M)...
    '_r_' rstring...
    '_Z_' Zstring...
    '_phi0_' phistring...
    constr...
    '_zmax_' zmaxstring...
    '_ngrid_' num2str(sys.ngrid)...
    '_lambdaB_' num2str(lambda*2*sys.Rreal)...
    '_' DFTtype '_' ...
    datestr(now, 'yyyy_mm_dd')];
while contains(filename,'  ')
    filename=strrep(filename,'  ',' ');
end

data.filename=strrep(strrep(filename,'.',''),' ','_');

end