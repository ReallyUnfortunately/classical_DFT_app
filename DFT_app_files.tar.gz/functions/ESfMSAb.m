function [c1ESb,muMSA,munonMSA,b,Gammab,dGammab,PhiMSAb,pMSA,Zeffb]=ESfMSAb(Z,alpha,lambda,r,d)
if nnz(Z)>1
    %% calculating Gamma Bulk
    
    %first guess gamma bulk
    q2b=sum(Z.^2.*alpha.*r.^3);
    o=1/length(r)*sum(1./r);
    Gammab=1/2/o.*(sqrt(1+4*o*sqrt(pi*lambda*q2b))-1);
    
    error=1;
    while error>1e-10
        Gamma0b=Gammab;
        Hb=sum(alpha./(1+Gamma0b./r))+2/pi*(1-pi/6*sum(alpha));
        etab=1/Hb*sum(Z.*alpha.*r.^2./(1+Gamma0b./r));
        Gammab=sqrt(pi*lambda*sum(r.^3.*alpha.*((Z-etab./r.^2)./(1+Gamma0b./r)).^2));
        error=max(abs(Gammab-Gamma0b));
    end
    
    Zeffb=(Z-etab./r.^2)./(1+Gamma0b./r);
    
    %% Derivative of Gamma bulk
    dGammab=1/2*pi*lambda*Z.^2.*r.^3./(sqrt(1+4*o*sqrt(pi*lambda*q2b)).*sqrt(pi*lambda*q2b));
    dGamma0b=dGammab;
    error=1;
    agam=0.5;
    while max(error)>1e-10
        dGamma0b=(1-agam)*dGamma0b+agam*dGammab;
        dHb=1./(1+Gammab./r)-sum(alpha./r./(1+Gammab./r).^2).*dGamma0b-1/3;
        detab=-dHb./Hb.*etab...
            +1./Hb.*(Z.*r.^2./(1+Gammab./r))...
            -1./Hb.*sum(Z.*r.*alpha./(1+Gammab./r).^2).*dGamma0b;
        dGammab=pi*lambda./(2*Gammab).*r.^3.*((Z-etab./r.^2)./(1+Gammab./r)).^2 ...
            -pi*lambda./Gammab.*sum(r.^2.*alpha.*(Z-etab./r.^2).^2./(1+Gammab./r).^3).*dGamma0b ...
            -pi*lambda./Gammab.*sum(r.*alpha.*(Z-etab./r.^2)./(1+Gammab./r).^2).*detab;
        error=max(abs(dGammab-dGamma0b));
    end
    
    %% Calculating free energy density MSA and pressure
    PhiMSAb=-lambda*sum(alpha.*r.^3.*(Z.^2*Gammab+Z.*etab./r)./(1+Gammab./r))+Gammab.^3/(3*pi);
    pMSA=-Gammab^3/3/pi-2*lambda*etab^2/pi;
    
    %% Chemical potential MSA
    muMSA=-lambda*Z.*(Z*Gammab+etab./r)./(1+Gammab./r)...
        -lambda./r.^3.*sum(r.^3.*alpha.*(Z.^2-Z.*etab./r.^2)./(1+Gammab./r).^2).*dGammab...
        -lambda./r.^3.*sum(r.^2.*alpha.*Z./(1+Gammab./r)).*detab...
        +1./r.^3*Gammab^2/pi.*dGammab;
    
    % muMSA=muMSA.*r.^3;
    
    % muMSA=-lambda*Z.*(Z*Gammab+etab./r)./(1+Gammab./r);
    
    %% Chemical Potential nonMSA
    RR=1/2*(1./r+1./r');
    
    %Shell Radius
    b=ceil((1./r/2+1/2/Gammab)/d)*d;
    B=b+b';
    
    munonMSA=-pi/2*lambda*Z./b.*((Z.*alpha.*r.^3./b)*(2*RR.*(RR.^3/3-B.*RR.^2+B.^2.*RR)-RR.^4/6+2*B.*RR.^3/3-B.^2.*RR.^2));
    
    %% bulk direct correlation function
    c1ESb=-muMSA-munonMSA;
else
    c1ESb=0;
    muMSA=0;
    munonMSA=zeros(1,length(r));
    b=1./r;
    Gammab=0;
    dGammab=0;
    PhiMSAb=0;
    pMSA=0;
    Zeffb=0;
end