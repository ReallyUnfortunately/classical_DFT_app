function [c1chainb, Phichainb, p]=c1CCb(alpha,r,Nhs,Nc,nb,Z,MSA,lambda)
    ds=1/r(min(Nc));
    M=length(Nc);
    Zeffb=MSA.Zeffb;
    
    

    ghs=1/(1-nb.n3)+nb.n2*ds/(4*(1-nb.n3)^2)+nb.n2^2*ds^2/(72*(1-nb.n3)^3);
%     yb=ones(1,M+length(Nhs))*yb;
%     if nnz(Z(Nc))>1
%         yb(Nc)=yb(Nc).*exp((Z(Nc).^2-Zeffb(Nc).^2)*lambda/r(Nc(1)));
%     end
    
%     rho1b=sum(alpha(Nc).*r(Nc).^3);

    if nnz(Z(Nc))>1 && length(Nc)==2
        Phichainb=(1-M)/M*nb.n0s*(log(ghs)+lambda/ds*(Z(Nc(1))*Z(Nc(2))-Zeffb(Nc(1))*Zeffb(Nc(2))));
        dZeffb=-1./r(Nc)./(1+MSA.Gammab./r(Nc)).*MSA.detab(Nc)'-Zeffb(Nc)./(1+MSA.Gammab./r(Nc))./r(Nc).*MSA.dGammab(Nc)';
    else
        Phichainb=(1-M)/M*nb.n0s*log(ghs);
    end
    
    dghsdn2=ds/(4*(1-nb.n3)^2)+nb.n2*ds^2/(36*(1-nb.n3)^3);
    dghsdn3=(1/(1-nb.n3)^2+nb.n2*ds/(2*(1-nb.n3)^3)+nb.n2^2*ds^2/(24*(1-nb.n3)^4));
    
    
    dphichainb.dn0s=Phichainb/nb.n0s;
    dphichainb.dn2=(1-M)/M*nb.n0s*dghsdn2./ghs;
    dphichainb.dn3=(1-M)/M*nb.n0s*dghsdn3./ghs;
    if nnz(Z(Nc))>1 && length(Nc)==2
        dphichainb.drho=(1-M)/M*nb.n0s*lambda/ds*(-Zeffb(Nc(1))*dZeffb(:,2)-dZeffb(:,1)*Zeffb(Nc(2)))';
    else
        dphichainb.drho=0;
    end
    
    
%     c1chainb(Nhs)=-(dphichainb.dn02(Nhs)*1+dphichainb.dn1(Nhs)*1/r(Nhs)/2+dphichainb.dn2(Nhs)*pi*1/r(Nhs).^2+dphichainb.dn3(Nhs)*pi/6*1/r(Nhs).^3);
%     c1chainb(Nc)=-(dphichainb.dn01(Nc)*1+dphichainb.dn1(Nc)*1./r(Nc)/2+dphichainb.dn2(Nc)*pi*1./r(Nc).^2+dphichainb.dn3(Nc)*pi/6*1./r(Nc).^3);
%     
    c1chainb(Nhs)=-(dphichainb.dn2*pi*1./r(Nhs).^2+dphichainb.dn3*pi/6*1./r(Nhs).^3);
    c1chainb(Nc)=-(dphichainb.dn0s*ones(1,length(Nc))+dphichainb.dn2*pi*1./r(Nc).^2+dphichainb.dn3*pi/6*1./r(Nc).^3+dphichainb.drho);
   
    
        %Pressure due to chain connectivity p=sum_i (rho_i mu_chain_i) - f_chain
        p=-(alpha.*r.^3)*c1chainb'-Phichainb;
%     p=(1-M)/M*nb.n0+dphichainb.dn2*nb.n2+dphichainb.dn3*nb.n3;
%     p=-Phichainb;
end