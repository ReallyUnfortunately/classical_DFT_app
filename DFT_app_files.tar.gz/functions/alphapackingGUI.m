function [alpha,c]=alphapackingGUI(sys,Mol,c0)

Rreal = sys.Rreal;
nhs = sys.nhs;
M = sys.M;
nu = M+nhs;

Nhs = 1:nhs;
Nc = nhs+1:nhs+M;

if nargin == 3
    eta = sys.eta(c0);
elseif length(sys.eta)>1
    eta = sys.eta(1);
else
    eta = sys.eta;
end

Z = sys.Z;
r = sys.r;

rhoratio = sys.rhoratio;
rhocratio = sys.rhocratio;

rhoposratio = rhoratio(Z(1:nhs)>0);
if isempty(rhoposratio)
    rhoposratio=[];
else
    rhoposratio = rhoposratio/rhoposratio(1);
end


rhonegratio = rhoratio(Z(1:nhs)<0);
if isempty(rhonegratio)
    rhonegratio=[];
else
    rhonegratio = rhonegratio/rhonegratio(1);
end

csolv = 40;

if M~=0 % When there are chain-like particles in the system
    
    if isempty(find(Z~=0, 1)) % If there are no charges particles
        alpha=ones(1,nu)*eta*6/pi/(nhs+1);
        alpha(Nc)=alpha(Nc)/M;
        alpha=alpha*eta/(pi/6*sum(alpha));
        c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
    else
        %Now we need a charge-neutral bulk system with the given
        %concentration
        alpha=ones(1,nu)*eta*6/pi/(nhs+1); %Divide the concentration evenly among the particles
        nonzeroZ=find(Z~=0); % Find the species with charge
        Zchain=sum(Z(nonzeroZ(nonzeroZ>nhs))); % total charge of a chain-like particle
        
        if Zchain==0 %if total charge of chain-like particle vanishes it is not constraint by charge-neutrality
            if nhs==0 % if there are no monomers in the system
                alpha=ones(1,nu)*eta*6/pi/nu;
                alpha=alpha*eta/(pi/6*sum(alpha));
                c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
            else % Use chainlike particle as solvent particle
                
                if strcmp(sys.solvent,'on')
                    alpha=ones(1,nu)*eta*6/pi/nhs;
                    
                    lastZ=max(nonzeroZ(1:nhs));
                    nonzeroZfixed=nonzeroZ(1:lastZ-1);
                    alpha(lastZ)=-1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZfixed).*r(nonzeroZfixed).^3.*Z(nonzeroZfixed));
                    
                    
                    c(1,Nhs)=alpha(Nhs).*(r(Nhs)/(2*Rreal)).^3/Mol;
                    
                    etamax=sys.solventeta;
                    c(1,Nc)=(etamax*6/pi-sum(alpha(Nhs)))/(sum(1./r(Nc).^3))/(2*Rreal).^3/Mol;
                    alpha=c(1,:)./r.^3*(2*Rreal)^3*Mol;
                    c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
                    
                else
                    rhob(Z(Nhs)>0)=eta*6/pi/sum(abs(Z(Nhs)))*sum(abs(Z(Z(Nhs)<0)))/sum(abs(Z(Z(Nhs)>0)))*rhoposratio;
                    rhob(Z(Nhs)<0)=(Z(Z(Nhs)>0)*rhob(Z(Nhs)>0)')*sum(rhonegratio.*abs(Z(Z(Nhs)<0)))*rhonegratio/sum(sum(rhonegratio.*abs(Z(Z(Nhs)<0)))*rhonegratio.*abs(Z(Z(Nhs)<0)));
                    alpha(Z(Nhs)~=0)=rhob./r(Z(Nhs)~=0).^3;
                    alpha(Nc)=rhocratio*alpha(1)./r(Nc).^3;
                    alpha=alpha*eta/(pi/6*sum(alpha));
                    c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
                end
            end
        else
            % when all HS species are charged
%             if isempty(Z(Z(Nhs)==0)) %fix the concentrations using the ratios
                ZZ=[Z(Nhs) Zchain];
                if Zchain<0
                    rhob = zeros(1,length(ZZ));
                    rhob(ZZ>0)=eta*6/pi/sum(abs(ZZ))*sum(abs(ZZ(ZZ<0)))/sum(abs(ZZ(ZZ>0)))*rhoposratio;
                    rhob(ZZ<0)=(ZZ(ZZ>0)*rhob(ZZ>0)')*sum([rhonegratio rhocratio].*abs(ZZ(ZZ<0)))*[rhonegratio  rhocratio]/sum(sum([rhonegratio  rhocratio].*abs(ZZ(ZZ<0)))*[rhonegratio rhocratio].*abs(ZZ(ZZ<0)));
                    rhob(Nc)=rhob(nhs+1);
                    alpha=eta/(sum(rhob./r.^3)*pi/6)*(rhob./r.^3);
                    c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
                else
                    rhob(ZZ>0)=eta*6/pi/sum(abs(ZZ))*sum(abs(ZZ(ZZ<0)))/sum(abs(ZZ(ZZ>0)))*[rhoposratio rhocratio];
                    rhob(ZZ<0)=(ZZ(ZZ>0)*rhob(ZZ>0)')*sum(rhonegratio.*abs(ZZ(ZZ<0)))*rhonegratio/sum(sum(rhonegratio.*abs(ZZ(ZZ<0)))*rhonegratio.*abs(ZZ(ZZ<0)));
                    rhob(Nc)=rhob(nhs+1);
                    alpha=eta/(sum(rhob./r.^3)*pi/6)*(rhob./r.^3);
                    c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
                end
%             else %when there are neutral HS species
%                 
%                 alpha(Z==0) = csolv./((r(Z==0)/(2*Rreal)).^3/Mol);
%                 alpha(Z~=0) = (eta*6/pi-csolv./((r(Z==0)/(2*Rreal)).^3/Mol))/(nu-1);
%                 
%                 lastZ = nhs+1;
%                 nonzeroZfixed = nonzeroZ(1:lastZ-1);
%                 alpha(lastZ) = -1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZfixed).*r(nonzeroZfixed).^3.*Z(nonzeroZfixed));
%                 alpha(Nc) = alpha(lastZ);
%                 
%                 c(1,:) = alpha.*(r/(2*Rreal)).^3/Mol;
%                 c(1,Z==0) = csolv;
%                 c(1,find(Z(Nc)==0,1)+nhs)=c(1,find(Z(Nc)~=0, 1)+nhs);
%                 alpha=c(1,:)./r.^3*(2*Rreal)^3*Mol;
%                 alpha([find(Z(Nhs)~=0) Nc])=alpha([find(Z(Nhs)~=0) Nc])*(eta-pi/6*sum(alpha(Z(Nhs)==0)))/(pi/6*sum(alpha([find(Z(Nhs)~=0) Nc])));
%                 c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
%             end
        end
        
    end
else
    
    if isempty(find(Z~=0, 1))% If there are no charges particles distribute according to ratios
        alpha = eta*6/pi/nhs*ones(1,nhs);
        alpha = rhoratio*alpha(1)./r.^3;
        alpha = alpha*eta/(pi/6*sum(alpha));
        c(1,:) = alpha.*(r/(2*Rreal)).^3/Mol;
    else

        alpha = eta*6/pi/nhs*ones(1,nhs);
        %         if isempty(Z(Z==0)) %fix the concentrations using the ratios
        rhob(Z>0) = eta*6/pi/sum(abs(Z))*sum(abs(Z(Z<0)))/sum(abs(Z(Z>0)))*rhoposratio;
        rhob(Z<0) = (Z(Z>0)*rhob(Z>0)')*sum(rhonegratio.*abs(Z(Z<0)))*rhonegratio/sum(sum(rhonegratio.*abs(Z(Z<0)))*rhonegratio.*abs(Z(Z<0)));
        alpha(Z~=0) = rhob(Z~=0)./r(Z~=0).^3;
        alpha(Z==0) = rhoratio(Z==0)*alpha(1)./r(Z==0).^3;
        alpha = alpha*eta/(pi/6*sum(alpha));

        
        c(1,:) = alpha.*(r/(2*Rreal)).^3/Mol;
        
    end
    
end