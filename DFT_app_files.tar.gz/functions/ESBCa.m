function [phi, D2, B, C]=ESBCa(phiV,sigma0,z,d,beta,el,BC,v0)
N=length(z);
zmax=max(z);
phi=zeros(1,length(z));
    if strcmp(BC,'DD')
        % Dirichlet-Dirichlet BC
        C=zeros(N,1);
        C(1,:)=2*phiV(v0)*el*beta/d^2; %potential at the wall left
        C(N,:)=-2*phiV(v0)*el*beta/d^2; %potential at the wall right
        
        phi=cosh(z-zmax/2)*phiV(v0)*el*beta/cosh(-zmax/2);%Trial potential profile used in initial density profile
        
        %Differential operator
        e=ones(N,1);
        D2=1/d^2*spdiags([e -2*e e],-1:1,N,N); %Tridiagonal matrix for Laplacian
        D2(1,1)=-3/d^2; %corrections for chosing gridpoints at z_i=d*(i-1/2)
        D2(N,N)=-3/d^2;
        B=spdiags(e,0,N,N)+D2*d^2/12; %second term is for second order corrections to the Laplacian
        
    elseif strcmp(BC,'ND')
        %Neumann-Dirichlet BC with zero potential on the right side of the
        %system
        %Differential operator
        e=ones(N,1);
        D2=1/d^2*spdiags([e -2*e e],-1:1,N,N);
        D2(1,1)=-1/d^2;
        D2(N,N)=-3/d^2;
        B=spdiags(e,0,N,N)+D2*d^2/12;
        
        sigma0=sigma0(v0)*(2*Rreal)^2*1e-18/el; %Converting C/m^2 to C/(2R)^2
        
        C=zeros(N,1); % Boundary condition vector
        C(1,:)=4*pi*lambda*sigma0/d;%charge density sigma on left side and zero potential on right side of the system
        K=sqrt(4*pi*lambda*sum(Z.^2.*alpha.*r.^3)); % Debye Parameter
        if 4*pi*lambda*sigma0/K>3
            K=4*pi*lambda*sigma0/3; %Merely to prevent too large starting density profiles
        end
        if length(Z==0)==length(Z)
            phi=zeros(1,length(z));
        else
            phi=4*pi*lambda*sigma0/K*exp(-z*K); %Trial potential profile used in initial density profile
        end
    else
        phi=zeros(1,N);
        C=zeros(N,1);
        B=zeros(N,N);
        D2=zeros(N,N);
    end