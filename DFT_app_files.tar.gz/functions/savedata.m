function  wat=savedata(piet)
hallo=1;
meneer=2;
filename=piet;
save(['C:\Users\peter\surfdrive\PhD\MATLAB\DFT ILs good\data\decay\' filename])
end