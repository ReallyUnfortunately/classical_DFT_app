function [F,f,p_HS_id]=F_id_ex_FMT(PhiFMT,g,c1,alpha,d,r,BC)
N=length(g(1,:));
if strcmp(BC,'ND')%setting integration range
    nsys=1:round(0.6*size(g,2));%for calculating the grand potential, we only want to integrate up to half the system in case of ND BC because of finite-size effects
else
    nsys=1:size(g,2);
end

    F.ex_FMT=d*sum(PhiFMT.tot(nsys));
    
    F.id_legendre=d*nansum((r.^3.*alpha)*(g(:,nsys).*(c1(:,nsys)-1)));
    
    f.id_FMT=PhiFMT.tot+(r.^3.*alpha)*(g(:,nsys).*(c1(:,nsys)-1));
    
    p_HS_id=-f.id_FMT(round(N/2));

end