function [F,f,p_ES]=F_ex_ES(g,z,Z,alpha,r,phi,phi0LV,sig,MSA,F,f,BC)
d=z(2)-z(1);
N=length(g(1,:));
if strcmp(BC.type,'ND')%setting integration range
    nsys=1:round(0.6*size(g,2));%for calculating the grand potential, we only want to integrate up to half the system in case of ND BC because of finite-size effects
    zmax=z(nsys(end))+d/2;
else
    nsys=1:N;
    zmax=z(nsys(end))+d/2;
end
    F.ex_ESu=d*sum(MSA.Phi(nsys));
    F.ex_ESc=-d*1/2*sum((alpha.*r.^3)*(g.*MSA.c1ESc));

% F.ex_ESc=0;
% for j=1:length(r)
%     if strcmp(BC.type,'ND')
%         F.ex_ESc=F.ex_ESc-1/2*simpsons((alpha.*r.^3)*(g.*MSA.c1ESc),1/r(j)/2,zmax);
%     else
%         F.ex_ESc=F.ex_ESc-1/2*simpsons((alpha.*r.^3)*(g.*MSA.c1ESc),1/r(j)/2+d/2,zmax-1/r(j)/2-d/2);
% %         F.ex_ESc=F.ex_ESc-1/2*simpsons((alpha.*r.^3)*(g.*MSA.c1ESc),0,zmax);
%     end
% end

    F.ex_ESC=1/2*d*sum((Z.*r.^3.*alpha)*g(:,nsys).*phi(nsys));
    F.ex_ESC_wall=1/2*phi0LV*sig';
    
    f.ex_ES=MSA.Phi-1/2*sum((alpha'.*r'.^3.*g).*MSA.c1ESc)+1/2*Z*(r'.^3.*alpha'.*g).*phi;
    
%     F.ex_ES=simpsons(f.ex_ES,0,zmax);
    
    p_ES=-f.ex_ES(round(N/2));
end