%% External potential=potential of wall=hard-wall potential
function V_ext_x=Vext_GUI(sys,V_ext,z0,app)
nu=sys.nu;
r=sys.r;

%Distance between gridpoints
d=1/sys.ngrid;

if nargin  ~= 3
    z0 = 1;
end

if nargin == 4
    %Round sys.zmax off in terms to d
    zmax = round(sys.zmax(z0)/d)*d;
else
    zmax = sys.zmax(z0);
end

% number of gridpoints |1|2|3|...|N-1|N|
N=round(sys.ngrid*sys.zmax(z0));

%Length vector with z_i=d*(i-1/2)
z=d*((1:N)-1/2);

V_ext_x=zeros(nu,N);

%% hard-wall

for j=1:nu
    V_ext_x(j,1:round(1/2/r(j)/d))=inf;
    V_ext_x(j,N-round(1/2/r(j)/d)+1:N)=inf;
end


%% Lennard-Jones Potential for wall-particle
if strcmp(V_ext.Steele,'on')
    %External Potential of LJ-wall with the Steele 10-4-3 potential
    for j=1:nu
        V_ext_x(j,:) = V_ext_x(j,:)+2*pi*V_ext.Steele_rhow*V_ext.Steele_dw(j)^3*V_ext.Steele_eLJw(j)*V_ext.Steele_dS*(2/5*(V_ext.Steele_dw(j)./z).^10-(mean(V_ext.Steele_dw(j))./z).^4-mean(V_ext.Steele_dw(j))^4./(3*mean(V_ext.Steele_dS)*(z+0.61*mean(V_ext.Steele_dS)).^3));
%         V_ext_x(j,:)=V_ext_x(j,:)+2*pi*V_ext.Steele_rhow*V_ext.Steele_dw(j)^2*V_ext.Steele_eLJw(j)*V_ext.Steele_dS*(2/5*(V_ext.Steele_dw(j)./fliplr(z)).^10-(mean(V_ext.Steele_dw(j,:))./fliplr(z)).^4-mean(V_ext.Steele_dw(j,:))^4./(3*mean(V_ext.Steele_dS(j,:))*(fliplr(z)+0.61*mean(V_ext.Steele_dS(j,:))).^3));
        V_ext_x(j,:) = V_ext_x(j,:) + fliplr(V_ext_x(j,:));
    end
end

%% WCA potential for wall-particle
if strcmp(V_ext.WCA,'on')
    for j=1:nu
        Nwca=1/d/r(j)/2+1:floor((V_ext.WCAd(j)/d)*2^(1/6));

        if strcmp(V_ext.WCAsingle,'on')
            V_ext_x(j,Nwca)=2*pi*V_ext.WCAeps(j)*V_ext.WCArho*V_ext.WCAd(j)^2*(2/5*(V_ext.WCAd(j)./z(Nwca)).^10-(V_ext.WCAd(j)./z(Nwca)).^4+2^(4/3)/5+1/2*(2^(1/3)-z(Nwca).^2/V_ext.WCAd(j)^2));
            V_ext_x(j,:)=V_ext_x(j,:)+fliplr(V_ext_x(j,:));
        else
%             V_ext_x(j,Nwca)=2*pi*V_ext.WCAeps(j)*V_ext.WCArho*V_ext.WCAd(j)^3*( 2/3*(1/15*(V_ext.WCAd(j)./z(Nwca)).^9-1/2*(V_ext.WCAd(j)./z(Nwca)).^3) + (2^(4/3)/5+2^(-2/3))*(2^(1/6)-z(Nwca)/V_ext.WCAd(j))...
%             - 1/3*(sqrt(2)-(z(Nwca)/V_ext.WCAd(j)).^3) - (sqrt(2)/90-1/(3*sqrt(2))));
            
            
            V_ext_x(j,Nwca)=2*pi*V_ext.WCAeps(j)*V_ext.WCArho*V_ext.WCAd(j)^3*(2/45*(V_ext.WCAd(j)./z(Nwca)).^9-1/3*(V_ext.WCAd(j)./z(Nwca)).^3-2^(4/3)/5*z(Nwca)/V_ext.WCAd(j)-1/2*(2^(1/3)*z(Nwca)/V_ext.WCAd(j)-1/3*(z(Nwca)/V_ext.WCAd(j)).^3)+16/9/sqrt(2));
            V_ext_x(j,:)=V_ext_x(j,:)+fliplr(V_ext_x(j,:));
        end
    end
end

%% Attractive EXP
if strcmp(V_ext.EXP,'on')
    for j=1:nu
        Nexp = 1/d/r(j)/2+1:N-1/d/r(j)/2;
        V_ext_x(j,Nexp)=V_ext.EXPeps(j)*exp(-(z(Nexp)-1/r(j)/2)/V_ext.EXPK(j));
        V_ext_x(j,:)=V_ext_x(j,:)+fliplr(V_ext_x(j,:));
    end
end


% Plot if run from app
if nargin == 4
    plot(app.UIAxes,z,V_ext_x);
    app.UIAxes.XLim = ([0 max(z)]);
    app.UIAxes.YLim = ([max(-100,1.1*min(min(V_ext_x(~isinf(V_ext_x))))-0.01) min(10,1.1*max(max(V_ext_x(~isinf(V_ext_x)))))]);
end
end