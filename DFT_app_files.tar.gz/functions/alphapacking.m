function [alpha,c]=alphapacking(Nc,Nhs,eta,Z,r,csolv,Mol,sys)
Rreal=sys.Rreal;
nhs=sys.nhs;
M=sys.M;
nu=M+nhs;



if M~=0 % When there are chain-like particles in the system
    
    if isempty(find(Z~=0, 1)) % If there are no charges particles
        alpha=ones(1,nu)*eta*6/pi/(nhs+1);
        alpha(Nc)=alpha(Nc)/M;
        alpha=alpha*eta/(pi/6*sum(alpha));
        c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
    else
        %Now we need a charge-neutral bulk system with the given
        %concentration
        alpha=ones(1,nu)*eta*6/pi/(nhs+1); %Divide the concentration evenly among the particles
        nonzeroZ=find(Z~=0); % Find the species with charge
        Zchain=sum(Z(nonzeroZ(nonzeroZ>nhs))); % total charge of a chain-like particle
        
        if Zchain==0 %if total charge of chain-like particle vanishes it is not constraint by charge-neutrality
            if nhs==0 % if there are no monomers in the system
                alpha=ones(1,nu)*eta*6/pi/nu;
                alpha=alpha*eta/(pi/6*sum(alpha));
                c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
            else % Use chainlike particle as solvent particle
                
                alpha=ones(1,nu)*eta*6/pi/nhs;
                
                lastZ=max(nonzeroZ(1:nhs));
                nonzeroZfixed=nonzeroZ(1:lastZ-1);
                alpha(lastZ)=-1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZfixed).*r(nonzeroZfixed).^3.*Z(nonzeroZfixed));
                
                
                c(1,Nhs)=alpha(Nhs).*(r(Nhs)/(2*Rreal)).^3/Mol;
                %                 c(1,Nc)=csolv;
                etamax=0.47;
                c(1,Nc)=(etamax*6/pi-sum(alpha(Nhs)))/(sum(1./r(Nc).^3))/(2*Rreal).^3/Mol;
                alpha=c(1,:)./r.^3*(2*Rreal)^3*Mol;
                %                 alpha(Z(Nhs)~=0)=alpha(Z(Nhs)~=0)*(eta-pi/6*sum(alpha(Nc)))/(pi/6*sum(alpha(Z(Nhs)~=0)));
                c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
            end
        else
            
            rhoposratio = sys.rhoratio(Z(1:nhs)>0);
            if isempty(rhoposratio)
                rhoposratio=1;
            else
                rhoposratio = rhoposratio/rhoposratio(1);
            end
            
            
            rhonegratio = sys.rhoratio(Z(1:nhs)<0);
            if isempty(rhonegratio)
                rhonegratio=1;
            else
                rhonegratio = rhonegratio/rhonegratio(1);
            end
            if isempty(Z(Z(Nhs)==0)) %fix the concentrations using the ratios
                ZZ=[Z(Nhs) Zchain];
                if Zchain<0
                    rhob(ZZ(Nhs)>0)=eta*6/pi/sum(abs(ZZ))*sum(abs(ZZ(ZZ<0)))/sum(abs(ZZ(ZZ>0)))*rhoposratio;
                    rhob(ZZ(Nhs)<0)=(ZZ(ZZ>0)*rhob(ZZ>0)')*sum([rhonegratio sys.rhocratio].*abs(ZZ(ZZ<0)))*[rhonegratio  sys.rhocratio]/sum(sum([rhonegratio  sys.rhocratio].*abs(ZZ(ZZ<0)))*[rhonegratio sys.rhocratio].*abs(ZZ(ZZ<0)));
                    rhob(Nc)=rhob(nhs+1);
                    alpha=eta/(sum(rhob./r.^3)*pi/6)*(rhob./r.^3);
                    c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
                else
                    rhob(ZZ>0)=eta*6/pi/sum(abs(ZZ))*sum(abs(ZZ(ZZ<0)))/sum(abs(ZZ(ZZ>0)))*[rhoposratio sys.rhocratio];
                    rhob(ZZ<0)=(ZZ(ZZ>0)*rhob(ZZ>0)')*sum(rhonegratio.*abs(ZZ(ZZ<0)))*rhonegratio/sum(sum(rhonegratio.*abs(ZZ(ZZ<0)))*rhonegratio.*abs(ZZ(ZZ<0)));
                    rhob(Nc)=rhob(nhs+1);
                    alpha=eta/(sum(rhob./r.^3)*pi/6)*(rhob./r.^3);
                    c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
                end
            else
                
                alpha(Z==0)=csolv./((r(Z==0)/(2*Rreal)).^3/Mol);
                alpha(Z~=0)=(eta*6/pi-csolv./((r(Z==0)/(2*Rreal)).^3/Mol))/(nu-1);
                
                lastZ=nhs+1;
                nonzeroZfixed=nonzeroZ(1:lastZ-1);
                alpha(lastZ)=-1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZfixed).*r(nonzeroZfixed).^3.*Z(nonzeroZfixed));
                alpha(Nc)=alpha(lastZ);
                
                c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
                c(1,Z==0)=csolv;
                c(1,find(Z(Nc)==0,1)+nhs)=c(1,find(Z(Nc)~=0, 1)+nhs);
                alpha=c(1,:)./r.^3*(2*Rreal)^3*Mol;
                alpha([find(Z(Nhs)~=0) Nc])=alpha([find(Z(Nhs)~=0) Nc])*(eta-pi/6*sum(alpha(Z(Nhs)==0)))/(pi/6*sum(alpha([find(Z(Nhs)~=0) Nc])));
                c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
            end
        end
        
    end
else
    
    if isempty(find(Z~=0, 1))% If there are no charges particles distribute equally
        alpha=eta*6/pi/nhs*ones(1,nhs);
        c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
    else
            rhoposratio = sys.rhoratio(Z(1:nhs)>0);
            if isempty(rhoposratio)
                rhoposratio=1;
            else
                rhoposratio = rhoposratio/rhoposratio(1);
            end
            
            
            rhonegratio = sys.rhoratio(Z(1:nhs)<0);
            if isempty(rhonegratio)
                rhonegratio=1;
            else
                rhonegratio = rhonegratio/rhonegratio(1);
            end
        if isempty(Z(Z==0)) %fix the concentrations using the ratios
            rhob(Z>0)=eta*6/pi/sum(abs(Z))*sum(abs(Z(Z<0)))/sum(abs(Z(Z>0)))*rhoposratio;
            rhob(Z<0)=(Z(Z>0)*rhob(Z>0)')*sum(rhonegratio.*abs(Z(Z<0)))*rhonegratio/sum(sum(rhonegratio.*abs(Z(Z<0)))*rhonegratio.*abs(Z(Z<0)));
            alpha=eta/(sum(rhob./r.^3)*pi/6)*(rhob./r.^3);
        else
            
            %fixing the concentrations by tuning the concentration of the last charged species
            alpha=eta*6/pi/nhs*ones(1,nu);
            nonzeroZ=find(Z~=0);
            lastZ=max(nonzeroZ);
            nonzeroZ=nonzeroZ(1:length(nonzeroZ)-1);
            alpha(lastZ)=-1/Z(lastZ)/r(lastZ)^3*sum(alpha(nonzeroZ).*r(nonzeroZ).^3.*Z(nonzeroZ));
            alpha(Z==0)=sys.rhoratio(Z==0)*alpha(1)./sys.r(Z==0).^3;
            clear nonzeroZ lastZ
            
%             c(1,Z~=0)=alpha(Z~=0).*(r(Z~=0)/(2*Rreal)).^3/Mol;
%             c(1,Z==0)=csolv;
%             alpha=c(1,:)./r.^3*(2*Rreal)^3*Mol;
            
            if strcmp(sys.packing,'on')
                alpha=alpha*eta/(pi/6*sum(alpha));
            end
            
        end
        
        c(1,:)=alpha.*(r/(2*Rreal)).^3/Mol;
        
    end
    
end