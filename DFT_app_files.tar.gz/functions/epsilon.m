function eps=epsilon(epsilonw,epsilon0,n,nb,c,beta,el,M,Z)
% M=Na*1e3;% Molar to #/m^3
% c=1e-6:0.001:6;%Concentration in Molar
% ntot=sum(c)*M;
% ntot=2*c*M;

if max(Z==0)==1
    
    if isstruct(n)
        ions=Z~=0;
        nc=n.n3/nb.n3*sum(c(ions));
        n3p=n.n3p;
    else
        ions=Z~=0;
        nc=n/nb*sum(c(ions));
        n3p=1;
    end
    
    
    polar=Z==0;
    
    delta=9/(2*(9+4*pi))*((epsilonw-1)-1+sqrt(((epsilonw-1)-1).^2+4*(epsilonw-1)*(1+4*pi/9)));
    % a=3.55*1e-10;%The only fitting parameter
    a=(sum(c)*M)^(-1/3)*1e-9;
    ntot=nc*M*1e27;
    npol=n3p*sum(c(polar))*M*1e27;
    kmax=2*pi/a;
    pdip=sqrt(delta*3*epsilon0*a^3/beta);
    
    
    deltaMF=pdip.^2*beta/(3*epsilon0*a^3);
    epsMF=(1+npol*a^3.*deltaMF)*epsilon0;
    % epsMFc=epsMF/epsilon0;  %mean-field value?
    K=sqrt(ntot*el^2*beta./epsMF); %kind-off Debye parameter
    G=1/2/pi^2./epsMF.*(kmax-K.*atan(kmax./K));
    DG=K.^2.*G-kmax^3/6/pi^2./epsMF;
    eps=1+npol*a^3.*delta-1/3*epsilon0*(npol*a^3).^2.*a^3.*delta.^2.*DG;
    
    
else
    
    
    if isstruct(n)
        nc=n.n3/nb.n3*sum(c);
    else
        nc=sum(n)/nb*sum(c);
    end
    
    
    delta=9/(2*(9+4*pi))*((epsilonw-1)-1+sqrt(((epsilonw-1)-1).^2+4*(epsilonw-1)*(1+4*pi/9)));
    a=3.55*1e-10;%The only fitting parameter
    ntot=nc*M*1e27;
    Phi=ntot*a^3;%Packing fraction sum_j a^3*rho_b^j
    kmax=2*pi/a;
    pdip=sqrt(delta*3*epsilon0*a^3/beta);
    
    
    deltaMF=pdip.^2*beta/(3*epsilon0*a^3);
    epsMF=(1+(1-Phi).*deltaMF)*epsilon0;
    % epsMFc=epsMF/epsilon0;  %mean-field value?
    K=sqrt(ntot*el^2*beta./epsMF); %kind-off Debye parameter
    G=1/2/pi^2./epsMF.*(kmax-K.*atan(kmax./K));
    DG=K.^2.*G-kmax^3/6/pi^2./epsMF;
    eps=1+(1-Phi).*delta-1/3*epsilon0*(1-Phi).^2.*a^3.*delta.^2.*DG;
end