function [c1ES,MSA]=ESMSA(Z,alpha,g,lambda,r,d,z,MSA,dft,errg)

if nnz(Z)>1
    %% Direct correlation functions due to energy term
    [c1ESu,MSA]=c1MSAu(alpha,Z,r,d,z,g,MSA,lambda,dft,errg);
    MSA.c1ESu=c1ESu;
    
    %% Direct correlation function from correlations
    c1ESc=c1MSAdc(alpha,Z,r,d,g,MSA,lambda,dft);
    MSA.c1ESc=c1ESc;
    
    %% Total contribution electrostatics to C1
    
    c1ES=c1ESc+c1ESu;

end

end
