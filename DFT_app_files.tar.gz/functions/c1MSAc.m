function [c1ESc]=c1MSAc(alphat,Z,r,d,z,g,MSA,lambda,dft)

c1ESc=zeros(length(r),size(g,2));
if nnz(Z)>1
    if strcmp(dft.ESc,'MSA')
        c1MSAc=zeros(length(r),size(g,2));
        
        for i=1:length(r)
            for j=1:length(r)
                

                
                Ddif=max(abs(1/r(j)-1/r(i))/2,0);
                Dsum=(1/r(j)+1/r(i))/2;
                NDs=ceil(Ddif/d);
                NDl=ceil((1/r(j)+1/r(i))/2/d);
                zds=d*(-NDs:NDs);
                zdl=d*(-NDl:NDl);
                
                %Direct correlation function c^(2)
                c2MSAc=2*pi*Z(i)*Z(j)*lambda*(Dsum-abs(zdl))+...
                    2*pi*lambda*(MSA.L0(i,j)*(Dsum-abs(zdl))+MSA.L1(i,j)/2*(Dsum^2-zdl.^2)+MSA.L2(i,j)/3*(Dsum^3-abs(zdl).^3)+MSA.L4/5*(Dsum^5-abs(zdl).^5));
                c2MSAc(-NDs+(length(c2MSAc)+1)/2:NDs+(length(c2MSAc)+1)/2)=pi*(Ddif^2-zds.^2)*MSA.cMSAsh(i,j)+...
                    2*pi*lambda*(MSA.L0(i,j)*(Dsum-Ddif)+MSA.L1(i,j)/2*(Dsum^2-Ddif^2)+MSA.L2(i,j)/3*(Dsum^3-Ddif^3)+MSA.L4/5*(Dsum^5-Ddif^5))+2*pi*lambda*Z(i)*Z(j)*(Dsum-abs(zds));
                
                % Normalize
                if sign(MSA.c2MSAcb(i,j))*(d*sum(c2MSAc)-MSA.c2MSAcb(i,j))<0
                    c2MSAc([1,end])=c2MSAc([1,end])-(d*sum(c2MSAc)-MSA.c2MSAcb(i,j))/2/d;
                else
                    c2MSAc([2,end-1])=c2MSAc([2,end-1])-(d*sum(c2MSAc)-MSA.c2MSAcb(i,j))/2/d;
                end
                
                % Direct correlation function c^(1)
                c1MSAc(i,:)=c1MSAc(i,:)+d*conv(alphat(j)*r(j)^3*g(j,:),c2MSAc,'same');
            end
        end
        c1ESc=c1MSAc;
    elseif strcmp(dft.ESc,'MSA_RPM')
        %% MSA direct correlation function from RPM, psish+psiC eq. 37 in J. Phys.: Condens. Matter 28 244006
        N=length(z);
        
        RR=1/2*(1./r+1./r');
        
        b=MSA.b;
        
        %Shell Radius
        B=b+b';
        BB=b'*b;
        
        ZZ=Z'*Z;
        
        nzero=find(Z~=0);
        
        c1MSAcRPM=zeros(length(r),N);
        
        for j=1:length(nzero)
            for k=1:length(nzero)
                
                NDl=ceil((1/r(nzero(j))+1/r(nzero(k)))/2/d);
                zdl=d*(-NDl:NDl);
                
                c2MSAcRPM=lambda*pi/2*ZZ(nzero(j),nzero(k))./BB(nzero(j),nzero(k)).*(1/3*RR(nzero(j),nzero(k)).^3+...
                    B(nzero(j),nzero(k)).^2.*RR(nzero(j),nzero(k))-...
                    B(nzero(j),nzero(k)).*RR(nzero(j),nzero(k)).^2+...
                    B(nzero(j),nzero(k)).*zdl.^2-...
                    1/3*(abs(zdl).^3)-...
                    abs(zdl).*B(nzero(j),nzero(k)).^2);
                
                % Normalize
                if sign(MSA.c2MSAcRPMb(nzero(j),nzero(k)))*(d*sum(c2MSAcRPM)-MSA.c2MSAcRPMb(nzero(j),nzero(k)))<0
                    c2MSAcRPM([1,end])=c2MSAcRPM([1,end])-(d*sum(c2MSAcRPM)-MSA.c2MSAcRPMb(nzero(j),nzero(k)))/2/d;
                else
                    c2MSAcRPM([2,end-1])=c2MSAcRPM([2,end-1])-(d*sum(c2MSAcRPM)-MSA.c2MSAcRPMb(nzero(j),nzero(k)))/2/d;
                end
                
                %Direct correlation function c^(1)
                c1MSAcRPM(nzero(j),:)=c1MSAcRPM(nzero(j),:)+d*conv(alphat(nzero(k))*r(nzero(k))^3*g(nzero(k),:),c2MSAcRPM,'same');
            end
        end
        c1ESc=c1MSAcRPM;
    end
end
