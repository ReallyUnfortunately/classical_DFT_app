function [c1DH]=ESDH(z,g,alphat,r,W,Z,lambda)
d=z(2)-z(1);
N=length(z);

q=zeros(length(r),N);
Kb=sqrt(4*pi*lambda*Z.^2.*r.^3*alphat');
b=1./r/2+1./Kb;
% b=1./r/2;
% b=0.1;
Nb=ceil(b/d);

WF=zeros(length(r),2*N-1);
for j=1:length(r)
    WF(j,max(N-Nb(j)+1,1):min(N+Nb(j)-1,size(WF,2)))=1/(2*b(j));
            if d*sum(WF(j,:))-1<0 
                WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])=WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])-(d*sum(WF(j,:))-1)/2/d;
            else
                WF(j,[max(N-Nb(j)+1,1) min(N+Nb(j)-1,size(WF,2))])=WF(j,[max(N-Nb(j)+1,1) min(N+Nb(j)-1,size(WF,2))])-(d*sum(WF(j,:))-1)/2/d;
            end
    WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])=WF(j,[max(N-Nb(j),1) min(N+Nb(j),size(WF,2))])-(d*sum(WF(j,:))-1)/2/d;
end

for j=1:length(r)
    q(j,:)=d*(conv(g(j,:)*alphat(j)*r(j)^3,WF(j,:),'same'));
end

K=sqrt(4*pi*lambda*Z.^2*q);

Phiu=Z'.^2.*K.*(2-K./r'/2)./(3*(1+K./r'/2));
dK=2*pi*lambda*Z'.^2./K;
dPhiu=(alphat.*r.^3)*(g.*(Phiu./K-Z'.^2.*K./r'/2./(1+K./r'/2).^2)).*dK;

c1DH=zeros(length(r),N);
for j=1:length(r)
    c1DH(j,:)=lambda/2*Phiu(j,:)+lambda/2*d*conv(dPhiu(j,:),WF(j,:),'same');
end

