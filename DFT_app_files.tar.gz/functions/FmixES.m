function [FexES,FexMSA,FexC,FexnonMSA]=FmixES(gs,Zs,alphas,gb,Zb,alphab,phi,phiV,sigma,PhiMSA,C1sESnonMSA,C1bESnonMSA,r,d)
    FexMSA=d*sum(PhiMSA);
    FexC=1/2*d*(sum((Zs*alphas*gs+Zb*r^3*alphab*gb).*phi))+1/2*phiV*sigma;
    FexnonMSA=d*1/2*(-sum(alphas*gs.*C1sESnonMSA)-sum(alphab*r^3*gb.*C1bESnonMSA));
    
    FexES=FexMSA+FexC+FexnonMSA;
end