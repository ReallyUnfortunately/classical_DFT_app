function [decay, wav, offset]=asymptot(g,phi,z,sys)
%%
[rr cc]=find(g<1e-10);
lowest=cc(find(abs(diff(cc))==max(abs(diff(cc)))))+1;

d=z(2)-z(1);
N=length(z);

minstart=2;
nh=round(max(lowest,1/d)):N/2;
zh=z(nh);

midoff=3/d;

bottom=[9.5 11 10];


fun(:,1)=log(abs(g(1,nh)+g(2,nh)-2))';
if max(abs(phi))>1e-13
    fun(:,2)=log(abs(g(1,nh)-g(2,nh)))';
    fun(:,3)=log(abs(phi(nh)))';
else
    decay(2:3)=0;
    wav(2:3)=0;
end
%%
for i=1:size(fun,2)
    [~,kolk]=find(diff(sign(diff(fun(:,i))))'==-2 & fun(2:length(fun(:,i))-1,i)'>-bottom(i)*log(10));%find peaks + numerical precision
    kolk=kolk+1;
    kolk(kolk<1/d)=[];
    fitfunt=fun(kolk,i);
    ztry=zh(kolk);
    if ~isempty(kolk)&&length(kolk)>1
        h=histcounts(diff(kolk),[-0.5:1:max(diff(kolk))+0.5]);
        [~,colwav]=find(h==max(h));
        if length(colwav)>1
            colwav=median(diff(kolk));
        end
        wav(i)=(colwav-1)*d;
    else
        wav(i)=inf;
    end
    
    if length(fitfunt)>3
        [row1, ~]=find(fitfunt<-bottom(i)*log(10));%Numerical precision
        [row2, ~]=find(fitfunt==min(fitfunt));%search for minimum
        row=nanmin([min(row1),min(row2)]);
        zfit=round(minstart):min(max(row,4),length(ztry));
        fitfun=fitfunt(zfit);
        zgridfit=ztry(zfit);
    else
        [row1, ~]=find(fun(~islocalmin(fun(:,i)),i)<-bottom(i)*log(10));
        [row0, ~]=find(islocalmin(fun(round(minstart/d:N/2-midoff),i))==max([islocalmin(fun(round(minstart/d:N/2-midoff),i)); 0.1]));
        row0=round(max(row0(row0<min([row1; N/2-midoff])))+minstart/d);%Used for cases when the decay length changes over distance
        [row2, ~]=find(fun(:,i)==min(fun(:,i)));
        row=nanmin([min(row1),min(row2)]);
        
        if isempty(row0)||i~=1||abs(row0-row)<2/d
            zfit=round(minstart/d):round(min(max(row,3/d+10),N/2-midoff));
            fitfun=fun(zfit,i);
        else
            zfit=max(round(minstart/d),row0+2/d):round(min(max(row,3/d+10),N/2-midoff));
            fitfun=fun(zfit,i);
            zfit=zfit(~islocalmin(fitfun));
            fitfun=fitfun(~islocalmin(fitfun));
        end
        
        zgridfit=z(zfit);
    end
    
    
    [row, col]=find(isinf(fitfun));
    if ~isempty(row)&&max(abs(phi))~=0
        zfit=zfit(1):zfit(min(row)-1);
        fitfun=fitfun(1:min(row)-1);
    end
    
    if max(abs(phi))~=0&&~isempty(fitfun)
        Kfit=fit(2*sys.Rreal*zgridfit',fitfun,'poly1');
        decay(i)=-1/Kfit.p1;
        offset(i)=Kfit.p2;
        
        
        %%
        if i==1
            figure(13464);plot(zh,fun(:,i)*log10(exp(1)),zgridfit,(offset(i)+Kfit.p1*zgridfit*2*sys.Rreal)*log10(exp(1)));
            axis([0 z(round(N/2)) -13 2]);
%                         axis([0 25 -11 2]);
            pause(0.5)
        end
%         %
    else
        decay(i)=0;
        offset(i)=0;
    end
    
    
end
end