
% Natural Constants
epsilon0=8.854e-12; %permittivity constant
el=1.602e-19; %Electric charge
Na=6.0221e23; %Number of Avogadro
Mol=Na*1e3*1e-27;% Molar in #/nm^3